
import React, { useState, useEffect } from 'react';
import { Outlet } from 'react-router-dom';
import Navbar from '@/components/layout/Navbar';
import Footer from '@/components/layout/Footer';
import SplashScreen from '@/components/splash/SplashScreen';

const MainLayout = () => {
  const [showingSplash, setShowingSplash] = useState(true);
  
  // Check if this is the first visit in this session
  useEffect(() => {
    const hasVisited = sessionStorage.getItem('hasVisitedLuxAuto');
    if (hasVisited) {
      setShowingSplash(false);
    } else {
      sessionStorage.setItem('hasVisitedLuxAuto', 'true');
    }
  }, []);

  const handleSplashFinish = () => {
    setShowingSplash(false);
  };

  if (showingSplash) {
    return <SplashScreen onFinish={handleSplashFinish} />;
  }

  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <div className="flex-grow">
        <Outlet />
      </div>
      <Footer />
    </div>
  );
};

export default MainLayout;
