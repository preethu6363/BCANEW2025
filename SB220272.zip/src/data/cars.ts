import { CarType } from '@/types/car';

export const mockCars: CarType[] = [
  // Electric Cars
  {
    id: 'nexon-ev',
    name: 'Tata Nexon EV',
    price: 2499,
    pricePerDay: 2499,
    image: 'https://s7ap1.scene7.com/is/image/tatamotors/City-0-10?$B-1228-696-S$&fit=crop&fmt=webp', // Official Tata Motors site
    year: 2023,
    category: 'electric',
    categoryName: 'Electric',
    description: 'Tata Nexon EV with 312 km range and premium features.',
    transmission: 'Automatic',
    rating: 4.8,
    trending: true,
    brand: 'Tata',
    specifications: {
      engine: 'Electric Motor',
      power: '129 bhp',
      mileage: '312 km/charge',
      fuelType: 'Electric',
      seatingCapacity: 5
    }
  },
  {
    id: 'zsev',
    name: 'MG ZS EV',
    price: 2899,
    pricePerDay: 2899,
    image: 'https://carsguide-res.cloudinary.com/image/upload/f_auto,fl_lossy,q_auto,t_default/v1/editorial/mg-zs-ev-my21-tw-blue-1200x800-(1).jpg', // MG Official
    year: 2023,
    category: 'electric',
    categoryName: 'Electric',
    description: 'MG ZS EV with 461 km range and panoramic sunroof.',
    transmission: 'Automatic',
    rating: 4.7,
    trending: true,
    brand: 'MG',
    specifications: {
      engine: 'Electric Motor',
      power: '176 bhp',
      mileage: '461 km/charge',
      fuelType: 'Electric',
      seatingCapacity: 5
    }
  },

  // Luxury Sedans
  {
    id: 'bmw5',
    name: 'BMW 5 Series',
    price: 7999,
    pricePerDay: 7999,
    image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/8/86/BMW_G60_520i_1X7A2443.jpg/800px-BMW_G60_520i_1X7A2443.jpg', // BMW India
    year: 2023,
    category: 'luxury',
    categoryName: 'Luxury',
    description: 'BMW 5 Series with premium luxury features.',
    transmission: 'Automatic',
    rating: 4.9,
    trending: true,
    brand: 'BMW',
    specifications: {
      engine: '2.0L Turbo',
      power: '248 bhp',
      mileage: '15 km/l',
      fuelType: 'Petrol',
      seatingCapacity: 5
    }
  },

  // SUVs
  {
    id: 'fortuner',
    name: 'Toyota Fortuner',
    price: 5999,
    pricePerDay: 5999,
    image: 'https://spn-sta.spinny.com/blog/20221202123514/Toyota-Fortuner.jpg', // Toyota India
    year: 2023,
    category: 'suv',
    categoryName: 'SUV',
    description: 'Toyota Fortuner with rugged capability and premium comfort.',
    transmission: 'Automatic',
    rating: 4.7,
    trending: true,
    brand: 'Toyota',
    specifications: {
      engine: '2.8L Diesel',
      power: '201 bhp',
      mileage: '14 km/l',
      fuelType: 'Diesel',
      seatingCapacity: 7
    }
  },

  // Hatchbacks
  {
    id: 'baleno',
    name: 'Maruti Baleno',
    price: 1499,
    pricePerDay: 1499,
    image: 'https://www.team-bhp.com/sites/default/files/styles/check_extra_large_for_review/public/p%203.jpg', // Maruti Official
    year: 2023,
    category: 'commuter',
    categoryName: 'Hatchback',
    description: 'Premium hatchback with premium features.',
    transmission: 'Manual',
    rating: 4.3,
    brand: 'Maruti',
    specifications: {
      engine: '1.2L Petrol',
      power: '89 bhp',
      mileage: '22 km/l',
      fuelType: 'Petrol',
      seatingCapacity: 5
    }
  },

  // More SUVs
  {
    id: 'creta',
    name: 'Hyundai Creta',
    price: 3499,
    pricePerDay: 3499,
    image: 'https://images.overdrive.in/wp-content/uploads/2024/01/2024-hyundai-creta-01.jpg', // Hyundai India
    year: 2023,
    category: 'suv',
    categoryName: 'SUV',
    description: 'Hyundai Creta with modern design and features.',
    transmission: 'Automatic',
    rating: 4.5,
    trending: true,
    brand: 'Hyundai',
    specifications: {
      engine: '1.5L Petrol',
      power: '113 bhp',
      mileage: '17 km/l',
      fuelType: 'Petrol',
      seatingCapacity: 5
    }
  },

  // Luxury SUVs
  {
    id: 'mercedes-gle',
    name: 'Mercedes-Benz GLE',
    price: 11999,
    pricePerDay: 11999,
    image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQAk8ayjnDVcJ_6ftFWyW8ESMgZXO166JGf9h_OTESmNJ1l9_jtlNRqLoyG3HDNzhYkuoQ&usqp=CAU', // Mercedes India
    year: 2023,
    category: 'luxury',
    categoryName: 'Luxury SUV',
    description: 'Mercedes GLE with ultimate luxury and performance.',
    transmission: 'Automatic',
    rating: 4.9,
    trending: true,
    brand: 'Mercedes',
    specifications: {
      engine: '3.0L Turbo',
      power: '362 bhp',
      mileage: '11 km/l',
      fuelType: 'Petrol',
      seatingCapacity: 5
    }
  },

  // Performance Cars
  {
    id: 'porsche-911',
    name: 'Porsche 911',
    price: 18999,
    pricePerDay: 18999,
    image: 'https://images.unsplash.com/photo-1580274455191-1c62238fa333?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTB8fHBvcnNjaGUlMjA5MTF8ZW58MHx8MHx8fDA%3D',
    year: 2023,
    category: 'sports',
    categoryName: 'Sports Car',
    description: 'Iconic Porsche 911 with legendary performance.',
    transmission: 'Automatic',
    rating: 4.9,
    trending: true,
    brand: 'Porsche',
    specifications: {
      engine: '3.0L Twin-Turbo',
      power: '443 bhp',
      mileage: '9 km/l',
      fuelType: 'Petrol',
      seatingCapacity: 2
    }
  },

  // Family MPVs
  {
    id: 'innova-crysta',
    name: 'Toyota Innova Crysta',
    price: 3999,
    pricePerDay: 3999,
    image: 'https://preview.redd.it/bought-innova-crysta-recently-really-loving-the-comfort-v0-je8whdjas6b81.jpg?width=640&crop=smart&auto=webp&s=dd55a5fcdd2aed2c6685da9dc22d747214e366f5',
    year: 2023,
    category: 'suv',
    categoryName: 'Family MPV',
    description: 'Toyota Innova Crysta with premium comfort for families.',
    transmission: 'Automatic',
    rating: 4.6,
    brand: 'Toyota',
    specifications: {
      engine: '2.4L Diesel',
      power: '148 bhp',
      mileage: '13 km/l',
      fuelType: 'Diesel',
      seatingCapacity: 7
    }
  },

  // Compact SUVs
  {
    id: 'brezza',
    name: 'Maruti Brezza',
    price: 1999,
    pricePerDay: 1999,
    image: 'https://english.cdn.zeenews.com/sites/default/files/2022/08/30/1084010-brezza-modified.jpg',
    year: 2023,
    category: 'suv',
    categoryName: 'Compact SUV',
    description: 'Maruti Brezza with sporty design and features.',
    transmission: 'Automatic',
    rating: 4.4,
    trending: true,
    brand: 'Maruti',
    specifications: {
      engine: '1.5L Petrol',
      power: '103 bhp',
      mileage: '18 km/l',
      fuelType: 'Petrol',
      seatingCapacity: 5
    }
  },

  // Luxury Convertible
  {
    id: 'mercedes-sl',
    name: 'Mercedes-Benz SL',
    price: 14999,
    pricePerDay: 14999,
    image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSCXT63fQPRQTu6ymGt6fYatshFgOVSV2AyEg&s',
    year: 2023,
    category: 'convertible',
    categoryName: 'Convertible',
    description: 'Mercedes SL with retractable hardtop and luxury features.',
    transmission: 'Automatic',
    rating: 4.8,
    trending: true,
    brand: 'Mercedes',
    specifications: {
      engine: '3.0L Turbo',
      power: '362 bhp',
      mileage: '10 km/l',
      fuelType: 'Petrol',
      seatingCapacity: 2
    }
  },

  // Sports Car
  {
    id: 'audi-r8',
    name: 'Audi R8',
    price: 19999,
    pricePerDay: 19999,
    image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTlfbmfOFCIqBXixc0vWicRzLQDSk_XsccncGzOsZYOS9wc5wxdklZd8hFJ3GODiEQkGUI&usqp=CAU',
    year: 2023,
    category: 'sports',
    categoryName: 'Sports Car',
    description: 'Audi R8 with V10 engine and stunning performance.',
    transmission: 'Automatic',
    rating: 4.9,
    trending: true,
    brand: 'Audi',
    specifications: {
      engine: '5.2L V10',
      power: '562 bhp',
      mileage: '8 km/l',
      fuelType: 'Petrol',
      seatingCapacity: 2
    }
  },

  // Luxury Sedan
  {
    id: 'audi-a8',
    name: 'Audi A8 L',
    price: 9999,
    pricePerDay: 9999,
    image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSAvVH_16udLpiUMFBoTNSSkLgYrGscqU91ow&s',
    year: 2023,
    category: 'luxury',
    categoryName: 'Luxury Sedan',
    description: 'Audi A8 L with executive luxury and advanced technology.',
    transmission: 'Automatic',
    rating: 4.8,
    trending: true,
    brand: 'Audi',
    specifications: {
      engine: '3.0L Turbo',
      power: '335 bhp',
      mileage: '12 km/l',
      fuelType: 'Petrol',
      seatingCapacity: 5
    }
  }
];