import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

const SplashScreen = ({ onFinish }: { onFinish: () => void }) => {
  const navigate = useNavigate();

  // This effect will simulate a splash screen delay (e.g., 3 seconds)
  useEffect(() => {
    const timer = setTimeout(() => {
      onFinish();  // Finish splash and close it
      navigate('/login');  // Redirect to login or another page after splash
    }, 3000);  // Adjust this duration as needed

    // Cleanup the timer if the component is unmounted
    return () => clearTimeout(timer);
  }, [onFinish, navigate]);

  return (
    <div>
      <h1>Welcome to WealthSync</h1>
      <p>Loading...</p>
      {/* Add splash screen styling/animation here */}
    </div>
  );
};

export default SplashScreen;
