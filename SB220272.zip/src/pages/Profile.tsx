import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  User, Settings, Car, Heart, CalendarCheck, LogOut, 
  ChevronRight, Mail, Phone, MapPin, Edit, Save, Trash2,
  Star, CheckCircle, MessageCircle
} from 'lucide-react';
import { AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { mockCars } from '@/data/cars';
import { CarType } from '@/types/car';
import { Link } from 'react-router-dom';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { useTheme } from '@/hooks/use-theme';

const Profile = () => {
  const { toast } = useToast();
  const { colorScheme } = useTheme();
  const [activeTab, setActiveTab] = useState("profile");
  const [editMode, setEditMode] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [bookingsView, setBookingsView] = useState<'upcoming' | 'past' | 'cancelled'>('upcoming');
  const [showProfileMenu, setShowProfileMenu] = useState(false);

  // User profile state
  const [profile, setProfile] = useState({
    name: "Preetham R",
    email: "rahul.kumar@example.com",
    phone: "+91 98765 43210",
    address: "123 Main Street, Bangalore, Karnataka",
    bio: "Car enthusiast and frequent traveler. I love exploring new places with luxury cars.",
    profileImage: "https://images.unsplash.com/photo-1542362567-b07e54358753?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NDd8fGNhcnxlbnwwfHwwfHx8MA%3D%3D",
    dateJoined: "March 2023",
    notifications: {
      email: true,
      sms: true,
      app: true,
      marketing: false
    },
    preferences: {
      carTypes: ["luxury", "sports"],
      drivingExperience: "intermediate",
      preferredLocations: ["Bangalore", "Mumbai", "Delhi"],
      paymentMethod: "card"
    }
  });

  // Example data - We need to ensure favorites have pricePerDay
  const favoriteData = [
    {
      id: "1",
      car: { ...mockCars[0], pricePerDay: 15000 },
      dateAdded: "2024-02-15"
    },
    {
      id: "2",
      car: { ...mockCars[1], pricePerDay: 18000 },
      dateAdded: "2024-03-01"
    },
    {
      id: "3",
      car: { ...mockCars[2], pricePerDay: 22000 },
      dateAdded: "2024-03-10"
    }
  ];

  const bookingsData = [
    {
      id: "B12345",
      car: mockCars[0],
      startDate: "2024-04-10",
      endDate: "2024-04-15",
      status: "confirmed",
      totalPrice: 25000,
      location: "Bangalore",
      payment: {
        method: "card",
        status: "paid"
      }
    },
    {
      id: "B12346",
      car: mockCars[3],
      startDate: "2024-05-01",
      endDate: "2024-05-03",
      status: "pending",
      totalPrice: 15000,
      location: "Mumbai",
      payment: {
        method: "wallet",
        status: "pending"
      }
    },
    {
      id: "B12347",
      car: mockCars[1],
      startDate: "2024-05-01",
      endDate: "2024-05-05",
      status: "confirmed",
      totalPrice: 30000,
      location: "Mumbai",
      payment: {
        method: "card",
        status: "paid"
      }
    },
    {
      id: "B12348",
      car: mockCars[2],
      startDate: "2024-06-10",
      endDate: "2024-06-15",
      status: "pending",
      totalPrice: 35000,
      location: "Delhi",
      payment: {
        method: "card",
        status: "unpaid"
      }
    },
    {
      id: "B12349",
      car: mockCars[3],
      startDate: "2024-07-20",
      endDate: "2024-07-25",
      status: "cancelled",
      totalPrice: 40000,
      location: "Chennai",
      payment: {
        method: "card",
        status: "refunded"
      }
    },
    {
      id: "B12348",
      car: mockCars[4],
      startDate: "2024-01-15",
      endDate: "2024-01-18",
      status: "cancelled",
      totalPrice: 18000,
      location: "Goa",
      payment: {
        method: "card",
        status: "refunded"
      }
    }
  ];

  const userReviews = [
    {
      id: "R1001",
      car: mockCars[0],
      date: "2024-03-15",
      rating: 5,
      content: "Amazing experience with this car. The performance was exceptional and the rental process was smooth.",
      likes: 12
    },
    {
      id: "R1002",
      car: mockCars[3],
      date: "2024-02-20",
      rating: 4,
      content: "Great car, very comfortable for long drives. The pickup and drop-off process was quick and efficient.",
      likes: 8
    }
  ];

  const notificationHistory = [
    {
      id: "N1001",
      title: "Booking Confirmed",
      content: "Your booking for BMW 7 Series has been confirmed.",
      date: "2024-03-20",
      read: true,
      type: "booking"
    },
    {
      id: "N1002",
      title: "Special Offer",
      content: "Enjoy 20% off on your next weekend booking!",
      date: "2024-03-15",
      read: false,
      type: "promotion"
    },
    {
      id: "N1003",
      title: "Booking Reminder",
      content: "Your booking for Mercedes-Benz S-Class starts tomorrow.",
      date: "2024-03-10",
      read: true,
      type: "reminder"
    }
  ];

  const upcomingBookings = bookingsData.filter(booking => booking.status === "confirmed" || booking.status === "pending");
  const pastBookings = bookingsData.filter(booking => booking.status === "completed");
  const cancelledBookings = bookingsData.filter(booking => booking.status === "cancelled");

  const handleProfileUpdate = () => {
    setEditMode(false);
    toast({
      title: "Profile Updated",
      description: "Your profile information has been updated successfully."
    });
  };

  const handleDeleteAccount = () => {
    setConfirmDelete(false);
    toast({
      title: "Account Deleted",
      description: "Your account has been deleted successfully. You will be logged out in 5 seconds.",
      variant: "destructive"
    });
    // In a real app, we would redirect to home page after a timeout
  };

  const handleRemoveFavorite = (id: string) => {
    // In a real app, we would update the state
    toast({
      title: "Car Removed",
      description: "Car has been removed from your favorites."
    });
  };

  const handleCancelBooking = (id: string) => {
    // In a real app, we would update the booking status
    toast({
      title: "Booking Cancelled",
      description: "Your booking has been cancelled successfully."
    });
  };

  const handleNotificationSettingChange = (setting: string, value: boolean) => {
    setProfile(prev => ({
      ...prev,
      notifications: {
        ...prev.notifications,
        [setting]: value
      }
    }));
    toast({
      title: "Notification Settings Updated",
      description: `${setting.charAt(0).toUpperCase() + setting.slice(1)} notifications ${value ? 'enabled' : 'disabled'}.`
    });
  };

  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { 
      opacity: 1,
      transition: { 
        when: "beforeChildren",
        staggerChildren: 0.1
      } 
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { 
      y: 0, 
      opacity: 1,
      transition: { duration: 0.4 }
    }
  };

  return (
    <main className="min-h-screen pt-20 pb-12">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row gap-6">
          {/* Sidebar - Mobile */}
          <div className="md:hidden relative mb-4">
            <Button 
              variant="outline" 
              className="w-full flex justify-between items-center"
              onClick={() => setShowProfileMenu(!showProfileMenu)}
            >
              <div className="flex items-center">
                <User className="h-5 w-5 mr-2" />
                <span>{activeTab.charAt(0).toUpperCase() + activeTab.slice(1)}</span>
              </div>
              <ChevronRight className={`h-5 w-5 transition-transform ${showProfileMenu ? 'rotate-90' : ''}`} />
            </Button>
            
            <AnimatePresence>
              {showProfileMenu && (
                <motion.div 
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="absolute top-full left-0 right-0 mt-2 z-20 bg-card border rounded-lg shadow-lg"
                >
                  <div className="flex flex-col p-2">
                    {[
                      { id: "profile", label: "Profile", icon: User },
                      { id: "bookings", label: "My Bookings", icon: CalendarCheck },
                      { id: "favorites", label: "Favorites", icon: Heart },
                      { id: "reviews", label: "Reviews", icon: Star },
                      { id: "settings", label: "Settings", icon: Settings }
                    ].map(item => (
                      <Button 
                        key={item.id} 
                        variant={activeTab === item.id ? "secondary" : "ghost"} 
                        className="justify-start mb-1"
                        onClick={() => {
                          setActiveTab(item.id);
                          setShowProfileMenu(false);
                        }}
                      >
                        <item.icon className="h-5 w-5 mr-2" />
                        {item.label}
                      </Button>
                    ))}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Sidebar - Desktop */}
          <div className="hidden md:block w-64 shrink-0">
            <Card>
              <CardHeader className="text-center">
                <Avatar className="h-24 w-24 mx-auto mb-4">
                  <AvatarImage src={profile.profileImage} alt={profile.name} />
                  <AvatarFallback>{profile.name.charAt(0)}</AvatarFallback>
                </Avatar>
                <CardTitle>{profile.name}</CardTitle>
                <CardDescription>Member since {profile.dateJoined}</CardDescription>
              </CardHeader>
              <CardContent className="flex flex-col gap-1">
                {[
                  { id: "profile", label: "Profile", icon: User },
                  { id: "bookings", label: "My Bookings", icon: CalendarCheck },
                  { id: "favorites", label: "Favorites", icon: Heart },
                  { id: "reviews", label: "Reviews", icon: Star },
                  { id: "settings", label: "Settings", icon: Settings }
                ].map(item => (
                  <Button 
                    key={item.id} 
                    variant={activeTab === item.id ? "secondary" : "ghost"} 
                    className="justify-start"
                    onClick={() => setActiveTab(item.id)}
                  >
                    <item.icon className="h-5 w-5 mr-2" />
                    {item.label}
                  </Button>
                ))}
                <Button variant="ghost" className="justify-start text-destructive hover:text-destructive/90 mt-6">
                  <LogOut className="h-5 w-5 mr-2" />
                  Logout
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="flex-1">
            {/* Profile Tab */}
            {activeTab === "profile" && (
              <motion.div
                variants={containerVariants}
                initial="hidden"
                animate="visible"
              >
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between">
                    <div>
                      <CardTitle>Personal Information</CardTitle>
                      <CardDescription>Update your personal details</CardDescription>
                    </div>
                    <Button 
                      variant={editMode ? "default" : "outline"} 
                      size="sm"
                      onClick={() => setEditMode(!editMode)}
                    >
                      {editMode ? (
                        <>
                          <Save className="h-4 w-4 mr-2" />
                          Save
                        </>
                      ) : (
                        <>
                          <Edit className="h-4 w-4 mr-2" />
                          Edit
                        </>
                      )}
                    </Button>
                  </CardHeader>
                  <CardContent>
                    <motion.div 
                      variants={itemVariants}
                      className="grid md:grid-cols-2 gap-6"
                    >
                      <div>
                        <Label htmlFor="name">Full Name</Label>
                        <Input 
                          id="name" 
                          value={profile.name} 
                          disabled={!editMode}
                          onChange={(e) => setProfile({...profile, name: e.target.value})}
                          className="mt-1"
                        />
                      </div>
                      <div>
                        <Label htmlFor="email">Email</Label>
                        <Input 
                          id="email" 
                          type="email" 
                          value={profile.email} 
                          disabled={!editMode}
                          onChange={(e) => setProfile({...profile, email: e.target.value})}
                          className="mt-1"
                        />
                      </div>
                      <div>
                        <Label htmlFor="phone">Phone</Label>
                        <Input 
                          id="phone" 
                          value={profile.phone} 
                          disabled={!editMode}
                          onChange={(e) => setProfile({...profile, phone: e.target.value})}
                          className="mt-1"
                        />
                      </div>
                      <div>
                        <Label htmlFor="address">Address</Label>
                        <Input 
                          id="address" 
                          value={profile.address} 
                          disabled={!editMode}
                          onChange={(e) => setProfile({...profile, address: e.target.value})}
                          className="mt-1"
                        />
                      </div>
                      <div className="md:col-span-2">
                        <Label htmlFor="bio">Bio</Label>
                        <Textarea 
                          id="bio" 
                          value={profile.bio} 
                          disabled={!editMode}
                          onChange={(e) => setProfile({...profile, bio: e.target.value})}
                          className="mt-1"
                          rows={4}
                        />
                      </div>
                    </motion.div>

                    <motion.div 
                      variants={itemVariants}
                      className="mt-6"
                    >
                      <h3 className="text-lg font-semibold mb-3">Driver Preferences</h3>
                      <div className="grid md:grid-cols-2 gap-6">
                        <div>
                          <Label htmlFor="car-types">Preferred Car Types</Label>
                          <Select 
                            disabled={!editMode}
                            value={profile.preferences.carTypes.join(',')}
                            onValueChange={(value) => setProfile({
                              ...profile, 
                              preferences: {
                                ...profile.preferences,
                                carTypes: value.split(',')
                              }
                            })}
                          >
                            <SelectTrigger id="car-types" className="mt-1">
                              <SelectValue placeholder="Select car types" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="luxury,sports">Luxury & Sports</SelectItem>
                              <SelectItem value="luxury,suv">Luxury & SUV</SelectItem>
                              <SelectItem value="sports,electric">Sports & Electric</SelectItem>
                              <SelectItem value="luxury,sports,suv">All Premium Cars</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div>
                          <Label htmlFor="driving-exp">Driving Experience</Label>
                          <Select 
                            disabled={!editMode}
                            value={profile.preferences.drivingExperience}
                            onValueChange={(value) => setProfile({
                              ...profile, 
                              preferences: {
                                ...profile.preferences,
                                drivingExperience: value
                              }
                            })}
                          >
                            <SelectTrigger id="driving-exp" className="mt-1">
                              <SelectValue placeholder="Select experience level" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="beginner">Beginner (0-2 years)</SelectItem>
                              <SelectItem value="intermediate">Intermediate (3-5 years)</SelectItem>
                              <SelectItem value="experienced">Experienced (5+ years)</SelectItem>
                              <SelectItem value="professional">Professional Driver</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div>
                          <Label htmlFor="preferred-locations">Preferred Locations</Label>
                          <Select 
                            disabled={!editMode}
                            value={profile.preferences.preferredLocations.join(',')}
                            onValueChange={(value) => setProfile({
                              ...profile, 
                              preferences: {
                                ...profile.preferences,
                                preferredLocations: value.split(',')
                              }
                            })}
                          >
                            <SelectTrigger id="preferred-locations" className="mt-1">
                              <SelectValue placeholder="Select preferred locations" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="Bangalore,Mumbai,Delhi">Bangalore, Mumbai, Delhi</SelectItem>
                              <SelectItem value="Mumbai,Delhi,Goa">Mumbai, Delhi, Goa</SelectItem>
                              <SelectItem value="Bangalore,Chennai,Hyderabad">Bangalore, Chennai, Hyderabad</SelectItem>
                              <SelectItem value="Goa,Kerala,Maharashtra">Goa, Kerala, Maharashtra</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div>
                          <Label htmlFor="payment-method">Preferred Payment Method</Label>
                          <Select 
                            disabled={!editMode}
                            value={profile.preferences.paymentMethod}
                            onValueChange={(value) => setProfile({
                              ...profile, 
                              preferences: {
                                ...profile.preferences,
                                paymentMethod: value
                              }
                            })}
                          >
                            <SelectTrigger id="payment-method" className="mt-1">
                              <SelectValue placeholder="Select payment method" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="card">Credit/Debit Card</SelectItem>
                              <SelectItem value="upi">UPI</SelectItem>
                              <SelectItem value="netbanking">Net Banking</SelectItem>
                              <SelectItem value="wallet">Digital Wallet</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    </motion.div>
                  </CardContent>
                  <CardFooter className="flex justify-between border-t px-6 py-4">
                    <Button 
                      variant="default" 
                      onClick={handleProfileUpdate}
                      disabled={!editMode}
                    >
                      Update Profile
                    </Button>
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button variant="destructive">Delete Account</Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Are you sure?</DialogTitle>
                          <DialogDescription>
                            This action cannot be undone. This will permanently delete your account and all associated data.
                          </DialogDescription>
                        </DialogHeader>
                        <div className="flex justify-end gap-2 mt-4">
                          <Button variant="outline" onClick={() => setConfirmDelete(false)}>Cancel</Button>
                          <Button variant="destructive" onClick={handleDeleteAccount}>Delete Account</Button>
                        </div>
                      </DialogContent>
                    </Dialog>
                  </CardFooter>
                </Card>
              </motion.div>
            )}

            {/* Bookings Tab */}
            {activeTab === "bookings" && (
              <motion.div
                variants={containerVariants}
                initial="hidden"
                animate="visible"
              >
                <Card>
                  <CardHeader>
                    <CardTitle>My Bookings</CardTitle>
                    <CardDescription>Manage your car bookings</CardDescription>
                    <Tabs defaultValue="upcoming" className="mt-3">
                      <TabsList className="w-full sm:w-auto">
                        <TabsTrigger 
                          value="upcoming" 
                          onClick={() => setBookingsView('upcoming')}
                          className="flex-1"
                        >
                          Upcoming ({upcomingBookings.length})
                        </TabsTrigger>
                        <TabsTrigger 
                          value="past" 
                          onClick={() => setBookingsView('past')}
                          className="flex-1"
                        >
                          Past ({pastBookings.length})
                        </TabsTrigger>
                        <TabsTrigger 
                          value="cancelled" 
                          onClick={() => setBookingsView('cancelled')}
                          className="flex-1"
                        >
                          Cancelled ({cancelledBookings.length})
                        </TabsTrigger>
                      </TabsList>
                    </Tabs>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {(bookingsView === 'upcoming' ? upcomingBookings : 
                        bookingsView === 'past' ? pastBookings : cancelledBookings).map((booking) => (
                        <motion.div 
                          key={booking.id}
                          variants={itemVariants}
                          className="border rounded-lg p-4"
                        >
                          <div className="flex flex-col md:flex-row gap-4">
                            <div className="w-full md:w-1/4 lg:w-1/5">
                              <div className="aspect-[16/10] rounded-md overflow-hidden">
                                <img 
                                  src={booking.car.image} 
                                  alt={booking.car.name} 
                                  className="w-full h-full object-cover"
                                />
                              </div>
                            </div>
                            <div className="flex-1 space-y-3">
                              <div className="flex justify-between">
                                <h3 className="font-semibold">{booking.car.name}</h3>
                                <Badge 
                                  variant={
                                    booking.status === 'confirmed' ? 'default' : 
                                    booking.status === 'pending' ? 'outline' : 
                                    booking.status === 'completed' ? 'secondary' : 'destructive'
                                  }
                                >
                                  {booking.status.charAt(0).toUpperCase() + booking.status.slice(1)}
                                </Badge>
                              </div>
                              <div className="grid grid-cols-2 sm:grid-cols-3 gap-y-2 text-sm">
                                <div>
                                  <span className="text-muted-foreground">Booking ID:</span>
                                  <p>{booking.id}</p>
                                </div>
                                <div>
                                  <span className="text-muted-foreground">Start Date:</span>
                                  <p>{booking.startDate}</p>
                                </div>
                                <div>
                                  <span className="text-muted-foreground">End Date:</span>
                                  <p>{booking.endDate}</p>
                                </div>
                                <div>
                                  <span className="text-muted-foreground">Location:</span>
                                  <p>{booking.location}</p>
                                </div>
                                <div>
                                  <span className="text-muted-foreground">Total:</span>
                                  <p>₹{booking.totalPrice}</p>
                                </div>
                                <div>
                                  <span className="text-muted-foreground">Payment:</span>
                                  <p className="capitalize">{booking.payment.status}</p>
                                </div>
                              </div>
                              <div className="pt-2 flex flex-wrap gap-2">
                                <Link to={`/car/${booking.car.id}`}>
                                  <Button variant="outline" size="sm">
                                    View Car
                                  </Button>
                                </Link>
                                {booking.status === 'confirmed' && (
                                  <Button 
                                    variant="secondary" 
                                    size="sm"
                                    onClick={() => handleCancelBooking(booking.id)}
                                  >
                                    Cancel Booking
                                  </Button>
                                )}
                                {booking.status === 'completed' && (
                                  <Button variant="outline" size="sm">
                                    <Star className="h-4 w-4 mr-1" />
                                    Write Review
                                  </Button>
                                )}
                                <Button variant="outline" size="sm">
                                  Download Invoice
                                </Button>
                              </div>
                            </div>
                          </div>
                        </motion.div>
                      ))}
                      
                      {/* Empty state */}
                      {(bookingsView === 'upcoming' && upcomingBookings.length === 0) || 
                       (bookingsView === 'past' && pastBookings.length === 0) ||
                       (bookingsView === 'cancelled' && cancelledBookings.length === 0) ? (
                        <motion.div 
                          variants={itemVariants}
                          className="text-center py-12"
                        >
                          <div className="inline-flex h-20 w-20 rounded-full bg-muted items-center justify-center mb-6">
                            <CalendarCheck className="h-10 w-10 text-muted-foreground" />
                          </div>
                          <h3 className="text-lg font-medium mb-2">No bookings found</h3>
                          <p className="text-muted-foreground mb-6">
                            {bookingsView === 'upcoming' ? 
                              "You don't have any upcoming bookings." : 
                              bookingsView === 'past' ? 
                              "You don't have any past bookings." : 
                              "You don't have any cancelled bookings."}
                          </p>
                          <Link to="/explore">
                            <Button>Explore Cars</Button>
                          </Link>
                        </motion.div>
                      ) : null}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            )}

            {/* Favorites Tab */}
            {activeTab === "favorites" && (
              <motion.div
                variants={containerVariants}
                initial="hidden"
                animate="visible"
              >
                <Card>
                  <CardHeader>
                    <CardTitle>My Favorites</CardTitle>
                    <CardDescription>Cars you've saved to your wishlist</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {favoriteData.map((item) => (
                        <motion.div 
                          key={item.id}
                          variants={itemVariants}
                          className="border rounded-lg overflow-hidden hover:shadow-md transition-shadow"
                        >
                          <div className="aspect-video relative">
                            <img 
                              src={item.car.image} 
                              alt={item.car.name} 
                              className="w-full h-full object-cover"
                            />
                            <Button 
                              variant="secondary" 
                              size="icon" 
                              className="absolute top-2 right-2 rounded-full bg-background/80 backdrop-blur-sm hover:bg-destructive hover:text-white"
                              onClick={() => handleRemoveFavorite(item.id)}
                            >
                              <Heart className="h-4 w-4 fill-current" />
                            </Button>
                          </div>
                          <div className="p-3">
                            <h3 className="font-medium">{item.car.name}</h3>
                            <div className="flex justify-between items-center mt-1">
                              <p className="text-sm text-muted-foreground">
                                Added: {item.dateAdded}
                              </p>
                              <p className="font-semibold">
                                ₹{item.car.pricePerDay}/day
                              </p>
                            </div>
                            <div className="mt-3">
                              <Link to={`/car/${item.car.id}`}>
                                <Button variant="outline" size="sm" className="w-full">
                                  View Details
                                </Button>
                              </Link>
                            </div>
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            )}

            {/* Reviews Tab */}
            {activeTab === "reviews" && (
              <motion.div
                variants={containerVariants}
                initial="hidden"
                animate="visible"
              >
                <Card>
                  <CardHeader>
                    <CardTitle>My Reviews</CardTitle>
                    <CardDescription>Reviews you've written for cars</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {userReviews.map((review) => (
                        <motion.div 
                          key={review.id}
                          variants={itemVariants}
                          className="border rounded-lg p-4"
                        >
                          <div className="flex flex-col md:flex-row gap-4">
                            <div className="w-full md:w-1/4 lg:w-1/5">
                              <div className="aspect-[16/10] rounded-md overflow-hidden">
                                <img 
                                  src={review.car.image} 
                                  alt={review.car.name} 
                                  className="w-full h-full object-cover"
                                />
                              </div>
                            </div>
                            <div className="flex-1">
                              <h3 className="font-semibold">{review.car.name}</h3>
                              <div className="flex items-center gap-1 my-1">
                                {[...Array(5)].map((_, i) => (
                                  <Star 
                                    key={i} 
                                    className={`h-4 w-4 ${i < review.rating ? 'text-yellow-500 fill-yellow-500' : 'text-gray-300'}`} 
                                  />
                                ))}
                                <span className="text-sm ml-1">{review.date}</span>
                              </div>
                              <p className="text-sm mt-1">{review.content}</p>
                              <div className="mt-3 flex justify-between items-center">
                                <span className="text-sm text-muted-foreground">
                                  {review.likes} people found this helpful
                                </span>
                                <div className="flex gap-2">
                                  <Button variant="outline" size="sm">Edit</Button>
                                  <Button variant="outline" size="sm" className="text-destructive">Delete</Button>
                                </div>
                              </div>
                            </div>
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            )}

            {/* Settings Tab */}
            {activeTab === "settings" && (
              <motion.div
                variants={containerVariants}
                initial="hidden"
                animate="visible"
              >
                <Card className="mb-6">
                  <CardHeader>
                    <CardTitle>Notification Settings</CardTitle>
                    <CardDescription>Manage how you receive notifications</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <motion.div variants={itemVariants} className="space-y-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="font-medium">Email Notifications</h3>
                          <p className="text-sm text-muted-foreground">Receive booking updates via email</p>
                        </div>
                        <Switch 
                          checked={profile.notifications.email}
                          onCheckedChange={(checked) => handleNotificationSettingChange('email', checked)}
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="font-medium">SMS Notifications</h3>
                          <p className="text-sm text-muted-foreground">Receive booking updates via SMS</p>
                        </div>
                        <Switch 
                          checked={profile.notifications.sms}
                          onCheckedChange={(checked) => handleNotificationSettingChange('sms', checked)}
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="font-medium">App Notifications</h3>
                          <p className="text-sm text-muted-foreground">Receive in-app notifications</p>
                        </div>
                        <Switch 
                          checked={profile.notifications.app}
                          onCheckedChange={(checked) => handleNotificationSettingChange('app', checked)}
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="font-medium">Marketing Communications</h3>
                          <p className="text-sm text-muted-foreground">Receive offers and updates about new cars</p>
                        </div>
                        <Switch 
                          checked={profile.notifications.marketing}
                          onCheckedChange={(checked) => handleNotificationSettingChange('marketing', checked)}
                        />
                      </div>
                    </motion.div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader>
                    <CardTitle>Recent Notifications</CardTitle>
                    <CardDescription>Your latest notifications</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <motion.div variants={itemVariants} className="space-y-4">
                      {notificationHistory.map((notification) => (
                        <div 
                          key={notification.id}
                          className={`p-3 border rounded-lg ${notification.read ? '' : 'bg-muted/20 border-primary/20'}`}
                        >
                          <div className="flex justify-between">
                            <h3 className="font-medium">{notification.title}</h3>
                            <Badge 
                              variant="outline"
                              className={notification.type === 'booking' ? 'border-green-500 text-green-500' : 
                                notification.type === 'promotion' ? 'border-orange text-orange' : 
                                'border-blue-500 text-blue-500'}
                            >
                              {notification.type}
                            </Badge>
                          </div>
                          <p className="text-sm mt-1">{notification.content}</p>
                          <p className="text-xs text-muted-foreground mt-2">{notification.date}</p>
                        </div>
                      ))}
                    </motion.div>
                  </CardContent>
                </Card>
              </motion.div>
            )}
          </div>
        </div>
      </div>
    </main>
  );
};

export default Profile;
