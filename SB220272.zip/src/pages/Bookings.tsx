
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Calendar, MapPin, Clock, X, Filter, PlusCircle, Car, ArrowRight, CheckCircle, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { mockCars } from '@/data/cars';
import { useToast } from '@/hooks/use-toast';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Link } from 'react-router-dom';
import { Card, CardContent } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import ScrollToTop from '@/components/common/ScrollToTop';

interface Booking {
  id: string;
  car: {
    id: string;
    name: string;
    image: string;
    categoryName: string;
    price: number;
  };
  startDate: Date;
  endDate: Date;
  pickupLocation: string;
  dropLocation: string;
  totalPrice: number;
  status: 'active' | 'upcoming' | 'completed' | 'cancelled';
  completionStage?: number;
  nextAction?: string | null;
}

const loadBookings = (): Booking[] => {
  try {
    const bookings = JSON.parse(localStorage.getItem('bookings') || '[]');
    return bookings.map((booking: Booking) => ({
      ...booking,
      startDate: new Date(booking.startDate),
      endDate: new Date(booking.endDate),
      status: booking.status || 'active',
      completionStage: booking.completionStage || 1,
      nextAction: booking.nextAction || 'Complete Payment'
    }));
  } catch (error) {
    return [];
  }
};

const Bookings = () => {
  const { toast } = useToast();
  const [activeFilter, setActiveFilter] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const loadedBookings = loadBookings();
    setBookings(loadedBookings);
    setIsLoading(false);
  }, []);

  const handleCancelBooking = (bookingId: string) => {
    try {
      const updatedBookings = bookings.filter(b => b.id !== bookingId);
      localStorage.setItem('bookings', JSON.stringify(updatedBookings));
      setBookings(updatedBookings);
      
      toast({
        title: "Booking Cancelled",
        description: "Your booking has been successfully cancelled",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to cancel booking",
        variant: "destructive"
      });
    }
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('en-US', {
      day: 'numeric',
      month: 'short',
      year: 'numeric'
    });
  };


  const handleNextStep = (booking: Booking) => {
    toast({
      title: `Processing: ${booking.nextAction}`,
      description: "Preparing next step for your booking",
    });
  };

  const getStatusBadgeClass = (status: string) => {
    switch (status) {
      case 'active':
        return 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400';
      case 'upcoming':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400';
      case 'completed':
        return 'bg-gray-100 text-gray-800 dark:bg-gray-800/50 dark:text-gray-300';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-800/50 dark:text-gray-300';
    }
  };

  const getProgressColor = (status: string) => {
    switch (status) {
      case 'active':
        return 'bg-green-500';
      case 'upcoming':
        return 'bg-blue-500';
      case 'completed':
        return 'bg-gray-500';
      default:
        return 'bg-gray-500';
    }
  };

  const filteredBookings = bookings.filter(booking => {
    const matchesStatus = activeFilter === 'all' || booking.status === activeFilter;
    const car = booking.car;
    
    if (!car) return false;
    
    const matchesSearch = car.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          booking.pickupLocation.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          booking.dropLocation.toLowerCase().includes(searchQuery.toLowerCase());
    
    return matchesStatus && matchesSearch;
  });

  return (
    <main className="pt-24 pb-24">
      <div className="container mx-auto px-4">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">My Bookings</h1>
          <p className="text-muted-foreground">
            Track and manage your car rental bookings
          </p>
        </div>
        
        <div className="flex flex-col md:flex-row gap-4 mb-8">
          <div className="md:w-2/3">
            <Tabs value={activeFilter} onValueChange={setActiveFilter} className="w-full">
              <TabsList className="w-full">
                <TabsTrigger value="all" className="flex-1">All Bookings</TabsTrigger>
                <TabsTrigger value="active" className="flex-1">Active</TabsTrigger>
                <TabsTrigger value="upcoming" className="flex-1">Upcoming</TabsTrigger>
                <TabsTrigger value="completed" className="flex-1">Completed</TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
          
          <div className="md:w-1/3 flex gap-2">
            <Input
              placeholder="Search bookings..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full"
            />
          </div>
        </div>
        
        <div className="space-y-6">
          {filteredBookings.length > 0 ? (
            filteredBookings.map((booking, index) => {
              const car = booking.car;
              if (!car) return null;
              
              return (
                <motion.div
                  key={booking.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                >
                  <Card className="overflow-hidden hover:shadow-md transition-shadow">
                    <CardContent className="p-0">
                      <div className="flex flex-col">
                        <div className="bg-muted/30 p-3 border-b">
                          <div className="flex justify-between items-center mb-1">
                            <div className="flex items-center">
                              <Badge className={getStatusBadgeClass(booking.status)}>
                                {booking.status.charAt(0).toUpperCase() + booking.status.slice(1)}
                              </Badge>
                              <span className="ml-2 text-sm text-muted-foreground">Booking ID: {booking.id}</span>
                            </div>
                            <span className="text-sm font-medium">
                              Step {booking.completionStage} of 5
                            </span>
                          </div>
                          <Progress
                            value={(booking.completionStage / 5) * 100}
                            className={`h-2 ${getProgressColor(booking.status)}`}
                          />
                        </div>
                        
                        <div className="flex flex-col md:flex-row">
                          <div 
                            className="w-full md:w-1/3 h-48 md:h-auto bg-center bg-cover"
                            style={{ backgroundImage: `url(${car.image})` }}
                          >
                            <div className="w-full h-full md:hidden flex items-center justify-center bg-black/40">
                              <div className="text-center p-4">
                                <h3 className="text-xl font-semibold text-white">{car.name}</h3>
                                <p className="text-white/80">{car.categoryName}</p>
                              </div>
                            </div>
                          </div>
                          
                          <div className="w-full md:w-2/3 p-6">
                            <div className="flex justify-between items-start mb-4">
                              <div className="hidden md:block">
                                <h3 className="text-xl font-semibold">{car.name}</h3>
                                <p className="text-muted-foreground text-sm">{car.categoryName}</p>
                              </div>
                            </div>
                            
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                              <div className="flex items-start gap-2">
                                <Calendar className="h-5 w-5 text-green-500" />
                                <div>
                                  <p className="text-sm font-medium">Rental Period</p>
                                  <p className="text-sm text-muted-foreground">
                                    {formatDate(booking.startDate)} - {formatDate(booking.endDate)}
                                  </p>
                                </div>
                              </div>
                              
                              <div className="flex items-start gap-2">
                                <Clock className="h-5 w-5 text-green-500" />
                                <div>
                                  <p className="text-sm font-medium">Rental Amount</p>
                                  <p className="text-sm text-muted-foreground">₹{booking.totalPrice.toLocaleString()}</p>
                                </div>
                              </div>
                              
                              <div className="flex items-start gap-2">
                                <MapPin className="h-5 w-5 text-green-500" />
                                <div className="flex-1">
                                  <p className="text-sm font-medium">Pickup Location</p>
                                  <p className="text-sm text-muted-foreground truncate">{booking.pickupLocation}</p>
                                </div>
                              </div>
                              
                              <div className="flex items-start gap-2">
                                <MapPin className="h-5 w-5 text-green-500" />
                                <div className="flex-1">
                                  <p className="text-sm font-medium">Drop Location</p>
                                  <p className="text-sm text-muted-foreground truncate">{booking.dropLocation}</p>
                                </div>
                              </div>
                            </div>
                            
                            {booking.status !== 'completed' && booking.nextAction && (
                              <div className="mb-4">
                                <Button
                                  className="w-full bg-green-500 hover:bg-green-600 text-white"
                                  onClick={() => handleNextStep(booking)}
                                >
                                  {booking.nextAction} <ArrowRight className="ml-2 h-4 w-4" />
                                </Button>
                              </div>
                            )}
                            
                            <div className="flex items-center justify-end gap-3">
                              <Link to={`/car/${car.id}`}>
                                <Button variant="outline" size="sm" className="text-sm">
                                  View Car
                                </Button>
                              </Link>
                              
                              <Button
                                variant="outline"
                                size="sm"
                                className="text-sm"
                                onClick={() => {
                                  toast({
                                    title: "Booking Details",
                                    description: `Details for ${car.name} booking are being prepared.`,
                                  });
                                }}
                              >
                                View Details
                              </Button>
                              
                              {booking.status !== 'completed' && (
                                <Button
                                  variant="outline"
                                  size="sm"
                                  className="flex items-center gap-1 text-destructive text-sm"
                                  onClick={() => handleCancelBooking(booking.id)}
                                >
                                  <X className="h-4 w-4" /> Cancel
                                </Button>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })
          ) : (
            <div className="py-12 text-center">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
              >
                <div className="bg-muted/30 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Car className="h-8 w-8 text-muted-foreground" />
                </div>
                <h3 className="text-xl font-semibold mb-2">No bookings found</h3>
                <p className="text-muted-foreground mb-6">
                  {searchQuery ? "No bookings match your search criteria" : "You haven't made any bookings yet"}
                </p>
                <Link to="/explore">
                  <Button className="bg-green-500 hover:bg-green-600 text-white">
                    <PlusCircle className="h-4 w-4 mr-2" />
                    Explore Cars
                  </Button>
                </Link>
              </motion.div>
            </div>
          )}
        </div>
      </div>
      
      <Link to="/explore">
        <Button className="fixed bottom-6 right-6 h-14 w-14 rounded-full shadow-lg p-0 bg-green-500 hover:bg-green-600 text-white flex items-center justify-center md:hidden z-50">
          <PlusCircle className="h-6 w-6" />
        </Button>
      </Link>
      
      {/* Scroll to top button */}
      <ScrollToTop />
    </main>
  );
};

export default Bookings;
