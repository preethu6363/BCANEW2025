import React, { useState } from 'react';
import WhyChooseUs from '@/components/home/WhyChooseUs';
import { motion } from 'framer-motion';
import Hero from '@/components/home/Hero';
import CarGallery from '@/components/car/CarGallery';
import { mockCars } from '@/data/cars';
import { useToast } from '@/hooks/use-toast';
import { CarType } from '@/types/car';

const Home = () => {
  const { toast } = useToast();
  const [bookmarkedCars, setBookmarkedCars] = useState<string[]>([]);

  const handleBookmark = (carId: string) => {
    setBookmarkedCars(prev => 
      prev.includes(carId) 
        ? prev.filter(id => id !== carId)
        : [...prev, carId]
    );
    const isBookmarked = bookmarkedCars.includes(carId);
    toast({
      title: isBookmarked ? "Removed from bookmarks" : "Added to bookmarks",
      description: `Car has been ${isBookmarked ? "removed from" : "added to"} your bookmarks`,
    });
  };

  // Get trending cars (minimum 3)
  const trendingCars = mockCars.filter(car => car.trending);
  const displayTrending = trendingCars.length >= 3 ? trendingCars : mockCars.slice(0, 3);

  // Get luxury cars for featured section
  const featuredCars = mockCars.filter(car => 
    ['bmw-7', 'audi-a8', 'mercedes-s'].includes(car.id)
  );

  return (
    <motion.main
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="min-h-screen"
    >
      <Hero />

      {/* Trending Cars Section */}
      <div className="container mx-auto px-4 py-12">
        <CarGallery 
          title="Trending Now" 
          cars={displayTrending}
          bookmarkedCars={bookmarkedCars}
          onBookmark={handleBookmark}
        />
      </div>

      {/* Why Choose Us Section */}
      <WhyChooseUs />

      {/* Featured Luxury Section */}
      {featuredCars.length > 0 && (
        <div className="container mx-auto px-4 py-12 bg-gray-50 dark:bg-gray-900">
          <CarGallery 
            title="Featured Luxury" 
            cars={featuredCars}
            bookmarkedCars={bookmarkedCars}
            onBookmark={handleBookmark}
          />
        </div>
      )}
    </motion.main>
  );
};

export default Home;
