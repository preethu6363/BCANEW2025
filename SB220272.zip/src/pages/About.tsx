
import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Card, CardContent } from '@/components/ui/card';
import { Code, BookOpen, Sparkles, Heart, Car, Map, Award, BadgeCheck, Github, Linkedin, Mail } from 'lucide-react';
import ReviewTabs from '@/components/reviews/ReviewTabs';
import ScrollToTop from '@/components/common/ScrollToTop';

const About = () => {
  return (
    <main className="pt-24 pb-24">
      <ScrollToTop />
      
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-green-500/20 to-green-700/20 py-16">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center max-w-3xl mx-auto"
          >
            <h1 className="text-4xl md:text-5xl font-bold mb-6 font-display">About LuxAuto</h1>
            <p className="text-lg text-muted-foreground mb-8">
              Redefining luxury car rentals in India with a passion for exceptional experiences
            </p>
            <div className="flex flex-wrap gap-4 justify-center">
              <Link to="/explore">
                <Button size="lg" className="rounded-full bg-green-500 hover:bg-green-600 text-white">
                  Explore Our Fleet
                </Button>
              </Link>
              <Link to="/contact">
                <Button variant="outline" size="lg" className="rounded-full">
                  Contact Us
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>
      
      {/* Our Story */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-10 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true }}
            >
              <h2 className="text-3xl font-bold mb-6 font-display">Our Story</h2>
              <p className="text-muted-foreground mb-4">
                LuxAuto began in 2023 with a vision to transform the luxury car rental experience in India. What started as a small collection of premium vehicles has now grown into one of India's premier luxury car rental services.
              </p>
              <p className="text-muted-foreground mb-4">
                Our mission is to make luxury accessible, providing exceptional vehicles paired with outstanding service. We believe that everyone deserves to experience automotive excellence, even if just for a day.
              </p>
              <p className="text-muted-foreground">
                Today, LuxAuto offers a diverse fleet of over 200 luxury, sports, and electric vehicles across 15+ cities in India, serving thousands of satisfied customers.
              </p>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true }}
              className="relative aspect-video rounded-xl overflow-hidden shadow-xl"
            >
              <img 
                src="https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?q=80&w=1883&auto=format&fit=crop" 
                alt="Luxury Car" 
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
              <div className="absolute bottom-0 left-0 right-0 p-6">
                <h3 className="text-white text-2xl font-bold mb-2">Luxury Redefined</h3>
                <p className="text-white/80">Experience our premium collection</p>
              </div>
            </motion.div>
          </div>
        </div>
      </section>
      
      {/* Meet the Developer */}
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl font-bold mb-3 font-display">Meet the Developer</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              LuxAuto is a solo passion project created by a talented developer
            </p>
          </motion.div>
          
          <div className="flex flex-col items-center">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true }}
              className="max-w-3xl w-full"
            >
              <Card className="overflow-hidden">
                <CardContent className="p-0">
                  <div className="flex flex-col md:flex-row">
                    <div className="md:w-1/3 bg-green-500 flex items-center justify-center p-10">
                      <div className="w-40 h-40 rounded-full overflow-hidden border-4 border-white">
                        <img
                          src="https://xsgames.co/randomusers/assets/avatars/male/8.jpg"
                          alt="Preetham R"
                          className="w-full h-full object-cover"
                        />
                      </div>
                    </div>
                    
                    <div className="md:w-2/3 p-8">
                      <h3 className="text-2xl font-bold mb-2">Preetham R</h3>
                      <p className="text-muted-foreground mb-1">Final Year BCA Student & Freelance Developer</p>
                      <p className="text-sm text-muted-foreground mb-4">Mid-Level Coder, Car Enthusiast</p>
                      
                      <Separator className="my-4" />
                      
                      <div className="mb-6">
                        <h4 className="font-semibold mb-2">About Me</h4>
                        <p className="text-muted-foreground">
                          I'm a passionate developer with a strong interest in creating beautiful, functional web applications. 
                          LuxAuto is my solo project that combines my love for coding with my passion for luxury automobiles. 
                          As a final year Bachelor of Computer Science student, I'm constantly learning and improving my skills 
                          through freelance work and personal projects.
                        </p>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4 mb-6">
                        <div>
                          <h4 className="font-semibold mb-2">Skills</h4>
                          <ul className="space-y-1 text-muted-foreground text-sm">
                            <li className="flex items-center gap-2">
                              <Code size={14} /> React, TypeScript, Node.js
                            </li>
                            <li className="flex items-center gap-2">
                              <Sparkles size={14} /> UI/UX Design
                            </li>
                            <li className="flex items-center gap-2">
                              <BookOpen size={14} /> Continuous Learning
                            </li>
                          </ul>
                        </div>
                        
                        <div>
                          <h4 className="font-semibold mb-2">Interests</h4>
                          <ul className="space-y-1 text-muted-foreground text-sm">
                            <li className="flex items-center gap-2">
                              <Car size={14} /> Luxury Automobiles
                            </li>
                            <li className="flex items-center gap-2">
                              <Map size={14} /> Travel & Exploration
                            </li>
                            <li className="flex items-center gap-2">
                              <Heart size={14} /> Creating Memorable Experiences
                            </li>
                          </ul>
                        </div>
                      </div>
                      
                      <div className="flex gap-3">
                        <Button variant="outline" size="sm" className="rounded-full flex items-center gap-2">
                          <Github size={16} /> GitHub
                        </Button>
                        <Button variant="outline" size="sm" className="rounded-full flex items-center gap-2">
                          <Linkedin size={16} /> LinkedIn
                        </Button>
                        <Button variant="outline" size="sm" className="rounded-full flex items-center gap-2">
                          <Mail size={16} /> Contact
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>
      </section>
      
      {/* Values */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl font-bold mb-3 font-display">Our Values</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              The principles that guide us in delivering exceptional experiences
            </p>
          </motion.div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                icon: <Award className="h-10 w-10 text-green-500" />,
                title: "Excellence",
                description: "We are committed to providing the highest quality vehicles and service in the industry."
              },
              {
                icon: <BadgeCheck className="h-10 w-10 text-green-500" />,
                title: "Reliability",
                description: "Our customers can count on us for well-maintained vehicles and dependable service."
              },
              {
                icon: <Heart className="h-10 w-10 text-green-500" />,
                title: "Passion",
                description: "We are car enthusiasts who are passionate about sharing exceptional driving experiences."
              }
            ].map((value, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="text-center"
              >
                <div className="mb-4 mx-auto bg-muted/50 w-20 h-20 rounded-full flex items-center justify-center">
                  {value.icon}
                </div>
                <h3 className="text-xl font-bold mb-3">{value.title}</h3>
                <p className="text-muted-foreground">{value.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
      
      {/* Reviews Section */}
      <ReviewTabs />
      
      {/* Call to Action */}
      <section className="py-16 bg-green-500/10">
        <div className="container mx-auto px-4 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl font-bold mb-4 font-display">Ready to Experience Luxury?</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto mb-8">
              Join thousands of satisfied customers who have discovered the joy of driving premium vehicles with LuxAuto
            </p>
            <Link to="/explore">
              <Button size="lg" className="rounded-full bg-green-500 hover:bg-green-600 text-white">
                Explore Our Fleet
              </Button>
            </Link>
          </motion.div>
        </div>
      </section>
    </main>
  );
};

export default About;

<img
  src="https://images.unsplash.com/photo-1542362567-b07e54358753?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NDd8fGNhcnxlbnwwfHwwfHx8MA%3D%3D"
  alt="Flying Car"
  className="w-full h-full object-cover"
/>
