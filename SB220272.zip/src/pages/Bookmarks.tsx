
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useToast } from '@/hooks/use-toast';
import { mockCars } from '@/data/cars';
import CarCard from '@/components/car/CarCard';

const Bookmarks = () => {
  const { toast } = useToast();
  const [bookmarkedCars, setBookmarkedCars] = useState<string[]>([]);
  
  // Filter cars that are already bookmarked (this would normally come from an API/state)
  // For demo purposes, we're showing the first 4 cars as bookmarked initially
  const initialBookmarkedCars = mockCars.slice(0, 4);

  const handleBookmark = (carId: string) => {
    setBookmarkedCars(prev => {
      if (prev.includes(carId)) {
        toast({
          title: "Removed from bookmarks",
          description: "Car has been removed from your bookmarks",
        });
        return prev.filter(id => id !== carId);
      } else {
        toast({
          title: "Added to bookmarks",
          description: "Car has been added to your bookmarks",
        });
        return [...prev, carId];
      }
    });
  };

  return (
    <main className="pt-24 pb-16">
      <div className="container mx-auto px-4">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">My Bookmarks</h1>
          <p className="text-muted-foreground">
            Your saved vehicles for quick access
          </p>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {initialBookmarkedCars.length > 0 ? (
            initialBookmarkedCars.map((car, index) => (
              <motion.div
                key={car.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <CarCard
                  car={car}
                  isBookmarked={!bookmarkedCars.includes(car.id)}
                  onBookmark={handleBookmark}
                />
              </motion.div>
            ))
          ) : (
            <div className="col-span-full py-12 text-center">
              <h3 className="text-xl font-semibold mb-2">No bookmarked cars</h3>
              <p className="text-muted-foreground">
                Start adding cars to your bookmarks from the Explore page
              </p>
            </div>
          )}
        </div>
      </div>
    </main>
  );
};

export default Bookmarks;
