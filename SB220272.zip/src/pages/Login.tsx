import { useState, useEffect } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { Eye, EyeOff, ChefHat, Mail, Lock, User as UserIcon, ArrowRight, Check, ExternalLink } from "lucide-react";
import Spline from '@splinetool/react-spline';
import PageLayout from "@/components/layout/PageLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "@/hooks/use-toast";
import { Separator } from "@/components/ui/separator";
import { useTheme } from "@/hooks/use-theme";
import { Checkbox } from "@/components/ui/checkbox";
import { useAuth } from "@/context/AContext";

const Auth = () => {
  const { theme } = useTheme();
  const { login, register, continueAsGuest, isLoading: authLoading } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [showPassword, setShowPassword] = useState(false);
  const [activeTab, setActiveTab] = useState<"login" | "signup" | "guest">("login");
  
  // Login form state
  const [loginEmail, setLoginEmail] = useState("");
  const [loginPassword, setLoginPassword] = useState("");
  const [rememberMe, setRememberMe] = useState(false);
  
  // Signup form state
  const [signupName, setSignupName] = useState("");
  const [signupEmail, setSignupEmail] = useState("");
  const [signupPassword, setSignupPassword] = useState("");
  const [signupConfirmPassword, setSignupConfirmPassword] = useState("");
  const [agreeTerms, setAgreeTerms] = useState(false);
  
  useEffect(() => {
    // Check if there's a signup parameter in the URL
    const searchParams = new URLSearchParams(location.search);
    if (searchParams.get('signup') === 'true') {
      setActiveTab('signup');
    } else if (searchParams.get('guest') === 'true') {
      setActiveTab('guest');
    }
  }, [location]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!loginEmail || !loginPassword) {
      toast({
        title: "Missing fields",
        description: "Please enter both email and password",
        variant: "destructive"
      });
      return;
    }
    
    const success = await login(loginEmail, loginPassword);
    if (success) {
      navigate('/', { replace: true });
    }
  };
  
  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (signupPassword !== signupConfirmPassword) {
      toast({
        title: "Passwords don't match",
        description: "Please make sure your passwords match.",
        variant: "destructive",
      });
      return;
    }
    
    if (!agreeTerms) {
      toast({
        title: "Terms and Conditions",
        description: "Please agree to the Terms and Conditions to continue.",
        variant: "destructive",
      });
      return;
    }
    
    const success = await register(signupName, signupEmail, signupPassword);
    if (success) {
      navigate('/', { replace: true });
    }
  };
  
  const handleGuestLogin = () => {
    continueAsGuest();
    navigate('/home');
  };
  
  const handleDemoLogin = async () => {
    const success = await login("demo@example.com", "demo123");
    if (success) {
      navigate('/', { replace: true });
    }
  };
  
  return (
    <PageLayout>
      <div className={`min-h-screen py-12 ${theme === "dark" ? "bg-gradient-to-br from-pantry-darker via-pantry-dark to-pantry-accent/20" : "bg-gradient-to-br from-gray-50 via-white to-pantry-accent/10"}`}>
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row gap-8 max-w-5xl mx-auto">
            {/* Left column with chef image and welcome text */}
            <div className="w-full md:w-5/12 flex flex-col justify-center">
              <div className={`p-8 rounded-lg ${theme === "dark" ? "bg-pantry-darker/60 backdrop-blur-md border border-pantry-muted/10" : "bg-white/75 backdrop-blur-md border border-gray-100 shadow-md"} flex flex-col items-center`}>
                <div className="w-full h-64 mb-6">
                  {/* Removed Spline animation from Login page */}
                </div>
                
                <h1 className={`text-4xl font-playfair font-bold mb-4 text-center ${theme === "dark" ? "text-pantry-light" : "text-pantry-darker"}`}>
                  Welcome to<br />LuxAuto
                </h1>
                <p className="text-pantry-muted text-center mb-6">
                  Your trusted partner for premium car rentals
                </p>
                <div className="mt-6 space-y-4 w-full">
                  <div className={`p-4 rounded-lg ${theme === "dark" ? "bg-pantry-dark/50" : "bg-gray-50"} flex items-center`}>
                    <Check size={16} className="text-green-500 mr-3 flex-shrink-0" />
                    <p className="text-sm">Wide selection of luxury vehicles</p>
                  </div>
                  <div className={`p-4 rounded-lg ${theme === "dark" ? "bg-pantry-dark/50" : "bg-gray-50"} flex items-center`}>
                    <Check size={16} className="text-green-500 mr-3 flex-shrink-0" />
                    <p className="text-sm">Flexible rental plans</p>
                  </div>
                  <div className={`p-4 rounded-lg ${theme === "dark" ? "bg-pantry-dark/50" : "bg-gray-50"} flex items-center`}>
                    <Check size={16} className="text-green-500 mr-3 flex-shrink-0" />
                    <p className="text-sm">24/7 customer support</p>
                  </div>
                </div>
              </div>
            </div>
            {/* Right column with auth forms */}
            <div className="w-full md:w-7/12">
              <div className={`p-8 rounded-lg ${theme === "dark" ? "bg-pantry-darker/80 backdrop-blur-md border border-pantry-muted/20" : "bg-white/90 backdrop-blur-md border border-gray-100 shadow-md"}`}>
                <Tabs defaultValue="login" value={activeTab} onValueChange={(value) => setActiveTab(value as "login" | "signup" | "guest")}>
                  <TabsList className="grid grid-cols-3 mb-8 w-full">
                    <TabsTrigger value="login">Login</TabsTrigger>
                    <TabsTrigger value="signup">Sign Up</TabsTrigger>
                    <TabsTrigger value="guest">Guest</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="login">
                    <form onSubmit={handleLogin} className="space-y-6">
                      <div className="space-y-2">
                        <Label htmlFor="email" className="flex items-center gap-2">
                          <Mail size={16} className="text-pantry-muted" />
                          Email Address
                        </Label>
                        <Input
                          id="email"
                          type="email"
                          placeholder="your@email.com"
                          className={`${theme === "dark" ? "bg-pantry-dark/70 border-pantry-muted/40" : "bg-gray-50 border-pantry-muted/40"}`}
                          value={loginEmail}
                          onChange={(e) => setLoginEmail(e.target.value)}
                          required
                          autoFocus
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <Label htmlFor="password" className="flex items-center gap-2">
                            <Lock size={16} className="text-pantry-muted" />
                            Password
                          </Label>
                          <Link to="#" className="text-xs text-pantry-accent hover:underline">
                            Forgot password?
                          </Link>
                        </div>
                        <div className="relative">
                          <Input
                            id="password"
                            type={showPassword ? "text" : "password"}
                            placeholder="••••••••"
                            className={`${theme === "dark" ? "bg-pantry-dark/70 border-pantry-muted/40" : "bg-gray-50 border-pantry-muted/40"} pr-10`}
                            value={loginPassword}
                            onChange={(e) => setLoginPassword(e.target.value)}
                            required
                          />
                          <Button
                            type="button"
                            onClick={() => setShowPassword((prev) => !prev)}
                            className="absolute top-1/2 right-3 transform -translate-y-1/2"
                          >
                            {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                          </Button>
                        </div>
                      </div>
                      
                      <div className="flex items-center">
                        <Checkbox
                          id="rememberMe"
                          checked={rememberMe}
                          onCheckedChange={(checked) => setRememberMe(checked === true)}
                          className="mr-3"
                        />
                        <Label htmlFor="rememberMe" className="text-sm">
                          Remember me
                        </Label>
                      </div>
                      
                      <div className="mt-6">
                        <Button type="submit" className="w-full" disabled={authLoading}>
                          {authLoading ? "Logging in..." : "Log In"}
                        </Button>
                      </div>
                    </form>
                  </TabsContent>
                  
                  <TabsContent value="signup">
                    <form onSubmit={handleSignup} className="space-y-6">
                      <div className="space-y-2">
                        <Label htmlFor="name" className="flex items-center gap-2">
                          <UserIcon size={16} className="text-pantry-muted" />
                          Name
                        </Label>
                        <Input
                          id="name"
                          placeholder="Your Name"
                          className={`${theme === "dark" ? "bg-pantry-dark/70 border-pantry-muted/40" : "bg-gray-50 border-pantry-muted/40"}`}
                          value={signupName}
                          onChange={(e) => setSignupName(e.target.value)}
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="email" className="flex items-center gap-2">
                          <Mail size={16} className="text-pantry-muted" />
                          Email Address
                        </Label>
                        <Input
                          id="email"
                          type="email"
                          placeholder="your@email.com"
                          className={`${theme === "dark" ? "bg-pantry-dark/70 border-pantry-muted/40" : "bg-gray-50 border-pantry-muted/40"}`}
                          value={signupEmail}
                          onChange={(e) => setSignupEmail(e.target.value)}
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <Label htmlFor="password" className="flex items-center gap-2">
                            <Lock size={16} className="text-pantry-muted" />
                            Password
                          </Label>
                        </div>
                        <div className="relative">
                          <Input
                            id="password"
                            type={showPassword ? "text" : "password"}
                            placeholder="••••••••"
                            className={`${theme === "dark" ? "bg-pantry-dark/70 border-pantry-muted/40" : "bg-gray-50 border-pantry-muted/40"} pr-10`}
                            value={signupPassword}
                            onChange={(e) => setSignupPassword(e.target.value)}
                            required
                          />
                          <Button
                            type="button"
                            onClick={() => setShowPassword((prev) => !prev)}
                            className="absolute top-1/2 right-3 transform -translate-y-1/2"
                          >
                            {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                          </Button>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <div className="relative">
                          <Input
                            id="confirm-password"
                            type={showPassword ? "text" : "password"}
                            placeholder="Confirm Password"
                            className={`${theme === "dark" ? "bg-pantry-dark/70 border-pantry-muted/40" : "bg-gray-50 border-pantry-muted/40"} pr-10`}
                            value={signupConfirmPassword}
                            onChange={(e) => setSignupConfirmPassword(e.target.value)}
                            required
                          />
                          <Button
                            type="button"
                            onClick={() => setShowPassword((prev) => !prev)}
                            className="absolute top-1/2 right-3 transform -translate-y-1/2"
                          >
                            {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                          </Button>
                        </div>
                      </div>
                      
                      <div className="flex items-center">
                        <Checkbox
                          id="agreeTerms"
                          checked={agreeTerms}
                          onCheckedChange={(checked) => setAgreeTerms(checked === true)}
                          className="mr-3"
                        />
                        <Label htmlFor="agreeTerms" className="text-sm">
                          I agree to the <span className="text-pantry-accent">Terms & Conditions</span>
                        </Label>
                      </div>
                      
                      <div className="mt-6">
                        <Button type="submit" className="w-full" disabled={authLoading}>
                          {authLoading ? "Signing up..." : "Sign Up"}
                        </Button>
                      </div>
                    </form>
                  </TabsContent>
                  
                  <TabsContent value="guest">
                    <div className="space-y-6">
                      <p className="text-center text-lg text-pantry-muted">
                        You can continue as a guest and explore the app, but won't have access to some features.
                      </p>
                      <Button onClick={handleGuestLogin} className="w-full">
                        Continue as Guest
                      </Button>
                    </div>
                  </TabsContent>
                </Tabs>
              </div>
            </div>
          </div>
        </div>
      </div>
    </PageLayout>
  );
};

export default Auth;
