
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Send, Star, ImagePlus, Car, ArrowLeft, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { useToast } from '@/hooks/use-toast';
import { mockCars } from '@/data/cars';
import { Link, useNavigate } from 'react-router-dom';

const SubmitTestimonial = () => {
  const { toast } = useToast();
  const navigate = useNavigate();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccessMessage, setShowSuccessMessage] = useState(false);
  const [rating, setRating] = useState(0);
  const [tempRating, setTempRating] = useState(0);
  
  // Form data state
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    carId: '',
    title: '',
    review: '',
    imageFile: null as File | null,
    imagePreview: ''
  });
  
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { 
      opacity: 1,
      transition: { staggerChildren: 0.1 }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { 
      y: 0, 
      opacity: 1,
      transition: { duration: 0.5 }
    }
  };
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };
  
  const handleSelectChange = (value: string) => {
    setFormData(prev => ({
      ...prev,
      carId: value
    }));
  };
  
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setFormData(prev => ({
        ...prev,
        imageFile: file,
        imagePreview: URL.createObjectURL(file)
      }));
    }
  };
  
  const handleStarClick = (selectedRating: number) => {
    setRating(selectedRating);
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate form
    if (!formData.name || !formData.email || !formData.carId || !formData.review || rating === 0) {
      toast({
        title: "Missing Information",
        description: "Please fill all required fields and provide a rating.",
        variant: "destructive"
      });
      return;
    }
    
    setIsSubmitting(true);
    
    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false);
      setShowSuccessMessage(true);
      
      toast({
        title: "Testimonial Submitted",
        description: "Thank you for sharing your experience with us!"
      });
      
      // Reset form after 2 seconds and redirect
      setTimeout(() => {
        setShowSuccessMessage(false);
        navigate('/testimonials');
      }, 2000);
    }, 1500);
  };
  
  // Selected car details
  const selectedCar = mockCars.find(car => car.id === formData.carId);
  
  return (
    <main className="min-h-screen pt-24 pb-16">
      <div className="container mx-auto px-4">
        {!showSuccessMessage ? (
          <>
            {/* Header */}
            <div className="mb-8">
              <Link to="/testimonials" className="flex items-center text-muted-foreground hover:text-foreground transition-colors mb-4">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Testimonials
              </Link>
              <h1 className="text-3xl md:text-4xl font-bold mb-3">Share Your Experience</h1>
              <p className="text-muted-foreground max-w-2xl">
                We value your feedback! Please share your thoughts about your recent rental experience to help others make informed decisions.
              </p>
            </div>
            
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Form Section */}
              <motion.div 
                variants={containerVariants}
                initial="hidden"
                animate="visible"
                className="lg:col-span-2"
              >
                <Card>
                  <CardHeader>
                    <CardTitle>Submit Your Review</CardTitle>
                    <CardDescription>All fields marked with * are required</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <form onSubmit={handleSubmit} className="space-y-6">
                      <motion.div variants={itemVariants} className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                          <label htmlFor="name" className="form-label form-required">Your Name</label>
                          <Input 
                            id="name"
                            name="name"
                            value={formData.name}
                            onChange={handleInputChange}
                            className="testimonial-input"
                            placeholder="Enter your full name"
                          />
                        </div>
                        <div>
                          <label htmlFor="email" className="form-label form-required">Email Address</label>
                          <Input 
                            id="email"
                            name="email"
                            type="email"
                            value={formData.email}
                            onChange={handleInputChange}
                            className="testimonial-input"
                            placeholder="Enter your email address"
                          />
                        </div>
                      </motion.div>
                      
                      <motion.div variants={itemVariants}>
                        <label htmlFor="car-select" className="form-label form-required">Car You Rented</label>
                        <Select value={formData.carId} onValueChange={handleSelectChange}>
                          <SelectTrigger id="car-select" className="testimonial-input">
                            <SelectValue placeholder="Select the car you rented" />
                          </SelectTrigger>
                          <SelectContent>
                            {mockCars.map(car => (
                              <SelectItem key={car.id} value={car.id}>
                                {car.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </motion.div>
                      
                      <motion.div variants={itemVariants}>
                        <label htmlFor="title" className="form-label">Review Title</label>
                        <Input 
                          id="title"
                          name="title"
                          value={formData.title}
                          onChange={handleInputChange}
                          className="testimonial-input"
                          placeholder="Summarize your experience in a brief title"
                        />
                        <p className="form-hint">Optional, but helps others quickly understand your experience</p>
                      </motion.div>
                      
                      <motion.div variants={itemVariants}>
                        <label className="form-label form-required">Your Rating</label>
                        <div className="flex items-center gap-1 mt-2">
                          {[1, 2, 3, 4, 5].map((star) => (
                            <Star
                              key={star}
                              className={`h-8 w-8 cursor-pointer transition-all ${
                                star <= (tempRating || rating) ? 'text-yellow-500 fill-yellow-500' : 'text-muted'
                              }`}
                              onClick={() => handleStarClick(star)}
                              onMouseEnter={() => setTempRating(star)}
                              onMouseLeave={() => setTempRating(0)}
                            />
                          ))}
                          <span className="ml-2 text-muted-foreground">
                            {rating > 0 ? `${rating} star${rating !== 1 ? 's' : ''}` : 'Select your rating'}
                          </span>
                        </div>
                      </motion.div>
                      
                      <motion.div variants={itemVariants}>
                        <label htmlFor="review" className="form-label form-required">Your Review</label>
                        <Textarea 
                          id="review"
                          name="review"
                          value={formData.review}
                          onChange={handleInputChange}
                          className="testimonial-input min-h-[150px]"
                          placeholder="Share details of your experience with this car. What did you like or dislike? Would you recommend it to others?"
                        />
                      </motion.div>
                      
                      <motion.div variants={itemVariants}>
                        <label htmlFor="image" className="form-label">Upload Photo (Optional)</label>
                        <div className="mt-2">
                          {formData.imagePreview ? (
                            <div className="relative">
                              <img 
                                src={formData.imagePreview} 
                                alt="Preview" 
                                className="w-full h-40 object-cover rounded-lg"
                              />
                              <Button
                                type="button"
                                variant="destructive"
                                size="sm"
                                className="absolute top-2 right-2"
                                onClick={() => setFormData(prev => ({ ...prev, imageFile: null, imagePreview: '' }))}
                              >
                                Remove
                              </Button>
                            </div>
                          ) : (
                            <label className="flex flex-col items-center justify-center w-full h-40 border-2 border-dashed border-muted-foreground/30 rounded-lg cursor-pointer hover:bg-muted/20 transition-colors">
                              <div className="flex flex-col items-center justify-center pt-5 pb-6">
                                <ImagePlus className="w-8 h-8 mb-4 text-muted-foreground" />
                                <p className="mb-2 text-sm text-muted-foreground">
                                  <span className="font-semibold">Click to upload</span> or drag and drop
                                </p>
                                <p className="text-xs text-muted-foreground">
                                  PNG, JPG or WEBP (MAX. 2MB)
                                </p>
                              </div>
                              <Input 
                                id="image" 
                                type="file" 
                                className="hidden" 
                                accept="image/*"
                                onChange={handleImageUpload}
                              />
                            </label>
                          )}
                        </div>
                      </motion.div>
                    </form>
                  </CardContent>
                  <CardFooter className="flex justify-between border-t pt-6">
                    <Button 
                      variant="outline" 
                      onClick={() => navigate('/testimonials')}
                    >
                      Cancel
                    </Button>
                    <Button 
                      onClick={handleSubmit} 
                      disabled={isSubmitting}
                      className="bg-orange hover:bg-orange/90 text-white"
                    >
                      {isSubmitting ? (
                        <motion.div
                          animate={{ rotate: 360 }}
                          transition={{ repeat: Infinity, duration: 1, ease: "linear" }}
                          className="mr-2 h-4 w-4 border-2 border-white border-t-transparent rounded-full"
                        />
                      ) : (
                        <Send className="mr-2 h-4 w-4" />
                      )}
                      Submit Review
                    </Button>
                  </CardFooter>
                </Card>
              </motion.div>
              
              {/* Preview Section */}
              <motion.div 
                variants={containerVariants}
                initial="hidden"
                animate="visible"
                className="lg:col-span-1"
              >
                <Card>
                  <CardHeader>
                    <CardTitle>Review Preview</CardTitle>
                    <CardDescription>Here's how your review will appear</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <motion.div variants={itemVariants} className="border rounded-lg p-4">
                      <div className="flex items-center gap-3 mb-4">
                        <Avatar>
                          <AvatarFallback>{formData.name.charAt(0) || '?'}</AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium">{formData.name || 'Your Name'}</p>
                          <p className="text-xs text-muted-foreground">Today</p>
                        </div>
                      </div>
                      
                      {selectedCar && (
                        <div className="flex items-center gap-2 mb-3 text-sm">
                          <Car className="h-4 w-4 text-muted-foreground" />
                          <span>{selectedCar.name}</span>
                        </div>
                      )}
                      
                      <div className="flex items-center gap-1 mb-3">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <Star
                            key={star}
                            className={`h-4 w-4 ${
                              star <= rating ? 'text-yellow-500 fill-yellow-500' : 'text-muted'
                            }`}
                          />
                        ))}
                      </div>
                      
                      {formData.title && (
                        <h3 className="font-medium mb-2">{formData.title}</h3>
                      )}
                      
                      <p className="text-sm text-muted-foreground mb-4">
                        {formData.review || 'Your detailed review will appear here...'}
                      </p>
                      
                      {formData.imagePreview && (
                        <div className="rounded-lg overflow-hidden mb-3">
                          <img 
                            src={formData.imagePreview} 
                            alt="Review" 
                            className="w-full h-auto object-cover"
                          />
                        </div>
                      )}
                    </motion.div>
                    
                    {/* Tips */}
                    <motion.div variants={itemVariants} className="mt-6">
                      <h3 className="font-medium mb-2">Tips for a Great Review</h3>
                      <ul className="space-y-2 text-sm text-muted-foreground">
                        <li className="flex items-start gap-2">
                          <Check className="h-4 w-4 text-green-500 mt-0.5" />
                          <span>Be specific about what you liked or disliked</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <Check className="h-4 w-4 text-green-500 mt-0.5" />
                          <span>Mention specific features of the car</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <Check className="h-4 w-4 text-green-500 mt-0.5" />
                          <span>Share your experience with the rental process</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <Check className="h-4 w-4 text-green-500 mt-0.5" />
                          <span>Keep it honest and respectful</span>
                        </li>
                      </ul>
                    </motion.div>
                  </CardContent>
                </Card>
              </motion.div>
            </div>
          </>
        ) : (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="flex flex-col items-center justify-center text-center max-w-md mx-auto py-16"
          >
            <div className="w-20 h-20 rounded-full bg-green-100 flex items-center justify-center mb-6">
              <Check className="h-10 w-10 text-green-500" />
            </div>
            <h2 className="text-2xl font-bold mb-4">Thank You for Your Feedback!</h2>
            <p className="text-muted-foreground mb-6">
              Your review has been submitted successfully. It will be published after a quick review by our team.
            </p>
            <Link to="/testimonials">
              <Button>View All Testimonials</Button>
            </Link>
          </motion.div>
        )}
      </div>
    </main>
  );
};

export default SubmitTestimonial;
