import React from 'react';
import Spline from '@splinetool/react-spline';

const PlaySection = () => {
  return (
    <div>
      <Spline scene="https://prod.spline.design/ZJDLiUHS7R5atW2N/scene.splinecode" />
    </div>
  );
};

export default PlaySection;