
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Star, ChevronLeft, ChevronRight, Quote, Send, User, Briefcase, Mail, Phone, Calendar } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { cn } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';

const testimonials = [
  {
    id: 1,
    name: "Arjun Kapoor",
    position: "Business Executive",
    image: "https://randomuser.me/api/portraits/men/32.jpg",
    rating: 5,
    text: "The BMW 7 Series rental exceeded all my expectations. The car was immaculate and the service was top-notch. I'll definitely be using LuxAuto for all my future business trips.",
    date: "15 May 2023"
  },
  {
    id: 2,
    name: "Priya Sharma",
    position: "Travel Blogger",
    image: "https://randomuser.me/api/portraits/women/44.jpg",
    rating: 5,
    text: "As a travel blogger, I've rented cars all over India, and LuxAuto offers the best electric vehicle selection by far. The Tata Nexon EV was perfect for my sustainable tourism series.",
    date: "2 June 2023"
  },
  {
    id: 3,
    name: "Rahul Mehta",
    position: "Software Engineer",
    image: "https://randomuser.me/api/portraits/men/68.jpg",
    rating: 4,
    text: "The booking process was effortless, and the car was delivered on time. The only small issue was a slight delay in pickup, but the team was very apologetic and provided excellent service otherwise.",
    date: "18 April 2023"
  },
  {
    id: 4,
    name: "Aisha Khan",
    position: "Wedding Planner",
    image: "https://randomuser.me/api/portraits/women/37.jpg",
    rating: 5,
    text: "I rented the Audi A8 for a client's wedding, and it was the perfect luxury touch. The chauffeur service was professional, and the car made for stunning photos. Highly recommend for special occasions!",
    date: "30 March 2023"
  }
];

const Testimonials = () => {
  const [activeIndex, setActiveIndex] = useState(0);
  const [submitForm, setSubmitForm] = useState(false);
  const [rating, setRating] = useState<number>(5);
  const [name, setName] = useState('');
  const [position, setPosition] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [review, setReview] = useState('');
  const [activeTab, setActiveTab] = useState('all');
  const { toast } = useToast();

  const nextTestimonial = () => {
    setActiveIndex((current) => (current + 1) % testimonials.length);
  };

  const prevTestimonial = () => {
    setActiveIndex((current) => (current - 1 + testimonials.length) % testimonials.length);
  };

  const handleSubmitReview = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!name || !position || !review) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields to submit your review.",
        variant: "destructive"
      });
      return;
    }
    
    toast({
      title: "Review Submitted",
      description: "Thank you for sharing your experience with us! Your review will be displayed after moderation.",
    });
    
    // Reset form
    setName('');
    setPosition('');
    setReview('');
    setEmail('');
    setPhone('');
    setRating(5);
    setSubmitForm(false);
  };

  const testimonial = testimonials[activeIndex];

  return (
    <main className="pt-20 pb-16">
      <div className="container mx-auto px-4">
        {/* Hero Section */}
        <div className="relative mb-16 rounded-xl overflow-hidden bg-gradient-to-r from-orange/10 via-orange/5 to-transparent dark:from-orange/20 dark:via-orange/10 dark:to-transparent">
          <div className="absolute -top-12 -right-12 text-orange/10 dark:text-orange/20">
            <Quote size={140} />
          </div>
          
          <div className="relative z-10 py-16 px-6 md:px-12">
            <motion.h1 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="text-4xl md:text-5xl font-bold mb-4 text-balance"
            >
              Customer <span className="text-orange">Experiences</span>
            </motion.h1>
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="text-lg text-muted-foreground max-w-2xl"
            >
              Read authentic stories from our valued customers and share your own LuxAuto experience
            </motion.p>
          </div>
        </div>

        {/* Featured Testimonials Carousel */}
        <div className="max-w-4xl mx-auto relative mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center mb-8"
          >
            <Badge variant="outline" className="mb-3 px-4 py-1 rounded-full border-orange/20 text-orange bg-orange/5">
              Featured Testimonials
            </Badge>
            <h2 className="text-3xl font-bold mb-2">What Our Customers Say</h2>
            <p className="text-muted-foreground">Hear from people who have experienced the LuxAuto difference</p>
          </motion.div>
          
          <div className="absolute -top-10 -left-10 text-orange opacity-10 z-0">
            <Quote size={80} />
          </div>
          
          <AnimatePresence mode="wait">
            <motion.div
              key={testimonial.id}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3 }}
              className="bg-card rounded-2xl p-8 shadow-md hover:shadow-lg transition-all relative z-10 border border-border"
            >
              <div className="flex flex-col md:flex-row gap-6">
                <div className="flex-shrink-0">
                  <Avatar className="w-20 h-20 border-2 border-orange">
                    <AvatarImage src={testimonial.image} alt={testimonial.name} />
                    <AvatarFallback className="bg-orange/20 text-orange">{testimonial.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                  </Avatar>
                </div>
                
                <div className="flex-grow">
                  <div className="flex items-center gap-2 mb-3">
                    <div className="flex">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          size={18}
                          className={cn(
                            i < testimonial.rating
                              ? "fill-orange text-orange"
                              : "text-gray-300"
                          )}
                        />
                      ))}
                    </div>
                    <Badge variant="outline" className="text-xs ml-2">
                      <Calendar className="h-3 w-3 mr-1" />
                      {testimonial.date}
                    </Badge>
                  </div>
                  
                  <p className="text-lg mb-4 italic">{testimonial.text}</p>
                  
                  <div>
                    <h4 className="font-semibold text-lg">{testimonial.name}</h4>
                    <p className="text-muted-foreground">{testimonial.position}</p>
                  </div>
                </div>
              </div>
            </motion.div>
          </AnimatePresence>
          
          <div className="flex justify-center mt-8 gap-2">
            <Button
              variant="outline"
              size="icon"
              className="rounded-full hover:bg-orange/10 hover:text-orange transition-colors"
              onClick={prevTestimonial}
            >
              <ChevronLeft className="h-5 w-5" />
            </Button>
            
            <div className="flex items-center gap-2">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setActiveIndex(index)}
                  className={`w-2 h-2 rounded-full transition-all ${
                    activeIndex === index 
                      ? 'bg-orange w-6' 
                      : 'bg-gray-300 hover:bg-gray-400'
                  }`}
                />
              ))}
            </div>
            
            <Button
              variant="outline"
              size="icon"
              className="rounded-full hover:bg-orange/10 hover:text-orange transition-colors"
              onClick={nextTestimonial}
            >
              <ChevronRight className="h-5 w-5" />
            </Button>
          </div>
        </div>
        
        {/* CTA for submitting a review */}
        <Card className="max-w-4xl mx-auto mb-16 border-orange/20 bg-gradient-to-br from-orange/5 to-transparent">
          <CardContent className="p-8">
            {!submitForm ? (
              <div className="text-center">
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3 }}
                >
                  <h2 className="text-2xl font-bold mb-4">Share Your Experience</h2>
                  <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
                    We value your feedback! Tell us about your experience with LuxAuto and help future customers make informed decisions.
                  </p>
                  <Button 
                    className="bg-orange hover:bg-orange/90 text-white"
                    onClick={() => setSubmitForm(true)}
                  >
                    Write a Review
                  </Button>
                </motion.div>
              </div>
            ) : (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
              >
                <h2 className="text-2xl font-bold mb-4 text-center">Submit Your Review</h2>
                <p className="text-center text-muted-foreground mb-6">Your honest feedback helps us improve our services</p>
                
                <form onSubmit={handleSubmitReview} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label htmlFor="name" className="flex items-center gap-2">
                        <User className="h-4 w-4 text-orange" />
                        Your Name <span className="text-red-500">*</span>
                      </Label>
                      <Input 
                        id="name" 
                        value={name} 
                        onChange={(e) => setName(e.target.value)} 
                        placeholder="John Doe"
                        className="border-orange/20 focus:border-orange"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="position" className="flex items-center gap-2">
                        <Briefcase className="h-4 w-4 text-orange" />
                        Profession/Title <span className="text-red-500">*</span>
                      </Label>
                      <Input 
                        id="position" 
                        value={position} 
                        onChange={(e) => setPosition(e.target.value)} 
                        placeholder="Business Professional, Student, etc."
                        className="border-orange/20 focus:border-orange"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="email" className="flex items-center gap-2">
                        <Mail className="h-4 w-4 text-orange" />
                        Email Address
                      </Label>
                      <Input 
                        id="email" 
                        type="email"
                        value={email} 
                        onChange={(e) => setEmail(e.target.value)} 
                        placeholder="your@email.com"
                        className="border-orange/20 focus:border-orange"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="phone" className="flex items-center gap-2">
                        <Phone className="h-4 w-4 text-orange" />
                        Phone Number
                      </Label>
                      <Input 
                        id="phone" 
                        value={phone} 
                        onChange={(e) => setPhone(e.target.value)} 
                        placeholder="+91 9876543210"
                        className="border-orange/20 focus:border-orange"
                      />
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label>Rating <span className="text-red-500">*</span></Label>
                    <div className="flex gap-1">
                      {[1, 2, 3, 4, 5].map((value) => (
                        <button
                          key={value}
                          type="button"
                          onClick={() => setRating(value)}
                          className="focus:outline-none transition-transform hover:scale-110"
                        >
                          <Star
                            size={32}
                            className={cn(
                              value <= rating
                                ? "fill-orange text-orange"
                                : "text-gray-300"
                            )}
                          />
                        </button>
                      ))}
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="review" className="flex items-center gap-2">
                      <Quote className="h-4 w-4 text-orange" />
                      Your Review <span className="text-red-500">*</span>
                    </Label>
                    <Textarea 
                      id="review" 
                      value={review} 
                      onChange={(e) => setReview(e.target.value)} 
                      placeholder="Share your experience with LuxAuto..."
                      rows={5}
                      className="border-orange/20 focus:border-orange"
                    />
                    <p className="text-xs text-muted-foreground">Fields marked with <span className="text-red-500">*</span> are required</p>
                  </div>
                  
                  <div className="flex justify-end gap-4">
                    <Button 
                      type="button" 
                      variant="outline"
                      onClick={() => setSubmitForm(false)}
                    >
                      Cancel
                    </Button>
                    <Button 
                      type="submit"
                      className="bg-orange hover:bg-orange/90 text-white"
                    >
                      <Send className="h-4 w-4 mr-2" />
                      Submit Review
                    </Button>
                  </div>
                </form>
              </motion.div>
            )}
          </CardContent>
        </Card>
        
        {/* All Testimonials Grid */}
        <div className="mb-16">
          <div className="text-center mb-8">
            <h2 className="text-2xl font-bold mb-4">Customer Reviews</h2>
            <Tabs value={activeTab} onValueChange={setActiveTab} className="inline-flex">
              <TabsList className="bg-muted/50">
                <TabsTrigger value="all">All Reviews</TabsTrigger>
                <TabsTrigger value="5star">5 Star</TabsTrigger>
                <TabsTrigger value="4star">4 Star</TabsTrigger>
                <TabsTrigger value="recent">Recent</TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {testimonials.concat(testimonials).map((testimonial, index) => (
              <motion.div
                key={`grid-${testimonial.id}-${index}`}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.1 }}
              >
                <Card className="h-full hover:shadow-md transition-shadow border-border/50 hover:border-orange/20">
                  <CardHeader className="pb-2">
                    <div className="flex items-center gap-4">
                      <Avatar>
                        <AvatarImage src={testimonial.image} alt={testimonial.name} />
                        <AvatarFallback className="bg-orange/20 text-orange">{testimonial.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                      </Avatar>
                      <div>
                        <CardTitle className="text-base">{testimonial.name}</CardTitle>
                        <CardDescription>{testimonial.position}</CardDescription>
                      </div>
                    </div>
                  </CardHeader>
                  
                  <CardContent className="pt-2">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            size={14}
                            className={cn(
                              i < testimonial.rating
                                ? "fill-orange text-orange"
                                : "text-gray-300"
                            )}
                          />
                        ))}
                      </div>
                      <span className="text-xs text-muted-foreground">{testimonial.date}</span>
                    </div>
                    
                    <p className="text-sm line-clamp-4">{testimonial.text}</p>
                  </CardContent>
                  
                  <CardFooter>
                    <Button variant="ghost" size="sm" className="text-orange hover:text-orange/80 hover:bg-orange/5 -ml-2 text-xs">
                      Read full review
                    </Button>
                  </CardFooter>
                </Card>
              </motion.div>
            ))}
          </div>
          
          <div className="flex justify-center mt-8">
            <Button variant="outline" className="rounded-full px-6">
              Load More Reviews
            </Button>
          </div>
        </div>
        
        {/* Customer Stats */}
        <div className="bg-card rounded-xl p-8 border border-border/50 mb-16">
          <div className="text-center mb-8">
            <h2 className="text-2xl font-bold mb-2">Customer Satisfaction</h2>
            <p className="text-muted-foreground">We pride ourselves on delivering exceptional service</p>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
            <div className="p-4">
              <div className="text-3xl font-bold text-orange mb-2">98%</div>
              <p className="text-muted-foreground">Satisfied Customers</p>
            </div>
            <div className="p-4">
              <div className="text-3xl font-bold text-orange mb-2">4.8/5</div>
              <p className="text-muted-foreground">Average Rating</p>
            </div>
            <div className="p-4">
              <div className="text-3xl font-bold text-orange mb-2">1200+</div>
              <p className="text-muted-foreground">Monthly Rentals</p>
            </div>
            <div className="p-4">
              <div className="text-3xl font-bold text-orange mb-2">85%</div>
              <p className="text-muted-foreground">Repeat Customers</p>
            </div>
          </div>
        </div>
        
        {/* FAQ Section */}
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h2 className="text-2xl font-bold mb-8">Frequently Asked Questions</h2>
          
          <div className="space-y-4 text-left">
            <Card>
              <CardHeader className="py-4">
                <CardTitle className="text-lg flex items-center">
                  <span className="bg-orange/10 text-orange w-6 h-6 rounded-full flex items-center justify-center mr-2 text-sm">Q</span>
                  How can I leave a review?
                </CardTitle>
              </CardHeader>
              <CardContent className="pb-4">
                <p className="text-muted-foreground pl-8">
                  You can leave a review by clicking the "Write a Review" button above and filling out the form with your experience.
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="py-4">
                <CardTitle className="text-lg flex items-center">
                  <span className="bg-orange/10 text-orange w-6 h-6 rounded-full flex items-center justify-center mr-2 text-sm">Q</span>
                  Are all reviews displayed?
                </CardTitle>
              </CardHeader>
              <CardContent className="pb-4">
                <p className="text-muted-foreground pl-8">
                  All reviews are subject to moderation to ensure they meet our community guidelines. Most reviews are approved within 24-48 hours.
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="py-4">
                <CardTitle className="text-lg flex items-center">
                  <span className="bg-orange/10 text-orange w-6 h-6 rounded-full flex items-center justify-center mr-2 text-sm">Q</span>
                  How do you verify reviews are authentic?
                </CardTitle>
              </CardHeader>
              <CardContent className="pb-4">
                <p className="text-muted-foreground pl-8">
                  We only accept reviews from verified customers who have completed a rental with us, ensuring all feedback is genuine and trustworthy.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </main>
  );
};

export default Testimonials;
