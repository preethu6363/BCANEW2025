import React from 'react';

const Contact = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Contact Us</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div>
          <h2 className="text-2xl font-semifont-bold mb-4">Visit Us</h2>
          <p className="mb-4">123 Cross, Mandya</p>
          <p className="mb-4">Phone: +91 1234567890</p>
          <p className="mb-4">Email: contact@example.com</p>
          
          <h3 className="text-xl font-semibold mt-6 mb-2">Business Hours</h3>
          <p className="mb-1">Monday - Friday: 9:00 AM - 6:00 PM</p>
          <p className="mb-4">Saturday: 10:00 AM - 4:00 PM</p>
          
          <h3 className="text-xl font-semibold mt-6 mb-2">Follow Us</h3>
          <div className="flex space-x-4">
            <a href="#" className="text-blue-500 hover:text-blue-700">Facebook</a>
            <a href="#" className="text-blue-500 hover:text-blue-700">Twitter</a>
            <a href="#" className="text-blue-500 hover:text-blue-700">Instagram</a>
          </div>
        </div>
        <div>
          <h2 className="text-2xl font-semibold mb-4">Send us a Message</h2>
          <form className="space-y-4">
            <div>
              <label className="block mb-1">Name</label>
              <input type="text" className="w-full p-2 border rounded" />
            </div>
            <div>
              <label className="block mb-1">Email</label>
              <input type="email" className="w-full p-2 border rounded" />
            </div>
            <div>
              <label className="block mb-1">Message</label>
              <textarea className="w-full p-2 border rounded" rows={4}></textarea>
            </div>
            <button className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">
              Submit
            </button>
          </form>
        </div>
      </div>

      <div className="mt-12">
        <h2 className="text-2xl font-semibold mb-4">Our Location</h2>
        <div className="bg-gray-200 h-64 rounded-lg">
          {/* Map placeholder */}
          <div className="flex items-center justify-center h-full">
            <p>Map of 123 Cross, Mandya</p>
          </div>
        </div>
      </div>

      <div className="mt-12">
        <h2 className="text-2xl font-semibold mb-4">Testimonials</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="border p-4 rounded-lg">
            <p>"Great service! Highly recommended."</p>
            <p className="font-semibold mt-2">- Rajesh K.</p>
          </div>
          <div className="border p-4 rounded-lg">
            <p>"Very professional and reliable."</p>
            <p className="font-semibold mt-2">- Priya M.</p>
          </div>
          <div className="border p-4 rounded-lg">
            <p>"Excellent customer support."</p>
            <p className="font-semibold mt-2">- Amit S.</p>
          </div>
        </div>
      </div>

      <div className="mt-12">
        <h2 className="text-2xl font-semibold mb-4">FAQ</h2>
        <div className="space-y-4">
          <div>
            <h3 className="font-semibold">What are your payment methods?</h3>
            <p className="mt-1">We accept credit card, debit card, and bank transfer.</p>
          </div>
          <div>
            <h3 className="font-semibold">What is your cancellation policy?</h3>
            <p className="mt-1">Cancellations are accepted up to 24 hours before the booking.</p>
          </div>
          <div>
            <h3 className="font-semibold">Do you offer discount for long-term rental?</h3>
            <p className="mt-1">Yes, we offer special rate for rental longer than 7 days.</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;
