import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { CheckCircle, Search, Filter, Star, Heart, ArrowUpRight, Car, Battery, Fuel, Users, GaugeCircle, Calendar, ShieldCheck } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { mockCars } from '@/data/cars';
import { CarType } from '@/types/car';

type SortOption = 'popular' | 'price-low' | 'price-high' | 'newest';

// Extend the CarType with additional optional properties for the trending page
interface TrendingCar extends Omit<CarType, 'year'> {
  year?: number;
  discount?: number;
  seats?: number;
  mileage?: string;
  enginePower?: string;
  features?: string[];
  fuelType: string; // Make fuelType required in TrendingCar
}

const Trending = () => {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<SortOption>('popular');
  const [bookmarkedCars, setBookmarkedCars] = useState<string[]>([]);
  const [filteredCars, setFilteredCars] = useState<TrendingCar[]>([]);
  const [showFilters, setShowFilters] = useState(false);
  const [priceRange, setPriceRange] = useState([0, 50000]);
  const [selectedBrands, setSelectedBrands] = useState<string[]>([]);
  
  // Convert mockCars to TrendingCar
  const trendingCars: TrendingCar[] = mockCars.map(car => ({
    ...car,
    discount: Math.random() > 0.7 ? Math.floor(Math.random() * 20) + 5 : undefined, // 30% of cars have discount
    seats: Math.floor(Math.random() * 3) + 4, // 4-6 seats
    mileage: car.specifications?.mileage || `${Math.floor(Math.random() * 10) + 10} km/l`,
    enginePower: car.specifications?.power || ['2.0L', '3.0L', '1.5L', '5.0L'][Math.floor(Math.random() * 4)],
    fuelType: car.specifications?.fuelType || 'Petrol', // Ensure fuelType is always defined
    features: [
      'Bluetooth',
      'GPS',
      'Leather Seats',
      'Sunroof',
      'Parking Sensors',
      'Climate Control',
      'Cruise Control'
    ].filter(() => Math.random() > 0.5) // Randomly select features
  }));
  
  useEffect(() => {
    // Apply search and sorting
    let result = [...trendingCars];
    
    // Filter by tab category
    if (activeTab !== 'all') {
      result = result.filter(car => car.category === activeTab);
    }
    
    // Apply search query
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      result = result.filter(car => 
        car.name.toLowerCase().includes(query) || 
        car.brand.toLowerCase().includes(query) ||
        car.description.toLowerCase().includes(query)
      );
    }
    
    // Apply brand filter
    if (selectedBrands.length > 0) {
      result = result.filter(car => selectedBrands.includes(car.brand));
    }
    
    // Apply price range filter
    result = result.filter(car => {
      const effectivePrice = car.discount 
        ? car.pricePerDay * (1 - car.discount / 100) 
        : car.pricePerDay;
      return effectivePrice >= priceRange[0] && effectivePrice <= priceRange[1];
    });
    
    // Apply sorting
    switch (sortBy) {
      case 'price-low':
        result.sort((a, b) => {
          const priceA = a.discount ? a.pricePerDay * (1 - a.discount / 100) : a.pricePerDay;
          const priceB = b.discount ? b.pricePerDay * (1 - b.discount / 100) : b.pricePerDay;
          return priceA - priceB;
        });
        break;
      case 'price-high':
        result.sort((a, b) => {
          const priceA = a.discount ? a.pricePerDay * (1 - a.discount / 100) : a.pricePerDay;
          const priceB = b.discount ? b.pricePerDay * (1 - b.discount / 100) : b.pricePerDay;
          return priceB - priceA;
        });
        break;
      case 'newest':
        result.sort((a, b) => (b.year || 2023) - (a.year || 2023));
        break;
      default: // popular
        result.sort((a, b) => (b.rating || 4.5) - (a.rating || 4.5));
    }
    
    setFilteredCars(result);
  }, [activeTab, searchQuery, sortBy, selectedBrands, priceRange]);
  
  const brands = Array.from(new Set(trendingCars.map(car => car.brand)));
  
  const handleBookmark = (carId: string) => {
    setBookmarkedCars(prev => {
      if (prev.includes(carId)) {
        toast({
          title: "Removed from bookmarks",
          description: "Car has been removed from your bookmarks"
        });
        return prev.filter(id => id !== carId);
      } else {
        toast({
          title: "Added to bookmarks",
          description: "Car has been added to your bookmarks"
        });
        return [...prev, carId];
      }
    });
  };
  
  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { 
      opacity: 1,
      transition: { 
        staggerChildren: 0.1
      } 
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { 
      y: 0, 
      opacity: 1,
      transition: { duration: 0.5 }
    }
  };
  
  return (
    <main className="min-h-screen pt-24 pb-16">
      <div className="container mx-auto px-4">
        <div className="flex flex-col gap-6">
          {/* Header */}
          <div className="text-center mb-8">
            <h1 className="text-3xl md:text-4xl font-bold mb-3">Trending Cars</h1>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Discover our most popular and trending luxury vehicles, perfect for any occasion
            </p>
          </div>
          
          {/* Search and Filter */}
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input 
                placeholder="Search by car name, brand or features..." 
                className="pl-10" 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <div className="flex gap-2">
              <Select value={sortBy} onValueChange={(value) => setSortBy(value as SortOption)}>
                <SelectTrigger className="w-[180px]">
                  <span>Sort by</span>
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="popular">Most Popular</SelectItem>
                  <SelectItem value="price-low">Price: Low to High</SelectItem>
                  <SelectItem value="price-high">Price: High to Low</SelectItem>
                  <SelectItem value="newest">Newest Models</SelectItem>
                </SelectContent>
              </Select>
              <Button 
                variant={showFilters ? "default" : "outline"} 
                onClick={() => setShowFilters(!showFilters)}
                className="whitespace-nowrap"
              >
                <Filter className="h-4 w-4 mr-2" />
                Filters
              </Button>
            </div>
          </div>
          
          {/* Filter Panel */}
          {showFilters && (
            <motion.div 
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="bg-muted/30 p-4 rounded-lg mb-6"
            >
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                  <h3 className="font-semibold mb-3">Price Range (₹/day)</h3>
                  <div className="flex items-center gap-2">
                    <Input 
                      type="number" 
                      min="0" 
                      max="50000" 
                      value={priceRange[0]} 
                      onChange={(e) => setPriceRange([parseInt(e.target.value), priceRange[1]])}
                    />
                    <span>to</span>
                    <Input 
                      type="number" 
                      min="0" 
                      max="50000" 
                      value={priceRange[1]} 
                      onChange={(e) => setPriceRange([priceRange[0], parseInt(e.target.value)])}
                    />
                  </div>
                </div>
                <div>
                  <h3 className="font-semibold mb-3">Brands</h3>
                  <div className="flex flex-wrap gap-2">
                    {brands.map(brand => (
                      <Badge 
                        key={brand}
                        variant={selectedBrands.includes(brand) ? "default" : "outline"}
                        className="cursor-pointer"
                        onClick={() => {
                          if (selectedBrands.includes(brand)) {
                            setSelectedBrands(selectedBrands.filter(b => b !== brand));
                          } else {
                            setSelectedBrands([...selectedBrands, brand]);
                          }
                        }}
                      >
                        {brand}
                      </Badge>
                    ))}
                  </div>
                </div>
                <div className="flex items-end">
                  <Button 
                    variant="outline" 
                    className="w-full"
                    onClick={() => {
                      setPriceRange([0, 50000]);
                      setSelectedBrands([]);
                    }}
                  >
                    Reset Filters
                  </Button>
                </div>
              </div>
            </motion.div>
          )}
          
          {/* Category Tabs */}
          <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="w-full flex overflow-x-auto scrollbar-hide mb-4">
              <TabsTrigger value="all" className="flex-1">All</TabsTrigger>
              <TabsTrigger value="luxury" className="flex-1">Luxury</TabsTrigger>
              <TabsTrigger value="sports" className="flex-1">Sports</TabsTrigger>
              <TabsTrigger value="electric" className="flex-1">Electric</TabsTrigger>
              <TabsTrigger value="suv" className="flex-1">SUV</TabsTrigger>
              <TabsTrigger value="convertible" className="flex-1">Convertible</TabsTrigger>
            </TabsList>
            
            <TabsContent value={activeTab}>
              {/* Results Stats */}
              <div className="flex justify-between items-center mb-6">
                <p className="text-sm text-muted-foreground">
                  {filteredCars.length} cars found
                </p>
                <div className="flex items-center gap-1">
                  <CheckCircle className="h-4 w-4 text-green-500" />
                  <span className="text-sm">Free cancellation</span>
                </div>
              </div>
              
              {/* Car Grid */}
              <motion.div 
                variants={containerVariants}
                initial="hidden"
                animate="visible"
                className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
              >
                {filteredCars.map((car) => (
                  <motion.div 
                    key={car.id}
                    variants={itemVariants}
                    className="group relative bg-card rounded-xl overflow-hidden border hover:shadow-lg transition-all"
                  >
                    {/* Car Image */}
                    <div className="aspect-[4/3] relative overflow-hidden">
                      <img 
                        src={car.image} 
                        alt={car.name} 
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                      {/* Discount Badge */}
                      {car.discount && (
                        <div className="absolute top-3 left-3 bg-orange text-white text-sm font-bold px-2 py-1 rounded">
                          {car.discount}% OFF
                        </div>
                      )}
                      {/* Bookmark Button */}
                      <Button
                        variant="ghost"
                        size="icon"
                        className="absolute top-3 right-3 bg-background/50 backdrop-blur-sm rounded-full"
                        onClick={(e) => {
                          e.preventDefault();
                          handleBookmark(car.id);
                        }}
                      >
                        <Heart 
                          className={`h-5 w-5 ${bookmarkedCars.includes(car.id) ? 'fill-orange text-orange' : 'text-foreground'}`} 
                        />
                      </Button>
                      {/* Category Badge */}
                      <div className="absolute bottom-3 left-3">
                        <Badge variant="secondary" className="bg-background/50 backdrop-blur-sm">
                          {car.category}
                        </Badge>
                      </div>
                    </div>
                    
                    {/* Car Details */}
                    <div className="p-4">
                      <div className="flex justify-between items-start mb-2">
                        <h3 className="font-semibold text-lg">{car.name}</h3>
                        <div className="flex items-center">
                          <Star className="h-4 w-4 fill-yellow-400 text-yellow-400 mr-1" />
                          <span>{car.rating}</span>
                        </div>
                      </div>
                      
                      <p className="text-sm text-muted-foreground mb-3">{car.brand}</p>
                      
                      {/* Price */}
                      <div className="flex items-center gap-2 mb-3">
                        {car.discount ? (
                          <>
                            <span className="text-xl font-bold">₹{Math.round(car.pricePerDay * (1 - car.discount / 100))}</span>
                            <span className="text-sm text-muted-foreground line-through">₹{car.pricePerDay}</span>
                            <span className="text-sm text-green-500 ml-auto">per day</span>
                          </>
                        ) : (
                          <>
                            <span className="text-xl font-bold">₹{car.pricePerDay}</span>
                            <span className="text-sm text-muted-foreground ml-auto">per day</span>
                          </>
                        )}
                      </div>
                      
                      {/* Features */}
                      <div className="grid grid-cols-2 gap-2 mb-4">
                        <div className="flex items-center text-sm">
                          <Users className="h-4 w-4 mr-1 text-muted-foreground" />
                          <span>{car.seats} Seats</span>
                        </div>
                        <div className="flex items-center text-sm">
                          <Fuel className="h-4 w-4 mr-1 text-muted-foreground" />
                          <span>{car.fuelType}</span>
                        </div>
                      </div>
                      
                      {/* Book Now Button */}
                      <div className="flex gap-2">
                        <Link to={`/car/${car.id}`} className="flex-1">
                          <Button variant="outline" className="w-full">
                            View Details
                          </Button>
                        </Link>
                        <Link to={`/bookings?car=${car.id}`} className="flex-1">
                          <Button className="w-full">
                            Book Now
                          </Button>
                        </Link>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </motion.div>
              
              {/* Empty State */}
              {filteredCars.length === 0 && (
                <div className="text-center py-16">
                  <div className="bg-muted w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Car className="h-8 w-8 text-muted-foreground" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">No Cars Found</h3>
                  <p className="text-muted-foreground mb-6">Try adjusting your search or filter criteria</p>
                  <Button 
                    onClick={() => {
                      setSearchQuery('');
                      setActiveTab('all');
                      setPriceRange([0, 50000]);
                      setSelectedBrands([]);
                    }}
                  >
                    Reset All Filters
                  </Button>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </div>
        
        {/* Special Offers Section */}
        <section className="mt-20">
          <div className="text-center mb-10">
            <h2 className="text-3xl font-bold mb-3">Special Offers</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Limited time deals on premium cars with exclusive benefits
            </p>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {trendingCars.filter(car => car.discount).slice(0, 3).map((car) => (
              <motion.div 
                key={car.id}
                whileHover={{ y: -5 }}
                className="bg-card rounded-xl overflow-hidden border border-orange/10 shadow-lg relative"
              >
                <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-orange to-orange/50"></div>
                <div className="aspect-video relative">
                  <img 
                    src={car.image} 
                    alt={car.name} 
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-3 right-3 bg-orange text-white font-bold px-3 py-1 rounded-full">
                    {car.discount}% OFF
                  </div>
                </div>
                <div className="p-5">
                  <h3 className="font-semibold text-xl mb-2">{car.name}</h3>
                  <div className="flex items-center gap-2 mb-4">
                    <span className="text-2xl font-bold">₹{Math.round(car.pricePerDay * (1 - car.discount / 100))}</span>
                    <span className="text-sm text-muted-foreground line-through">₹{car.pricePerDay}</span>
                    <span className="text-sm ml-auto">per day</span>
                  </div>
                  <div className="space-y-2 mb-4">
                    <div className="flex items-center text-sm">
                      <CheckCircle className="h-4 w-4 mr-2 text-green-500" />
                      <span>Free cancellation up to 24hrs</span>
                    </div>
                    <div className="flex items-center text-sm">
                      <CheckCircle className="h-4 w-4 mr-2 text-green-500" />
                      <span>Unlimited kilometers</span>
                    </div>
                    <div className="flex items-center text-sm">
                      <CheckCircle className="h-4 w-4 mr-2 text-green-500" />
                      <span>Doorstep delivery</span>
                    </div>
                  </div>
                  <Link to={`/bookings?car=${car.id}`}>
                    <Button className="w-full">
                      Book Now <ArrowUpRight className="h-4 w-4 ml-1" />
                    </Button>
                  </Link>
                  <p className="text-xs text-muted-foreground text-center mt-3">
                    Offer valid until 31 May 2024
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        </section>
      </div>
    </main>
  );
};

export default Trending;
