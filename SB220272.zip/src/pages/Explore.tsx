
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useSearchParams } from 'react-router-dom';
import { Search, Filter, ChevronDown, Car, Fuel, Users, Gauge, Calendar, X, Settings, CircleDollarSign, Truck, Zap } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Slider } from '@/components/ui/slider';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Sheet, SheetContent, SheetTrigger, SheetClose, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Checkbox } from '@/components/ui/checkbox';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import CarCategoryFilter from '@/components/car/CarCategoryFilter';
import CarCard from '@/components/car/CarCard';
import { mockCars } from '@/data/cars';
import { useToast } from '@/hooks/use-toast';

const purposeOptions = [
  { value: 'any', label: 'Any Purpose' },
  { value: 'business', label: 'Business' },
  { value: 'leisure', label: 'Leisure' },
  { value: 'wedding', label: 'Wedding' },
  { value: 'airport', label: 'Airport Transfer' }
];

const mileageRanges = [
  { value: 'any', label: 'Any Mileage' },
  { value: 'high', label: 'High (>15 km/l)' },
  { value: 'medium', label: 'Medium (10-15 km/l)' },
  { value: 'low', label: 'Low (<10 km/l)' }
];

const Explore = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const initialCategory = searchParams.get('category') || 'all';
  
  const [selectedCategory, setSelectedCategory] = useState(initialCategory);
  const [searchQuery, setSearchQuery] = useState('');
  const [bookmarkedCars, setBookmarkedCars] = useState<string[]>([]);
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 20000]);
  const [selectedBrands, setSelectedBrands] = useState<string[]>([]);
  const [selectedFuelTypes, setSelectedFuelTypes] = useState<string[]>([]);
  const [selectedYears, setSelectedYears] = useState<number[]>([]);
  const [selectedPurpose, setSelectedPurpose] = useState('any');
  const [selectedMileage, setSelectedMileage] = useState('any');
  const [minSeats, setMinSeats] = useState<number>(0);
  const [automatic, setAutomatic] = useState<boolean | null>(null);
  const [sortBy, setSortBy] = useState<string>('popular');
  const [filteredCars, setFilteredCars] = useState(mockCars);
  const { toast } = useToast();

  // Extract unique values for filters
  const brands = Array.from(new Set(mockCars.map(car => car.brand)));
  const fuelTypes = Array.from(new Set(mockCars.map(car => car.specifications?.fuelType || '')));
  const years = Array.from(new Set(mockCars.map(car => car.year))).sort((a, b) => b - a);

  // Update URL when category changes
  useEffect(() => {
    if (selectedCategory === 'all') {
      searchParams.delete('category');
    } else {
      searchParams.set('category', selectedCategory);
    }
    setSearchParams(searchParams);
  }, [selectedCategory, searchParams, setSearchParams]);

  // Filter cars based on all criteria
  useEffect(() => {
    let result = mockCars.filter(car => {
      // Category filter
      const matchesCategory = selectedCategory === 'all' || car.category === selectedCategory;
      
      // Search query filter
      const matchesSearch = 
        car.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        car.brand.toLowerCase().includes(searchQuery.toLowerCase()) ||
        car.categoryName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        car.description.toLowerCase().includes(searchQuery.toLowerCase());
      
      // Price range filter
      const matchesPrice = car.pricePerDay ? 
        car.pricePerDay >= priceRange[0] && car.pricePerDay <= priceRange[1] : 
        true;
      
      // Brand filter
      const matchesBrand = selectedBrands.length === 0 || selectedBrands.includes(car.brand);
      
      // Fuel type filter
      const matchesFuel = selectedFuelTypes.length === 0 || 
        (car.specifications?.fuelType && selectedFuelTypes.includes(car.specifications.fuelType));
      
      // Year filter
      const matchesYear = selectedYears.length === 0 || selectedYears.includes(car.year);
      
      // Purpose filter (simulated - would need real data)
      const matchesPurpose = selectedPurpose === 'any' || 
        (selectedPurpose === 'business' && car.pricePerDay > 10000) ||
        (selectedPurpose === 'leisure' && car.pricePerDay < 15000) ||
        (selectedPurpose === 'wedding' && car.category === 'luxury') ||
        (selectedPurpose === 'airport' && car.specifications?.fuelType !== 'Electric');
      
      // Mileage filter (simulated - would need real data)
      const carMileage = parseInt(car.specifications?.mileage?.split(' ')[0] || '0');
      const matchesMileage = selectedMileage === 'any' ||
        (selectedMileage === 'high' && carMileage > 15) ||
        (selectedMileage === 'medium' && carMileage >= 10 && carMileage <= 15) ||
        (selectedMileage === 'low' && carMileage < 10);
      
      // Seats filter (simulated)
      const carSeats = car.specifications?.seatingCapacity || 5;
      const matchesSeats = minSeats === 0 || carSeats >= minSeats;
      
      // Transmission filter (simulated)
      const isAutomatic = car.transmission === 'Automatic';
      const matchesTransmission = automatic === null || isAutomatic === automatic;
      
      return matchesCategory && matchesSearch && matchesPrice && matchesBrand && 
             matchesFuel && matchesYear && matchesPurpose && matchesMileage && 
             matchesSeats && matchesTransmission;
    });

    // Apply sorting
    switch (sortBy) {
      case 'price-low':
        result.sort((a, b) => (a.pricePerDay || 0) - (b.pricePerDay || 0));
        break;
      case 'price-high':
        result.sort((a, b) => (b.pricePerDay || 0) - (a.pricePerDay || 0));
        break;
      case 'newest':
        result.sort((a, b) => b.year - a.year);
        break;
      case 'rating':
        result.sort((a, b) => b.rating - a.rating);
        break;
      default: // popular
        result.sort((a, b) => b.rating - a.rating);
    }

    setFilteredCars(result);
  }, [
    selectedCategory, searchQuery, priceRange, selectedBrands, 
    selectedFuelTypes, selectedYears, sortBy, selectedPurpose,
    selectedMileage, minSeats, automatic
  ]);

  const handleBookmark = (carId: string) => {
    setBookmarkedCars(prev => {
      if (prev.includes(carId)) {
        toast({
          title: "Removed from bookmarks",
          description: "Car has been removed from your bookmarks",
        });
        return prev.filter(id => id !== carId);
      } else {
        toast({
          title: "Added to bookmarks",
          description: "Car has been added to your bookmarks",
        });
        return [...prev, carId];
      }
    });
  };

  const resetFilters = () => {
    setSelectedCategory('all');
    setSearchQuery('');
    setPriceRange([0, 20000]);
    setSelectedBrands([]);
    setSelectedFuelTypes([]);
    setSelectedYears([]);
    setSelectedPurpose('any');
    setSelectedMileage('any');
    setMinSeats(0);
    setAutomatic(null);
    setSortBy('popular');
  };

  return (
    <main className="pt-24 pb-16">
      <div className="container mx-auto px-4">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Explore Our Fleet</h1>
          <p className="text-muted-foreground">
            Find your perfect vehicle from our extensive collection
          </p>
        </div>
        
        {/* Search and Filter */}
        <div className="flex flex-col md:flex-row gap-4 mb-8">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
            <Input
              className="pl-10 h-12"
              placeholder="Search by car name, brand, or features..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          
          <div className="flex gap-2">
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-[180px]">
                <span>Sort by</span>
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="popular">Most Popular</SelectItem>
                <SelectItem value="price-low">Price: Low to High</SelectItem>
                <SelectItem value="price-high">Price: High to Low</SelectItem>
                <SelectItem value="newest">Newest Models</SelectItem>
                <SelectItem value="rating">Highest Rated</SelectItem>
              </SelectContent>
            </Select>
            
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="outline" className="flex items-center gap-2">
                  <Filter className="h-4 w-4" />
                  <span>Filters</span>
                </Button>
              </SheetTrigger>
              <SheetContent className="overflow-y-auto">
                <SheetHeader>
                  <SheetTitle>Advanced Filters</SheetTitle>
                </SheetHeader>
                
                <div className="space-y-6 py-4">
                  {/* Price Range */}
                  <div className="space-y-4">
                    <div className="flex items-center gap-2">
                      <CircleDollarSign className="h-5 w-5 text-green-500" />
                      <h3 className="text-sm font-medium">Price Range (₹/day)</h3>
                    </div>
                    <div className="px-2">
                      <Slider 
                        defaultValue={[0, 20000]} 
                        max={20000} 
                        step={500} 
                        value={priceRange}
                        onValueChange={(value) => setPriceRange(value as [number, number])}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <span>₹{priceRange[0]}</span>
                      <span>₹{priceRange[1]}</span>
                    </div>
                  </div>
                  
                  {/* Purpose Filter (New) */}
                  <div className="space-y-4">
                    <div className="flex items-center gap-2">
                      <Settings className="h-5 w-5 text-green-500" />
                      <h3 className="text-sm font-medium">Purpose</h3>
                    </div>
                    <RadioGroup
                      value={selectedPurpose}
                      onValueChange={setSelectedPurpose}
                      className="flex flex-col space-y-1"
                    >
                      {purposeOptions.map(option => (
                        <div key={option.value} className="flex items-center space-x-2">
                          <RadioGroupItem value={option.value} id={`purpose-${option.value}`} />
                          <Label htmlFor={`purpose-${option.value}`}>{option.label}</Label>
                        </div>
                      ))}
                    </RadioGroup>
                  </div>
                  
                  {/* Mileage Filter (New) */}
                  <div className="space-y-4">
                    <div className="flex items-center gap-2">
                      <Gauge className="h-5 w-5 text-green-500" />
                      <h3 className="text-sm font-medium">Mileage Efficiency</h3>
                    </div>
                    <RadioGroup
                      value={selectedMileage}
                      onValueChange={setSelectedMileage}
                      className="flex flex-col space-y-1"
                    >
                      {mileageRanges.map(option => (
                        <div key={option.value} className="flex items-center space-x-2">
                          <RadioGroupItem value={option.value} id={`mileage-${option.value}`} />
                          <Label htmlFor={`mileage-${option.value}`}>{option.label}</Label>
                        </div>
                      ))}
                    </RadioGroup>
                  </div>
                  
                  {/* Seats Filter (New) */}
                  <div className="space-y-4">
                    <div className="flex items-center gap-2">
                      <Users className="h-5 w-5 text-green-500" />
                      <h3 className="text-sm font-medium">Minimum Seats</h3>
                    </div>
                    <RadioGroup
                      value={minSeats.toString()}
                      onValueChange={(value) => setMinSeats(parseInt(value))}
                      className="flex justify-between"
                    >
                      {[0, 2, 4, 5, 7].map(num => (
                        <div key={num} className="flex flex-col items-center gap-1">
                          <RadioGroupItem value={num.toString()} id={`seats-${num}`} />
                          <Label htmlFor={`seats-${num}`}>{num === 0 ? 'Any' : num+'+'}</Label>
                        </div>
                      ))}
                    </RadioGroup>
                  </div>
                  
                  {/* Transmission Type (New) */}
                  <div className="space-y-4">
                    <div className="flex items-center gap-2">
                      <Settings className="h-5 w-5 text-green-500" />
                      <h3 className="text-sm font-medium">Transmission</h3>
                    </div>
                    <RadioGroup
                      value={automatic === null ? 'any' : automatic ? 'automatic' : 'manual'}
                      onValueChange={(value) => {
                        if (value === 'any') setAutomatic(null);
                        else setAutomatic(value === 'automatic');
                      }}
                      className="flex justify-between"
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="any" id="transmission-any" />
                        <Label htmlFor="transmission-any">Any</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="automatic" id="transmission-auto" />
                        <Label htmlFor="transmission-auto">Automatic</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="manual" id="transmission-manual" />
                        <Label htmlFor="transmission-manual">Manual</Label>
                      </div>
                    </RadioGroup>
                  </div>
                  
                  {/* Brand Filter */}
                  <div className="space-y-4">
                    <div className="flex items-center gap-2">
                      <Car className="h-5 w-5 text-green-500" />
                      <h3 className="text-sm font-medium">Brands</h3>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {brands.map(brand => (
                        <Badge 
                          key={brand}
                          variant={selectedBrands.includes(brand) ? "default" : "outline"}
                          className="cursor-pointer"
                          onClick={() => {
                            setSelectedBrands(prev => 
                              prev.includes(brand) 
                                ? prev.filter(b => b !== brand) 
                                : [...prev, brand]
                            );
                          }}
                        >
                          {brand}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  
                  {/* Fuel Type Filter */}
                  <div className="space-y-4">
                    <div className="flex items-center gap-2">
                      <Fuel className="h-5 w-5 text-green-500" />
                      <h3 className="text-sm font-medium">Fuel Type</h3>
                    </div>
                    <div className="space-y-2">
                      {fuelTypes.filter(Boolean).map(fuel => (
                        <div key={fuel} className="flex items-center space-x-2">
                          <Checkbox 
                            id={`fuel-${fuel}`} 
                            checked={selectedFuelTypes.includes(fuel)}
                            onCheckedChange={(checked) => {
                              if (checked) {
                                setSelectedFuelTypes(prev => [...prev, fuel]);
                              } else {
                                setSelectedFuelTypes(prev => prev.filter(f => f !== fuel));
                              }
                            }}
                          />
                          <label htmlFor={`fuel-${fuel}`} className="text-sm">{fuel}</label>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  {/* Year Filter */}
                  <div className="space-y-4">
                    <div className="flex items-center gap-2">
                      <Calendar className="h-5 w-5 text-green-500" />
                      <h3 className="text-sm font-medium">Year</h3>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {years.map(year => (
                        <Badge 
                          key={year}
                          variant={selectedYears.includes(year) ? "default" : "outline"}
                          className="cursor-pointer"
                          onClick={() => {
                            setSelectedYears(prev => 
                              prev.includes(year) 
                                ? prev.filter(y => y !== year) 
                                : [...prev, year]
                            );
                          }}
                        >
                          {year}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  
                  {/* Action Buttons */}
                  <div className="flex justify-between pt-4">
                    <Button variant="outline" onClick={resetFilters}>
                      Reset All
                    </Button>
                    <SheetClose asChild>
                      <Button className="bg-green-500 hover:bg-green-600">Apply Filters</Button>
                    </SheetClose>
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
        
        {/* Category Tabs with Icons */}
        <div className="mb-8">
          <div className="grid grid-cols-2 md:grid-cols-6 gap-2 mb-6">
            <motion.button
              whileHover={{ scale: 1.05 }}
              onClick={() => setSelectedCategory('all')}
              className={`flex flex-col items-center justify-center p-4 rounded-xl ${
                selectedCategory === 'all' 
                  ? 'bg-green-500 text-white' 
                  : 'bg-muted/40 hover:bg-muted/60'
              }`}
            >
              <Car className="h-6 w-6 mb-2" />
              <span className="text-sm font-medium">All</span>
            </motion.button>
            
            <motion.button
              whileHover={{ scale: 1.05 }}
              onClick={() => setSelectedCategory('luxury')}
              className={`flex flex-col items-center justify-center p-4 rounded-xl ${
                selectedCategory === 'luxury' 
                  ? 'bg-green-500 text-white' 
                  : 'bg-muted/40 hover:bg-muted/60'
              }`}
            >
              <Car className="h-6 w-6 mb-2" />
              <span className="text-sm font-medium">Luxury</span>
            </motion.button>
            
            <motion.button
              whileHover={{ scale: 1.05 }}
              onClick={() => setSelectedCategory('sports')}
              className={`flex flex-col items-center justify-center p-4 rounded-xl ${
                selectedCategory === 'sports' 
                  ? 'bg-green-500 text-white' 
                  : 'bg-muted/40 hover:bg-muted/60'
              }`}
            >
              <Gauge className="h-6 w-6 mb-2" />
              <span className="text-sm font-medium">Sports</span>
            </motion.button>
            
            <motion.button
              whileHover={{ scale: 1.05 }}
              onClick={() => setSelectedCategory('suv')}
              className={`flex flex-col items-center justify-center p-4 rounded-xl ${
                selectedCategory === 'suv' 
                  ? 'bg-green-500 text-white' 
                  : 'bg-muted/40 hover:bg-muted/60'
              }`}
            >
              <Truck className="h-6 w-6 mb-2" />
              <span className="text-sm font-medium">SUV</span>
            </motion.button>
            
            <motion.button
              whileHover={{ scale: 1.05 }}
              onClick={() => setSelectedCategory('sedan')}
              className={`flex flex-col items-center justify-center p-4 rounded-xl ${
                selectedCategory === 'sedan' 
                  ? 'bg-green-500 text-white' 
                  : 'bg-muted/40 hover:bg-muted/60'
              }`}
            >
              <Car className="h-6 w-6 mb-2" />
              <span className="text-sm font-medium">Sedan</span>
            </motion.button>
            
            <motion.button
              whileHover={{ scale: 1.05 }}
              onClick={() => setSelectedCategory('electric')}
              className={`flex flex-col items-center justify-center p-4 rounded-xl ${
                selectedCategory === 'electric' 
                  ? 'bg-green-500 text-white' 
                  : 'bg-muted/40 hover:bg-muted/60'
              }`}
            >
              <Zap className="h-6 w-6 mb-2" />
              <span className="text-sm font-medium">Electric</span>
            </motion.button>
          </div>
          
          <CarCategoryFilter
            selectedCategory={selectedCategory}
            onSelectCategory={setSelectedCategory}
          />
        </div>
        
        {/* Active Filters */}
        {(selectedBrands.length > 0 || selectedFuelTypes.length > 0 || selectedYears.length > 0 || 
          priceRange[0] > 0 || priceRange[1] < 20000 || selectedPurpose !== 'any' || 
          selectedMileage !== 'any' || minSeats > 0 || automatic !== null) && (
          <div className="flex flex-wrap gap-2 mb-6">
            <span className="text-sm text-muted-foreground my-auto">Active filters:</span>
            
            {priceRange[0] > 0 || priceRange[1] < 20000 ? (
              <Badge variant="secondary" className="flex items-center gap-1">
                <span>₹{priceRange[0]} - ₹{priceRange[1]}</span>
                <X 
                  className="h-3 w-3 cursor-pointer" 
                  onClick={() => setPriceRange([0, 20000])}
                />
              </Badge>
            ) : null}
            
            {selectedPurpose !== 'any' && (
              <Badge variant="secondary" className="flex items-center gap-1">
                <span>Purpose: {purposeOptions.find(p => p.value === selectedPurpose)?.label}</span>
                <X 
                  className="h-3 w-3 cursor-pointer" 
                  onClick={() => setSelectedPurpose('any')}
                />
              </Badge>
            )}
            
            {selectedMileage !== 'any' && (
              <Badge variant="secondary" className="flex items-center gap-1">
                <span>Mileage: {mileageRanges.find(m => m.value === selectedMileage)?.label}</span>
                <X 
                  className="h-3 w-3 cursor-pointer" 
                  onClick={() => setSelectedMileage('any')}
                />
              </Badge>
            )}
            
            {minSeats > 0 && (
              <Badge variant="secondary" className="flex items-center gap-1">
                <span>Min Seats: {minSeats}</span>
                <X 
                  className="h-3 w-3 cursor-pointer" 
                  onClick={() => setMinSeats(0)}
                />
              </Badge>
            )}
            
            {automatic !== null && (
              <Badge variant="secondary" className="flex items-center gap-1">
                <span>Transmission: {automatic ? 'Automatic' : 'Manual'}</span>
                <X 
                  className="h-3 w-3 cursor-pointer" 
                  onClick={() => setAutomatic(null)}
                />
              </Badge>
            )}
            
            {selectedBrands.map(brand => (
              <Badge key={brand} variant="secondary" className="flex items-center gap-1">
                <span>{brand}</span>
                <X 
                  className="h-3 w-3 cursor-pointer" 
                  onClick={() => setSelectedBrands(prev => prev.filter(b => b !== brand))}
                />
              </Badge>
            ))}
            
            {selectedFuelTypes.map(fuel => (
              <Badge key={fuel} variant="secondary" className="flex items-center gap-1">
                <span>{fuel}</span>
                <X 
                  className="h-3 w-3 cursor-pointer" 
                  onClick={() => setSelectedFuelTypes(prev => prev.filter(f => f !== fuel))}
                />
              </Badge>
            ))}
            
            {selectedYears.map(year => (
              <Badge key={year} variant="secondary" className="flex items-center gap-1">
                <span>{year}</span>
                <X 
                  className="h-3 w-3 cursor-pointer" 
                  onClick={() => setSelectedYears(prev => prev.filter(y => y !== year))}
                />
              </Badge>
            ))}
            
            <Button variant="ghost" size="sm" onClick={resetFilters}>
              Clear all
            </Button>
          </div>
        )}
        
        {/* Results count */}
        <div className="mb-6">
          <p className="text-sm text-muted-foreground">
            {filteredCars.length} cars found
          </p>
        </div>
        
        {/* Results */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredCars.length > 0 ? (
            filteredCars.map((car, index) => (
              <motion.div
                key={car.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <CarCard
                  car={car}
                  isBookmarked={bookmarkedCars.includes(car.id)}
                  onBookmark={handleBookmark}
                />
              </motion.div>
            ))
          ) : (
            <div className="col-span-full py-12 text-center">
              <h3 className="text-xl font-semibold mb-2">No cars found</h3>
              <p className="text-muted-foreground mb-4">
                Try adjusting your search or filters to find what you're looking for
              </p>
              <Button onClick={resetFilters} className="bg-green-500 hover:bg-green-600">
                Reset All Filters
              </Button>
            </div>
          )}
        </div>
      </div>
    </main>
  );
};

export default Explore;
