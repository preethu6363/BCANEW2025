import React, { useState, useEffect } from 'react';
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { ThemeProvider } from "@/hooks/use-theme";  // Your ThemeProvider
import { AuthProvider } from "@/context/AContext";

// Importing components and pages
import SplashScreen from "@/components/splash/SplashScreen";
import WelcomePopup from "@/components/common/WelcomePopup";
import MainLayout from "@/layout/MainLayout";
import Home from "@/pages/Home";
import Explore from "@/pages/Explore";
import Trending from "@/pages/Trending";
import Bookmarks from "@/pages/Bookmarks";
import Bookings from "@/pages/Bookings";
import About from "@/pages/About";
import Profile from "@/pages/Profile";
import Login from "@/pages/Login";
import NotFound from "@/pages/NotFound";
import Testimonials from "@/pages/Testimonials";
import SubmitTestimonial from "@/pages/SubmitTestimonial";
import Contact from "@/pages/Contact";
import PlaySection from "@/pages/PlaySection";

// Create a new QueryClient instance
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: false,
      refetchOnWindowFocus: false,
    },
  },
});

const App = () => {
  const [showSplash, setShowSplash] = useState(true);
  const [showWelcome, setShowWelcome] = useState(false);

  // Check if it's the first visit
  useEffect(() => {
    const hasVisited = localStorage.getItem('hasVisited');
    if (hasVisited) {
      setShowSplash(false);
    } else {
      setShowWelcome(true);
    }
  }, []);

  const handleSplashFinish = () => {
    setShowSplash(false);
    if (!showWelcome) {
      localStorage.setItem('hasVisited', 'true');
    }
  };

  const handleWelcomeClose = () => {
    setShowWelcome(false);
    localStorage.setItem('hasVisited', 'true');
  };

  return (
    <QueryClientProvider client={queryClient}>
      <BrowserRouter> {/* Wrap the entire application in BrowserRouter */}
        <ThemeProvider>
          <AuthProvider>
            <TooltipProvider>
              <Toaster />
              <Sonner />
              {showSplash ? (
                <SplashScreen onFinish={handleSplashFinish} />
              ) : (
                <>
                  {showWelcome && <WelcomePopup onClose={handleWelcomeClose} />}
                  <Routes>
                    <Route path="/login" element={<Login />} />
                    <Route element={<MainLayout />}>
                      <Route path="/" element={<Home />} />
                      <Route path="/explore" element={<Explore />} />
                      <Route path="/trending" element={<Trending />} />
                      <Route path="/bookmarks" element={<Bookmarks />} />
                      <Route path="/bookings" element={<Bookings />} />
                      <Route path="/about" element={<About />} />
                      <Route path="/testimonials" element={<Testimonials />} />
                      <Route path="/testimonials/submit" element={<SubmitTestimonial />} />
                      <Route path="/contact" element={<Contact />} />
                      <Route path="/profile" element={<Profile />} />
                      <Route path="/Home" element={<Home />} />
                      <Route path="/play" element={<PlaySection />} />
                    </Route>
                    <Route path="*" element={<NotFound />} />
                  </Routes>
                </>
              )}
            </TooltipProvider>
          </AuthProvider>
        </ThemeProvider>
      </BrowserRouter>
    </QueryClientProvider>
  );
};

export default App;
