
export type CarCategoryType = 'electric' | 'luxury' | 'suv' | 'sports' | 'commuter' | 'convertible';

export interface CarSpecifications {
  engine: string;
  power: string;
  mileage: string;
  fuelType: string;
  seatingCapacity: number;
  seats?: number; // Added optional seats property
  transmission?: string; // Added optional transmission property
}

export interface CarType {
  id: string;
  name: string;
  category: CarCategoryType;
  categoryName: string;
  description: string;
  image: string;
  images?: string[];
  price: number;
  pricePerDay?: number;
  year: number;
  transmission: string;
  rating: number;
  trending?: boolean;
  features?: string[];
  specifications?: CarSpecifications;
  brand: string;
}
