
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowUp, ChevronUp } from 'lucide-react';

const ScrollToTop = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [animationActive, setAnimationActive] = useState(false);

  const toggleVisibility = () => {
    if (window.scrollY > 300) {
      setIsVisible(true);
    } else {
      setIsVisible(false);
    }
  };

  const scrollToTop = () => {
    setAnimationActive(true);
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
    
    // Reset animation after scrolling
    setTimeout(() => {
      setAnimationActive(false);
    }, 1000);
  };

  useEffect(() => {
    window.addEventListener('scroll', toggleVisibility);
    return () => window.removeEventListener('scroll', toggleVisibility);
  }, []);

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.button
          initial={{ opacity: 0, scale: 0.5, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.5, y: 20 }}
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          className="fixed bottom-24 right-6 z-50 bg-green-500 text-white p-4 rounded-full shadow-lg flex items-center justify-center hover:bg-green-600 transition-colors"
          onClick={scrollToTop}
          aria-label="Scroll to top"
          style={{ 
            filter: "drop-shadow(0 0 8px rgba(34, 197, 94, 0.6))",
            boxShadow: "0 0 15px rgba(34, 197, 94, 0.4)"
          }}
        >
          <motion.div
            animate={
              animationActive 
                ? { y: [-3, 0, -3], opacity: [0.6, 1, 0.6] } 
                : { y: [0, -5, 0], opacity: 1 }
            }
            transition={
              animationActive 
                ? { duration: 0.3, times: [0, 0.5, 1] } 
                : { duration: 1.5, repeat: Infinity }
            }
          >
            <ChevronUp className="h-6 w-6" />
          </motion.div>
        </motion.button>
      )}
    </AnimatePresence>
  );
};

export default ScrollToTop;
