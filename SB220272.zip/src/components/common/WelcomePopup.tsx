
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Volume, Info, Car, Zap, Gift } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface WelcomePopupProps {
  onClose: () => void;
}

const WelcomePopup: React.FC<WelcomePopupProps> = ({ onClose }) => {
  const [currentStep, setCurrentStep] = useState(0);
  
  const features = [
    {
      icon: <Volume className="h-10 w-10 text-green-500" />,
      title: "Engine Sound",
      description: "Experience the thrill of luxury cars with our authentic engine sounds. Use the sound button to toggle."
    },
    {
      icon: <Car className="h-10 w-10 text-green-500" />,
      title: "Premium Cars",
      description: "Browse through our collection of luxury and sports cars, with detailed specifications."
    },
    {
      icon: <Zap className="h-10 w-10 text-green-500" />,
      title: "Easy Booking",
      description: "Book your dream car in just a few clicks with our streamlined booking process."
    },
    {
      icon: <Gift className="h-10 w-10 text-green-500" />,
      title: "Special Offers",
      description: "Look out for special discounts and promotional offers throughout the site."
    }
  ];
  
  const nextStep = () => {
    if (currentStep < features.length - 1) {
      setCurrentStep(prev => prev + 1);
    } else {
      onClose();
    }
  };
  
  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(prev => prev - 1);
    }
  };

  return (
    <AnimatePresence>
      <motion.div
        className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
      >
        <motion.div
          className="bg-white dark:bg-gray-900 rounded-xl shadow-2xl max-w-md w-full overflow-hidden"
          initial={{ scale: 0.9, y: 20 }}
          animate={{ scale: 1, y: 0 }}
          exit={{ scale: 0.9, y: 20 }}
        >
          <div className="relative">
            <button 
              onClick={onClose}
              className="absolute top-4 right-4 p-1 rounded-full bg-gray-100 dark:bg-gray-800 text-gray-500 hover:bg-gray-200 dark:hover:bg-gray-700 z-10"
            >
              <X className="h-5 w-5" />
            </button>
            
            <div className="p-6">
              <div className="text-center mb-4">
                <h2 className="text-2xl font-bold">Welcome to LuxAuto</h2>
                <p className="text-muted-foreground">Your premium car rental experience</p>
              </div>
              
              <div className="py-6">
                <AnimatePresence mode="wait">
                  <motion.div
                    key={currentStep}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    className="text-center"
                  >
                    <div className="flex justify-center mb-4">
                      {features[currentStep].icon}
                    </div>
                    <h3 className="text-xl font-semibold mb-2">{features[currentStep].title}</h3>
                    <p className="text-muted-foreground">{features[currentStep].description}</p>
                  </motion.div>
                </AnimatePresence>
              </div>
              
              <div className="flex flex-col gap-3">
                <div className="flex justify-center gap-1 mb-2">
                  {features.map((_, idx) => (
                    <div 
                      key={idx} 
                      className={`h-1.5 rounded-full transition-all ${
                        idx === currentStep ? 'w-6 bg-green-500' : 'w-2 bg-gray-300 dark:bg-gray-700'
                      }`}
                    />
                  ))}
                </div>
                
                <div className="flex gap-3">
                  {currentStep > 0 && (
                    <Button 
                      variant="outline" 
                      onClick={prevStep}
                      className="flex-1"
                    >
                      Previous
                    </Button>
                  )}
                  
                  <Button 
                    onClick={nextStep} 
                    className="flex-1 bg-green-500 hover:bg-green-600 text-white"
                  >
                    {currentStep < features.length - 1 ? 'Next' : 'Got it!'}
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
};

export default WelcomePopup;
