import React, { useState, useEffect } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { Moon, Sun, Menu, X, Bell, User, Search, Settings, ChevronDown, LogIn, Bookmark } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useTheme } from "@/hooks/use-theme";
import { cn } from "@/lib/utils";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import { motion, AnimatePresence } from "framer-motion";
import { Heart } from "lucide-react";

const Navbar = () => {
  const navigate = useNavigate();
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [userName, setUserName] = useState("Preetham R"); // Simulated user name
  const [isLoggedIn, setIsLoggedIn] = useState(true); // Simulated login state
  const location = useLocation();
  const { theme, setTheme, colorScheme, setColorScheme } = useTheme();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const toggleMenu = () => setIsMenuOpen(!isMenuOpen);
  const closeMenu = () => setIsMenuOpen(false);

  const navLinks = [
    { title: "PlaySection", path: "/play" },
    { title: "Home", path: "Home/" },
    { title: "Explore", path: "/explore" },
    { title: "Trending", path: "/trending" },
    { title: "About", path: "/about" },
    { title: "Testimonials", path: "/testimonials" },
    { title: "Contact", path: "/contact" },
    { title: "My Bookings", path: "/bookings" },
  ];

  const colorSchemes = [
    { name: "Vibrant Orange", value: "vibrant-orange" },
    { name: "Black Elegance", value: "black-elegance" },
    { name: "Blush", value: "blush" },
    { name: "Sunset Orange", value: "sunset" },
    { name: "Amber Gold", value: "amber" },
    { name: "Luxury Purple", value: "luxury" },
    { name: "Royal", value: "royal" },
    { name: "Midnight", value: "midnight" },
    { name: "Ocean", value: "ocean" },
    { name: "Forest", value: "forest" },
  ];

  return (
    <header
      className={cn(
        "fixed top-0 left-0 right-0 z-50 transition-all duration-300",
        isScrolled
          ? "bg-background/80 backdrop-blur-md shadow-md py-2"
          : "bg-transparent py-4"
      )}
    >
      <div className="container mx-auto px-4">
        <div className="glass-morphism rounded-full bg-card/70 backdrop-blur-md shadow-lg overflow-hidden border border-border/50">
          <div className="flex items-center justify-between p-3">
            <Link
              to="/"
              className="flex items-center gap-2 font-display font-bold text-xl group"
            >
              <div className={`relative h-10 w-10 bg-${colorScheme} rounded-md flex items-center justify-center overflow-hidden group-hover:scale-105 transition-transform bg-gradient-to-br from-${colorScheme}-400 to-${colorScheme}-600`}>
                <span className={`text-${colorScheme}-foreground font-bold`}>L</span>
                <div className="absolute inset-0 overflow-hidden rounded-md">
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent opacity-20 animate-[aurora_6s_linear_infinite]"></div>
                </div>
              </div>
              <span className="font-display group-hover:opacity-80 transition-opacity bg-clip-text text-transparent bg-gradient-to-r from-blue-500 to-purple-600">LUXAUTO</span>
            </Link>

            {/* Spacer for logo positioning */}
            <div className="flex-1 hidden md:block"></div>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center gap-6">
              {navLinks.map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  className={cn(
                    "font-medium transition-colors hover:text-primary relative py-2",
                    location.pathname === link.path
                      ? `text-${colorScheme} after:absolute after:bottom-0 after:left-0 after:right-0 after:h-0.5 after:bg-${colorScheme}`
                      : "text-foreground/80 hover:text-foreground"
                  )}
                >
                  {link.title}
                </Link>
              ))}
            </nav>

            <div className="hidden md:flex items-center gap-3">
              {!isLoggedIn && (
                <Link to="/login">
                  <Button variant="outline" size="sm" className="rounded-full">
                    <LogIn className="h-4 w-4 mr-1" />
                    Sign In
                  </Button>
                </Link>
              )}
              {/* Compact Search Bar */}
              <div className="relative w-28">
                <Search className="absolute left-2 top-1/2 transform -translate-y-1/2 h-3 w-3 text-muted-foreground" />
                <input
                  type="search"
                  placeholder="Search..."
                  className="w-full h-6 rounded-full pl-7 pr-1.5 bg-muted/50 border-muted focus:border-primary focus:ring-1 focus:ring-primary text-xs"
                />
              </div>
              
              {/* Notifications */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="rounded-full relative">
                    <Bell className="h-5 w-5" />
                    <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center bg-red-500 text-white text-xs rounded-full">
                      3 {/* Example notification count */}
                    </span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-80 glass-morphism rounded-xl">
                  <div className="flex items-center justify-between p-4">
                    <h3 className="font-semibold">Notifications</h3>
                    <Badge variant="outline">New</Badge>
                  </div>
                  <div className="py-2">
                    <div className={`px-4 py-3 hover:bg-muted cursor-pointer border-l-2 border-${colorScheme}`}>
                      <p className="text-sm font-medium">Your booking is confirmed</p>
                      <p className="text-xs text-muted-foreground">BMW 7 Series · 23 March 2024</p>
                    </div>
                    <div className="px-4 py-3 hover:bg-muted cursor-pointer">
                      <p className="text-sm font-medium">Special offer: 20% off on weekday bookings</p>
                      <p className="text-xs text-muted-foreground">Valid until 30 March 2024</p>
                    </div>
                    <div className="px-4 py-3 hover:bg-muted cursor-pointer">
                      <p className="text-sm font-medium">Limited time discount on Luxury cars</p>
                      <p className="text-xs text-muted-foreground">Use code LUXURY25 at checkout</p>
                    </div>
                  </div>
                </DropdownMenuContent>
              </DropdownMenu>

              {/* Bookmark Icon beside Notification */}
              <Link to="/bookmarks">
                <Button variant="ghost" size="icon" className="rounded-full relative">
                  <Bookmark className="h-5 w-5" />
                </Button>
              </Link>

              {/* 3D Animated Theme Toggle */}
              <motion.div
                className={`relative w-12 h-6 rounded-full p-1 cursor-pointer flex items-center ${theme === 'dark' ? 'bg-indigo-900/30' : 'bg-amber-200/30'}`}
                onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <motion.div
                  className={`absolute w-5 h-5 rounded-full flex items-center justify-center ${theme === 'dark' ? 'bg-indigo-500 left-1' : 'bg-amber-400 right-1'}`}
                  layout
                  transition={{ type: "spring", stiffness: 700, damping: 30 }}
                >
                  {theme === "dark" ? (
                    <motion.div
                      animate={{ rotate: 360 }}
                      transition={{ repeat: Infinity, duration: 10, ease: "linear" }}
                    >
                      <Moon className="h-3 w-3 text-indigo-200" />
                    </motion.div>
                  ) : (
                    <motion.div
                      animate={{ rotate: 360 }}
                      transition={{ repeat: Infinity, duration: 20, ease: "linear" }}
                    >
                      <Sun className="h-3 w-3 text-amber-800" />
                    </motion.div>
                  )}
                </motion.div>
              </motion.div>

              {/* Profile Dropdown */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className={`rounded-full hover:bg-${colorScheme}/10`}>
                    <User className="h-5 w-5" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="glass-morphism rounded-xl">
                  <div className="p-3 border-b">
                    <p className="font-medium">Hello, {isLoggedIn ? userName : 'Guest'}</p>
                    <p className="text-xs text-muted-foreground">Hello Preetham R, Welcome</p>
                  </div>
                  <DropdownMenuItem asChild>
                    <Link to="/profile">My Profile</Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link to="/bookings">My Bookings</Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link to="/bookmarks">My Bookmarks</Link> {/* "My Bookmarks" here */}
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link to="/settings">Settings</Link>
                  </DropdownMenuItem>
                  <div className="border-t border-border my-1"></div>
                  {isLoggedIn ? (
                    <DropdownMenuItem onClick={() => { setIsLoggedIn(false); navigate('/'); }}>
                      Logout
                    </DropdownMenuItem>
                  ) : (
                    <DropdownMenuItem asChild>
                      <Link to="/login">Sign In</Link>
                    </DropdownMenuItem>
                  )}
                </DropdownMenuContent>
              </DropdownMenu>
            </div>

            {/* Mobile Navigation Toggle */}
            <div className="flex items-center gap-2 md:hidden">
              {!isLoggedIn && (
                <Link to="/login">
                  <Button variant="outline" size="sm" className="rounded-full">
                    <LogIn className="h-4 w-4 mr-1" />
                    Sign In
                  </Button>
                </Link>
              )}
              {/* Mobile 3D Animated Theme Toggle */}
              <motion.div
                className={`relative w-10 h-5 rounded-full p-1 cursor-pointer flex items-center ${theme === 'dark' ? 'bg-navy-blue/20' : 'bg-yellow/20'}`}
                onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <motion.div
                  className={`absolute w-4 h-4 rounded-full flex items-center justify-center ${theme === 'dark' ? 'bg-white left-0.5' : 'bg-yellow right-0.5'}`}
                  layout
                  transition={{ type: "spring", stiffness: 700, damping: 30 }}
                >
                  {theme === "dark" ? (
                    <Moon className="h-2.5 w-2.5 text-navy-blue" />
                  ) : (
                    <Sun className="h-2.5 w-2.5 text-white" />
                  )}
                </motion.div>
              </motion.div>

              <Button variant="ghost" size="icon" onClick={toggleMenu} className="rounded-full">
                <Menu className="h-5 w-5" />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Navbar;
