
import React from 'react';
import { Link } from 'react-router-dom';
import { PhoneCall, Mail, MapPin, Facebook, Twitter, Instagram, Linkedin } from 'lucide-react';
import { useTheme } from '@/hooks/use-theme';

const Footer = () => {
  const { colorScheme } = useTheme();
  
  return (
    <footer className={`bg-${colorScheme} text-${colorScheme}-foreground pt-16 pb-8`}>
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <Link to="/" className="flex items-center gap-2 font-display font-bold text-xl mb-4">
              <div className={`h-10 w-10 bg-${colorScheme}-foreground rounded-md flex items-center justify-center`}>
                <span className={`text-${colorScheme}`}>L</span>
              </div>
              <span className={`text-${colorScheme}-muted font-display`}>LUXAUTO</span>
            </Link>
            <p className={`text-${colorScheme}-foreground/80 mb-6`}>
              Experience luxury car rentals like never before. Premium vehicles for all your needs.
            </p>
            <div className="flex space-x-4">
              <a href="#" className={`text-${colorScheme}-foreground/80 hover:text-${colorScheme}-muted transition-colors`}>
                <Facebook size={20} />
              </a>
              <a href="#" className={`text-${colorScheme}-foreground/80 hover:text-${colorScheme}-muted transition-colors`}>
                <Twitter size={20} />
              </a>
              <a href="#" className={`text-${colorScheme}-foreground/80 hover:text-${colorScheme}-muted transition-colors`}>
                <Instagram size={20} />
              </a>
              <a href="#" className={`text-${colorScheme}-foreground/80 hover:text-${colorScheme}-muted transition-colors`}>
                <Linkedin size={20} />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/" className={`text-${colorScheme}-foreground/80 hover:text-${colorScheme}-muted transition-colors`}>Home</Link>
              </li>
              <li>
                <Link to="/explore" className={`text-${colorScheme}-foreground/80 hover:text-${colorScheme}-muted transition-colors`}>Explore Cars</Link>
              </li>
              <li>
                <Link to="/about" className={`text-${colorScheme}-foreground/80 hover:text-${colorScheme}-muted transition-colors`}>About Us</Link>
              </li>
              <li>
                <Link to="/bookmarks" className={`text-${colorScheme}-foreground/80 hover:text-${colorScheme}-muted transition-colors`}>My Bookmarks</Link>
              </li>
              <li>
                <Link to="/bookings" className={`text-${colorScheme}-foreground/80 hover:text-${colorScheme}-muted transition-colors`}>My Bookings</Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Car Categories</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/explore?category=electric" className={`text-${colorScheme}-foreground/80 hover:text-${colorScheme}-muted transition-colors`}>Electric & Hybrid</Link>
              </li>
              <li>
                <Link to="/explore?category=luxury" className={`text-${colorScheme}-foreground/80 hover:text-${colorScheme}-muted transition-colors`}>Luxury Cars</Link>
              </li>
              <li>
                <Link to="/explore?category=suv" className={`text-${colorScheme}-foreground/80 hover:text-${colorScheme}-muted transition-colors`}>SUVs</Link>
              </li>
              <li>
                <Link to="/explore?category=sports" className={`text-${colorScheme}-foreground/80 hover:text-${colorScheme}-muted transition-colors`}>Sports Cars</Link>
              </li>
              <li>
                <Link to="/explore?category=commuter" className={`text-${colorScheme}-foreground/80 hover:text-${colorScheme}-muted transition-colors`}>Daily Commuters</Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Contact Us</h3>
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <MapPin className={`h-5 w-5 text-${colorScheme}-muted mt-0.5`} />
                <p className={`text-${colorScheme}-foreground/80`}>
                  123 Luxauto Lane, Automotive District, Mysore, India
                </p>
              </div>
              <div className="flex items-center gap-3">
                <PhoneCall className={`h-5 w-5 text-${colorScheme}-muted`} />
                <p className={`text-${colorScheme}-foreground/80`}>+91 6363-969591</p>
              </div>
              <div className="flex items-center gap-3">
                <Mail className={`h-5 w-5 text-${colorScheme}-muted`} />
                <p className={`text-${colorScheme}-foreground/80`}>contact@luxauto.in</p>
              </div>
            </div>
          </div>
        </div>
        
        <div className={`border-t border-${colorScheme}-foreground/10 mt-12 pt-8 text-center`}>
          <p className={`text-${colorScheme}-foreground/60 text-sm`}>
            &copy; {new Date().getFullYear()} LuxAuto. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
