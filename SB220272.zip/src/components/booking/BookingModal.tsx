
import React, { useState } from 'react';
import { Calendar as CalendarIcon, Clock, User, MapPin, X, CreditCard, Tag, CheckCircle2, Info, ShieldCheck, Upload, Camera, Gift, FileText, FileCheck, AlertTriangle } from 'lucide-react';
import { format, addDays } from 'date-fns';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';
import { CarType } from '@/types/car';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Textarea } from '@/components/ui/textarea';

interface BookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  car: CarType;
}

const durations = [
  { id: 'hourly', label: 'Hourly', multiplier: 1/24, minHours: 4 },
  { id: 'daily', label: 'Daily', multiplier: 1, minDays: 1 },
  { id: 'weekly', label: 'Weekly', multiplier: 7, discount: 0.15, minDays: 7 }
];

interface Extra {
  id: string;
  name: string;
  price: number;
  selected: boolean;
  description: string;
}

// Free complementary items
const complementaryItems = [
  "Bottled water",
  "Tissues and wet wipes",
  "Phone charger (multiple types)",
  "Hand sanitizer",
  "Reading materials",
  "Complimentary snacks",
  "Umbrella"
];

// Required documents
const requiredDocuments = [
  "Government ID (Aadhar/PAN/Voter ID)",
  "Valid Driver's License",
  "Address Proof",
  "Passport sized photographs (2)",
  "Security deposit authorization"
];

// Popular pickup/drop locations
const popularLocations = [
  "Airport Terminal 1",
  "Airport Terminal 2",
  "Central Railway Station",
  "Downtown City Center",
  "Business District",
  "Mall of India",
  "Luxury Hotel Zone"
];

const BookingModal: React.FC<BookingModalProps> = ({ isOpen, onClose, car }) => {
  const { toast } = useToast();
  const [startDate, setStartDate] = useState<Date | undefined>(new Date());
  const [startTime, setStartTime] = useState("10:00 AM");
  const [endDate, setEndDate] = useState<Date | undefined>(addDays(new Date(), 1));
  const [endTime, setEndTime] = useState("10:00 AM");
  const [pickupLocation, setPickupLocation] = useState('');
  const [dropLocation, setDropLocation] = useState('');
  const [duration, setDuration] = useState('daily');
  const [paymentMethod, setPaymentMethod] = useState('creditCard');
  const [promoCode, setPromoCode] = useState('');
  const [promoApplied, setPromoApplied] = useState(false);
  const [agreeTerms, setAgreeTerms] = useState(false);
  
  // Personal details
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [emergencyPhone, setEmergencyPhone] = useState('');
  const [idType, setIdType] = useState('');
  const [idNumber, setIdNumber] = useState('');
  const [address, setAddress] = useState('');
  const [age, setAge] = useState('');
  const [gender, setGender] = useState('');
  
  // Document uploads
  const [documentsUploaded, setDocumentsUploaded] = useState({
    idProof: false,
    driverLicense: false,
    addressProof: false,
    photos: false
  });
  
  const [extras, setExtras] = useState<Extra[]>([
    { 
      id: 'childSeat', 
      name: 'Child Seat', 
      price: 500, 
      selected: false,
      description: 'Safety-certified child seat suitable for ages 1-4 years'
    },
    { 
      id: 'gps', 
      name: 'GPS Navigation', 
      price: 300, 
      selected: false,
      description: 'Premium GPS system with offline maps and voice guidance'
    },
    { 
      id: 'driver', 
      name: 'Chauffeur Service', 
      price: 1500, 
      selected: false,
      description: 'Professional driver with excellent knowledge of local routes'
    },
    { 
      id: 'wifi', 
      name: 'Wi-Fi Hotspot', 
      price: 250, 
      selected: false,
      description: 'High-speed 4G internet access for all your devices'
    },
    { 
      id: 'insurance', 
      name: 'Premium Insurance', 
      price: 700, 
      selected: false,
      description: 'Extended coverage with zero deductible for complete peace of mind'
    },
    { 
      id: 'carwash', 
      name: 'Car Wash Service', 
      price: 400, 
      selected: false,
      description: "We'll wash the car daily for you"
    },
    { 
      id: 'refreshments', 
      name: 'Premium Refreshments', 
      price: 350, 
      selected: false,
      description: 'Upgraded selection of gourmet snacks and premium beverages'
    },
    { 
      id: 'babychair', 
      name: 'Baby Chair', 
      price: 600, 
      selected: false,
      description: 'Specialized seat for infants under 12 months'
    },
    { 
      id: 'petprotection', 
      name: 'Pet Protection', 
      price: 800, 
      selected: false,
      description: 'Pet-friendly protection covers for seats and floors'
    },
  ]);

  const [currentStep, setCurrentStep] = useState(1);
  const totalSteps = 5;

  const timeOptions = [
    "6:00 AM", "7:00 AM", "8:00 AM", "9:00 AM", "10:00 AM", "11:00 AM", "12:00 PM",
    "1:00 PM", "2:00 PM", "3:00 PM", "4:00 PM", "5:00 PM", "6:00 PM", "7:00 PM",
    "8:00 PM", "9:00 PM", "10:00 PM"
  ];

  const nextStep = () => {
    if (currentStep === 1) {
      if (!startDate || !endDate || !pickupLocation || !dropLocation || !startTime || !endTime) {
        toast({
          title: "Missing Information",
          description: "Please fill all required fields in this step.",
          variant: "destructive"
        });
        return;
      }
    }
    
    if (currentStep === 2) {
      if (!fullName || !email || !phone || !emergencyPhone || !age || !gender) {
        toast({
          title: "Missing Information",
          description: "Please fill all required personal details.",
          variant: "destructive"
        });
        return;
      }
    }
    
    if (currentStep === 3) {
      // Documents validation is optional at this step
    }
    
    if (currentStep < totalSteps) {
      setCurrentStep(currentStep + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };
  
  const handleUploadDocument = (docType: keyof typeof documentsUploaded) => {
    // Simulate document upload
    toast({
      title: "Document Uploaded",
      description: `Your ${docType.replace(/([A-Z])/g, ' $1').toLowerCase()} has been uploaded successfully.`
    });
    
    setDocumentsUploaded(prev => ({
      ...prev,
      [docType]: true
    }));
  };

  const calculatePrice = () => {
    if (!startDate || !endDate) return 0;
    
    // Calculate days/hours difference
    const diffTime = Math.abs(endDate.getTime() - startDate.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    const diffHours = Math.ceil(diffTime / (1000 * 60 * 60));
    
    // Find selected duration option
    const durationOption = durations.find(d => d.id === duration);
    if (!durationOption) return 0;
    
    // Calculate base price
    let basePrice = 0;
    if (duration === 'hourly') {
      const hours = Math.max(diffHours, durationOption.minHours || 4);
      basePrice = (car.price / 8) * hours; // Hourly rate is 1/8th of daily
    } else if (duration === 'daily') {
      const days = Math.max(diffDays, durationOption.minDays || 1);
      basePrice = car.price * days;
    } else if (duration === 'weekly') {
      const weeks = Math.ceil(diffDays / 7);
      basePrice = car.price * weeks * 5.5; // Weekly rate is 5.5x daily
    }
    
    // Add extras
    const extrasTotal = extras
      .filter(extra => extra.selected)
      .reduce((total, extra) => total + extra.price, 0);
    
    // Apply promo code (example: 10% off)
    let finalPrice = basePrice + extrasTotal;
    if (promoApplied) {
      finalPrice = finalPrice * 0.9; // 10% discount
    }
    
    return Math.round(finalPrice);
  };

  const toggleExtra = (extraId: string) => {
    setExtras(extras.map(extra => 
      extra.id === extraId ? { ...extra, selected: !extra.selected } : extra
    ));
  };

  const handleApplyPromo = () => {
    if (promoCode.toLowerCase() === 'lux10') {
      setPromoApplied(true);
      toast({
        title: "Promo Applied!",
        description: "You got 10% off on your booking.",
      });
    } else {
      toast({
        title: "Invalid Promo Code",
        description: "The promo code you entered is not valid.",
        variant: "destructive"
      });
    }
  };

  const [isSubmitting, setIsSubmitting] = useState(false);

  const validateForm = () => {
    const errors = [];
    
    if (!startDate) errors.push('Pickup date is required');
    if (!endDate) errors.push('Return date is required');
    if (startDate && endDate && startDate >= endDate) {
      errors.push('Return date must be after pickup date');
    }
    if (!pickupLocation) errors.push('Pickup location is required');
    if (!dropLocation) errors.push('Drop location is required');
    if (!fullName) errors.push('Full name is required');
    if (!email || !/^\S+@\S+\.\S+$/.test(email)) {
      errors.push('Valid email is required');
    }
    if (!phone || !/^\d{10}$/.test(phone)) {
      errors.push('Valid 10-digit phone number is required');
    }
    if (!agreeTerms) errors.push('You must agree to terms and conditions');
    
    return errors;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Validate form
    const errors = validateForm();
    if (errors.length > 0) {
      toast({
        title: "Form Errors",
        description: (
          <ul className="list-disc pl-5">
            {errors.map((error, i) => (
              <li key={i}>{error}</li>
            ))}
          </ul>
        ),
        variant: "destructive"
      });
      setIsSubmitting(false);
      return;
    }
    
    try {
      // In a real app, this would call an API
      const bookingId = `LUX-${Math.floor(100000 + Math.random() * 900000)}`;
      const booking = {
        id: bookingId,
        car,
        startDate,
        endDate,
        pickupLocation,
        dropLocation,
        totalPrice: calculatePrice(),
        status: 'confirmed'
      };
      
      // Save to localStorage for demo purposes
      const bookings = JSON.parse(localStorage.getItem('bookings') || '[]');
      bookings.push(booking);
      localStorage.setItem('bookings', JSON.stringify(bookings));

      toast({
        title: "Booking Successful!",
        description: `You've booked the ${car.name}. Booking ID: ${bookingId}`,
      });
      
      onClose();
    } catch (error) {
      toast({
        title: "Booking Failed",
        description: "There was an error processing your booking. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const calculateInitialBookingFee = () => {
    return Math.round(calculatePrice() * 0.2); // 20% of total price
  };
  
  const calculateSecurityDeposit = () => {
    return car.price * 3; // Increased to 3x daily price
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl p-0 overflow-hidden">
        <div className="flex flex-col md:flex-row h-full">
          {/* Car Image and Info */}
          <div className="w-full md:w-2/5 bg-orange/5 dark:bg-orange/10 p-6 flex flex-col justify-between">
            <div>
              <h3 className="text-xl font-bold mb-2">{car.name}</h3>
              <p className="text-muted-foreground mb-4">{car.categoryName}</p>
              
              <div className="space-y-4 mb-4">
                {/* Car Gallery */}
                <div className="space-y-2">
                  <div className="aspect-video rounded-lg overflow-hidden relative">
                    <img src={car.image} alt={car.name} className="w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black/50"></div>
                    <div className="absolute bottom-2 right-2 bg-black/60 text-white px-2 py-1 rounded text-xs">
                      {car.specifications?.mileage} • {car.specifications?.seatingCapacity} Seats
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-3 gap-2">
                    <div className="rounded-md overflow-hidden aspect-square">
                      <img 
                        src="https://images.unsplash.com/photo-1563720223185-11326f53d3b2?w=500&auto=format&fit=crop"
                        alt={`${car.name} interior`}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="rounded-md overflow-hidden aspect-square">
                      <img 
                        src="https://images.unsplash.com/photo-1544739313-6fad02554c5e?w=500&auto=format&fit=crop"
                        alt={`${car.name} dashboard`}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="rounded-md overflow-hidden aspect-square">
                      <img 
                        src="https://images.unsplash.com/photo-1591293836027-e05b48473b96?w=500&auto=format&fit=crop"
                        alt={`${car.name} rear view`}
                        className="w-full h-full object-cover"
                      />
                    </div>
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Base Rate:</span>
                  <span>₹{car.price}/day</span>
                </div>
                {extras.filter(e => e.selected).map(extra => (
                  <div key={extra.id} className="flex justify-between">
                    <span className="text-muted-foreground">{extra.name}:</span>
                    <span>₹{extra.price}</span>
                  </div>
                ))}
                {promoApplied && (
                  <div className="flex justify-between text-green-500">
                    <span>Promo (LUX10):</span>
                    <span>-10%</span>
                  </div>
                )}
                
                <Separator className="my-2" />
                
                <div className="flex justify-between font-bold">
                  <span>Total:</span>
                  <span className="text-orange">₹{calculatePrice()}</span>
                </div>
                
                <div className="text-xs text-muted-foreground pt-1">
                  <p>* Includes taxes and fees</p>
                  <p>* Initial booking fee: ₹{calculateInitialBookingFee()} (20% of total)</p>
                  <p>* Security deposit: ₹{calculateSecurityDeposit()} (refundable)</p>
                  <p className="text-red-500 font-medium">* Documents required: Original ID proof + 2 passport photos</p>
                  <p className="text-green-600 font-medium">
                    * Current rate: {duration === 'hourly' ? '₹'+(car.price/8).toFixed(0)+'/hr' :
                                   duration === 'daily' ? '₹'+car.price+'/day' :
                                   '₹'+(car.price*5.5).toFixed(0)+'/week (save 15%)'}
                  </p>
                </div>
              </div>
            </div>

            {/* Complementary Items */}
            <div className="mt-4 bg-card rounded-lg p-4">
              <h4 className="text-sm font-medium flex items-center gap-2 mb-2">
                <Gift className="h-4 w-4 text-orange" /> Complementary Items
              </h4>
              <ul className="text-xs text-muted-foreground grid grid-cols-2 gap-2">
                {complementaryItems.map((item, index) => (
                  <li key={index} className="flex items-center gap-1">
                    <CheckCircle2 className="h-3 w-3 text-green-500" /> {item}
                  </li>
                ))}
              </ul>
            </div>

            {/* Progress Indicator */}
            <div className="mt-6">
              <div className="flex justify-between mb-2">
                {Array.from({ length: totalSteps }).map((_, idx) => (
                  <div 
                    key={idx} 
                    className={cn(
                      "flex items-center justify-center w-8 h-8 rounded-full text-sm font-medium",
                      currentStep > idx 
                        ? "bg-orange text-white" 
                        : currentStep === idx + 1
                          ? "border-2 border-orange text-orange"
                          : "border border-muted-foreground/30 text-muted-foreground"
                    )}
                  >
                    {idx + 1}
                  </div>
                ))}
              </div>
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>Booking</span>
                <span>Details</span>
                <span>Documents</span>
                <span>Extras</span>
                <span>Payment</span>
              </div>
            </div>
          </div>
          
          {/* Booking Form */}
          <div className="w-full md:w-3/5 p-6 max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="text-2xl">Book Your Car</DialogTitle>
              <DialogDescription>
                {currentStep === 1 && "Enter your booking details and schedule"}
                {currentStep === 2 && "Please provide your personal information"}
                {currentStep === 3 && "Upload required documents (originals must be presented at pickup)"}
                {currentStep === 4 && "Customize your experience with add-ons"}
                {currentStep === 5 && "Complete your payment details to confirm"}
              </DialogDescription>
            </DialogHeader>
            
            <form onSubmit={handleSubmit} className="space-y-4 mt-6">
              {/* Step 1: Booking Details */}
              {currentStep === 1 && (
                <>
                  {/* Duration Type */}
                  <div className="space-y-2">
                    <Label htmlFor="duration">Rental Type</Label>
                    <Tabs 
                      value={duration} 
                      onValueChange={setDuration}
                      className="w-full"
                    >
                      <TabsList className="w-full">
                        {durations.map(option => (
                          <TabsTrigger 
                            key={option.id} 
                            value={option.id}
                            className="flex-1"
                          >
                            {option.label}
                            {option.discount && (
                              <span className="ml-1 text-xs bg-green-500/10 text-green-600 dark:text-green-400 px-1.5 py-0.5 rounded-full">
                                -{option.discount * 100}%
                              </span>
                            )}
                          </TabsTrigger>
                        ))}
                      </TabsList>
                    </Tabs>
                  </div>
                  
                  {/* Date and Time Range Picker */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="pickup-date">Pickup Date</Label>
                      <Popover>
                        <PopoverTrigger asChild>
                          <Button
                            variant="outline"
                            id="pickup-date"
                            className={cn(
                              "w-full justify-start text-left font-normal",
                              !startDate && "text-muted-foreground"
                            )}
                          >
                            <CalendarIcon className="mr-2 h-4 w-4" />
                            {startDate ? format(startDate, "PPP") : <span>Pick a date</span>}
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={startDate}
                            onSelect={setStartDate}
                            initialFocus
                            disabled={(date) => date < new Date()}
                            className="p-3 pointer-events-auto"
                          />
                        </PopoverContent>
                      </Popover>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="pickup-time">Pickup Time</Label>
                      <Select value={startTime} onValueChange={setStartTime}>
                        <SelectTrigger id="pickup-time">
                          <Clock className="mr-2 h-4 w-4" />
                          <SelectValue placeholder="Select time" />
                        </SelectTrigger>
                        <SelectContent>
                          {timeOptions.map(time => (
                            <SelectItem key={`pickup-${time}`} value={time}>{time}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="return-date">Return Date</Label>
                      <Popover>
                        <PopoverTrigger asChild>
                          <Button
                            variant="outline"
                            id="return-date"
                            className={cn(
                              "w-full justify-start text-left font-normal",
                              !endDate && "text-muted-foreground"
                            )}
                          >
                            <CalendarIcon className="mr-2 h-4 w-4" />
                            {endDate ? format(endDate, "PPP") : <span>Pick a date</span>}
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={endDate}
                            onSelect={setEndDate}
                            initialFocus
                            disabled={(date) => date < (startDate || new Date())}
                            className="p-3 pointer-events-auto"
                          />
                        </PopoverContent>
                      </Popover>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="return-time">Return Time</Label>
                      <Select value={endTime} onValueChange={setEndTime}>
                        <SelectTrigger id="return-time">
                          <Clock className="mr-2 h-4 w-4" />
                          <SelectValue placeholder="Select time" />
                        </SelectTrigger>
                        <SelectContent>
                          {timeOptions.map(time => (
                            <SelectItem key={`return-${time}`} value={time}>{time}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                
                  {/* Location Fields */}
                  <div className="space-y-2">
                    <Label htmlFor="pickup-location">Pickup Location</Label>
                    <div className="flex items-center gap-2">
                      <MapPin className="h-4 w-4 text-muted-foreground" />
                      <Input
                        placeholder="Enter pickup location (start typing for suggestions)"
                        value={pickupLocation}
                        onChange={(e) => setPickupLocation(e.target.value)}
                        list="location-suggestions"
                        className="flex-1"
                      />
                    </div>
                    <datalist id="location-suggestions">
                      <option value="same-as-pickup">Same as pickup location</option>
                      {popularLocations.map(location => (
                        <option key={location} value={location} />
                      ))}
                    </datalist>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="drop-location">Drop Location</Label>
                    <div className="flex items-center gap-2">
                      <MapPin className="h-4 w-4 text-muted-foreground" />
                      <Input
                        placeholder="Enter drop location (start typing for suggestions)"
                        value={dropLocation}
                        onChange={(e) => setDropLocation(e.target.value)}
                        list="location-suggestions"
                        className="flex-1"
                      />
                    </div>
                  </div>
                </>
              )}
              
              {/* Step 2: Personal Details */}
              {currentStep === 2 && (
                <>
                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">Personal Information</h3>
                    <p className="text-sm text-muted-foreground">Enter your details for booking verification</p>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="full-name">Full Name</Label>
                        <Input 
                          id="full-name" 
                          placeholder="As per ID proof" 
                          value={fullName}
                          onChange={(e) => setFullName(e.target.value)}
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="email">Email Address</Label>
                        <Input 
                          id="email" 
                          type="email" 
                          placeholder="your@email.com" 
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="phone">Phone Number</Label>
                        <Input 
                          id="phone" 
                          placeholder="+91 6363-969591" 
                          value={phone}
                          onChange={(e) => setPhone(e.target.value)}
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="emergency-contact">Emergency Contact</Label>
                        <Input 
                          id="emergency-contact" 
                          placeholder="Alternative phone number" 
                          value={emergencyPhone}
                          onChange={(e) => setEmergencyPhone(e.target.value)}
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="age">Age</Label>
                        <Input
                          id="age"
                          type="number"
                          placeholder="Must be 21 or older to book"
                          value={age}
                          onChange={(e) => setAge(e.target.value)}
                        />
                        {age && parseInt(age) < 21 && (
                          <p className="text-xs text-destructive mt-1">You must be 21 or older to rent this vehicle</p>
                        )}
                      </div>
                      
                      <div className="space-y-2">
                        <Label>Gender</Label>
                        <RadioGroup value={gender} onValueChange={setGender} className="flex gap-4">
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="male" id="male" />
                            <Label htmlFor="male">Male</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="female" id="female" />
                            <Label htmlFor="female">Female</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="batman" id="batman" />
                            <Label htmlFor="batman">Batman</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="other" id="other" />
                            <Label htmlFor="other">Other</Label>
                          </div>
                        </RadioGroup>
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="address">Residential Address</Label>
                      <Textarea 
                        id="address" 
                        placeholder="Enter your full address" 
                        value={address}
                        onChange={(e) => setAddress(e.target.value)}
                      />
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="id-type">ID Type</Label>
                        <Select value={idType} onValueChange={setIdType}>
                          <SelectTrigger id="id-type">
                            <SelectValue placeholder="Select ID type" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="aadhar">Aadhar Card</SelectItem>
                            <SelectItem value="pan">PAN Card</SelectItem>
                            <SelectItem value="passport">Passport</SelectItem>
                            <SelectItem value="voter">Voter ID</SelectItem>
                            <SelectItem value="driving">Driving License</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="id-number">ID Number</Label>
                        <Input 
                          id="id-number" 
                          placeholder="Enter your ID number" 
                          value={idNumber}
                          onChange={(e) => setIdNumber(e.target.value)}
                        />
                      </div>
                    </div>
                  </div>
                </>
              )}
              
              {/* Step 3: Document Verification */}
              {currentStep === 3 && (
                <>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <h3 className="text-lg font-medium">Document Verification</h3>
                      <span className="text-xs text-orange bg-orange/10 px-2 py-1 rounded-full">Required for booking</span>
                    </div>
                    <p className="text-sm text-muted-foreground">Upload the following documents for verification</p>
                    
                    <div className="space-y-4 mt-6">
                      <div className="space-y-2">
                        <div className="flex items-start space-x-3">
                          <AlertTriangle className="h-5 w-5 text-orange mt-1" />
                          <div className="text-sm">
                            <p className="font-medium mb-1">Required Documents</p>
                            <ul className="list-disc pl-5 space-y-1 text-muted-foreground">
                              {requiredDocuments.map((doc, idx) => (
                                <li key={idx}>{doc}</li>
                              ))}
                            </ul>
                          </div>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                        <div className={`border rounded-lg p-4 ${documentsUploaded.idProof ? 'border-green-500 bg-green-50 dark:bg-green-950/20' : 'border-dashed'}`}>
                          <div className="flex flex-col items-center justify-center space-y-2">
                            {documentsUploaded.idProof ? (
                              <>
                                <FileCheck className="h-8 w-8 text-green-500" />
                                <p className="text-sm font-medium text-green-600 dark:text-green-400">ID Proof Uploaded</p>
                              </>
                            ) : (
                              <>
                                <FileText className="h-8 w-8 text-muted-foreground" />
                                <p className="text-sm font-medium">ID Proof</p>
                                <p className="text-xs text-muted-foreground text-center">Aadhar Card, PAN Card, or Passport</p>
                              </>
                            )}
                            <Button 
                              onClick={() => handleUploadDocument('idProof')} 
                              variant={documentsUploaded.idProof ? "outline" : "default"}
                              type="button"
                              size="sm"
                              className="mt-2"
                            >
                              <Upload className="h-4 w-4 mr-2" />
                              {documentsUploaded.idProof ? 'Re-upload' : 'Upload'}
                            </Button>
                          </div>
                        </div>
                        
                        <div className={`border rounded-lg p-4 ${documentsUploaded.driverLicense ? 'border-green-500 bg-green-50 dark:bg-green-950/20' : 'border-dashed'}`}>
                          <div className="flex flex-col items-center justify-center space-y-2">
                            {documentsUploaded.driverLicense ? (
                              <>
                                <FileCheck className="h-8 w-8 text-green-500" />
                                <p className="text-sm font-medium text-green-600 dark:text-green-400">Driver's License Uploaded</p>
                              </>
                            ) : (
                              <>
                                <FileText className="h-8 w-8 text-muted-foreground" />
                                <p className="text-sm font-medium">Driver's License</p>
                                <p className="text-xs text-muted-foreground text-center">Valid driving license (front and back)</p>
                              </>
                            )}
                            <Button 
                              onClick={() => handleUploadDocument('driverLicense')} 
                              variant={documentsUploaded.driverLicense ? "outline" : "default"}
                              type="button"
                              size="sm"
                              className="mt-2"
                            >
                              <Upload className="h-4 w-4 mr-2" />
                              {documentsUploaded.driverLicense ? 'Re-upload' : 'Upload'}
                            </Button>
                          </div>
                        </div>
                        
                        <div className={`border rounded-lg p-4 ${documentsUploaded.addressProof ? 'border-green-500 bg-green-50 dark:bg-green-950/20' : 'border-dashed'}`}>
                          <div className="flex flex-col items-center justify-center space-y-2">
                            {documentsUploaded.addressProof ? (
                              <>
                                <FileCheck className="h-8 w-8 text-green-500" />
                                <p className="text-sm font-medium text-green-600 dark:text-green-400">Address Proof Uploaded</p>
                              </>
                            ) : (
                              <>
                                <FileText className="h-8 w-8 text-muted-foreground" />
                                <p className="text-sm font-medium">Address Proof</p>
                                <p className="text-xs text-muted-foreground text-center">Utility bill, bank statement, etc.</p>
                              </>
                            )}
                            <Button 
                              onClick={() => handleUploadDocument('addressProof')} 
                              variant={documentsUploaded.addressProof ? "outline" : "default"}
                              type="button"
                              size="sm"
                              className="mt-2"
                            >
                              <Upload className="h-4 w-4 mr-2" />
                              {documentsUploaded.addressProof ? 'Re-upload' : 'Upload'}
                            </Button>
                          </div>
                        </div>
                        
                        <div className={`border rounded-lg p-4 ${documentsUploaded.photos ? 'border-green-500 bg-green-50 dark:bg-green-950/20' : 'border-dashed'}`}>
                          <div className="flex flex-col items-center justify-center space-y-2">
                            {documentsUploaded.photos ? (
                              <>
                                <FileCheck className="h-8 w-8 text-green-500" />
                                <p className="text-sm font-medium text-green-600 dark:text-green-400">Photos Uploaded</p>
                              </>
                            ) : (
                              <>
                                <Camera className="h-8 w-8 text-muted-foreground" />
                                <p className="text-sm font-medium">Passport Size Photos</p>
                                <p className="text-xs text-muted-foreground text-center">Two recent passport size photographs</p>
                              </>
                            )}
                            <Button 
                              onClick={() => handleUploadDocument('photos')} 
                              variant={documentsUploaded.photos ? "outline" : "default"}
                              type="button"
                              size="sm"
                              className="mt-2"
                            >
                              <Upload className="h-4 w-4 mr-2" />
                              {documentsUploaded.photos ? 'Re-upload' : 'Upload'}
                            </Button>
                          </div>
                        </div>
                      </div>
                      
                      <div className="mt-4 p-3 bg-orange/10 rounded-lg flex items-start gap-3">
                        <Info className="h-5 w-5 text-orange flex-shrink-0 mt-0.5" />
                        <div className="text-sm">
                          <p className="font-medium mb-1">Document Verification Process</p>
                          <p className="text-muted-foreground">
                            Your documents will be reviewed within 2-4 hours. You'll receive a confirmation email once verification is complete. 
                            For faster processing, please ensure that all documents are clearly visible and not expired.
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </>
              )}
              
              {/* Step 4: Extras */}
              {currentStep === 4 && (
                <>
                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">Additional Features</h3>
                    <p className="text-sm text-muted-foreground">Enhance your rental experience with premium add-ons</p>
                    
                    <div className="space-y-4">
                      {extras.map(extra => (
                        <div key={extra.id} className="flex items-start space-x-3 p-3 rounded-lg border hover:bg-muted/50 transition-colors">
                          <Checkbox
                            id={extra.id}
                            checked={extra.selected}
                            onCheckedChange={() => toggleExtra(extra.id)}
                            className="mt-1"
                          />
                          <div className="flex-1">
                            <Label htmlFor={extra.id} className="cursor-pointer flex items-center">
                              <span>{extra.name}</span>
                              <span className="ml-2 text-sm font-medium text-orange">+₹{extra.price}</span>
                            </Label>
                            <p className="text-sm text-muted-foreground mt-1">{extra.description}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  <div className="space-y-2 mt-6">
                    <Label htmlFor="promo">Promo Code</Label>
                    <div className="flex gap-2">
                      <Input
                        id="promo"
                        placeholder="Enter promo code"
                        value={promoCode}
                        onChange={(e) => setPromoCode(e.target.value)}
                        disabled={promoApplied}
                      />
                      <Button 
                        type="button" 
                        variant={promoApplied ? "outline" : "default"} 
                        onClick={handleApplyPromo}
                        disabled={!promoCode || promoApplied}
                      >
                        {promoApplied ? (
                          <>
                            <CheckCircle2 className="mr-1 h-4 w-4" />
                            Applied
                          </>
                        ) : (
                          <>
                            <Tag className="mr-1 h-4 w-4" />
                            Apply
                          </>
                        )}
                      </Button>
                    </div>
                    {promoApplied && (
                      <p className="text-xs text-green-600 dark:text-green-400">
                        10% discount has been applied to your booking!
                      </p>
                    )}
                    {!promoApplied && (
                      <p className="text-xs text-muted-foreground">
                        Try code "LUX10" for 10% off your booking
                      </p>
                    )}
                  </div>
                </>
              )}
              
              {/* Step 5: Payment */}
              {currentStep === 5 && (
                <>
                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">Payment Method</h3>
                    
                    <Tabs 
                      value={paymentMethod} 
                      onValueChange={setPaymentMethod}
                      className="w-full"
                    >
                      <TabsList className="w-full">
                        <TabsTrigger value="creditCard" className="flex-1">
                          <CreditCard className="mr-2 h-4 w-4" />
                          Credit Card
                        </TabsTrigger>
                        <TabsTrigger value="upi" className="flex-1">
                          <span className="mr-2">₹</span>
                          UPI
                        </TabsTrigger>
                        <TabsTrigger value="netBanking" className="flex-1">
                          <Building className="mr-2 h-4 w-4" />
                          Net Banking
                        </TabsTrigger>
                      </TabsList>
                    </Tabs>
                    
                    <div className="p-4 border rounded-lg bg-muted/50">
                      {paymentMethod === 'creditCard' && (
                        <div className="space-y-4">
                          <div className="space-y-2">
                            <Label htmlFor="card-number">Card Number</Label>
                            <Input id="card-number" placeholder="1234 5678 9012 3456" />
                          </div>
                          <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-2">
                              <Label htmlFor="expiry">Expiry Date</Label>
                              <Input id="expiry" placeholder="MM/YY" />
                            </div>
                            <div className="space-y-2">
                              <Label htmlFor="cvv">CVV</Label>
                              <Input id="cvv" placeholder="123" />
                            </div>
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="name">Cardholder Name</Label>
                            <Input id="name" placeholder="John Doe" />
                          </div>
                        </div>
                      )}
                      
                      {paymentMethod === 'upi' && (
                        <div className="space-y-4">
                          <div className="space-y-2">
                            <Label htmlFor="upi-id">UPI ID</Label>
                            <Input id="upi-id" placeholder="yourname@upi" />
                          </div>
                          <div className="bg-orange/5 p-3 rounded-lg flex items-start gap-2">
                            <Info className="h-4 w-4 text-orange mt-1" />
                            <p className="text-sm text-muted-foreground">
                              You will receive a payment request on your UPI app to complete the transaction.
                            </p>
                          </div>
                        </div>
                      )}
                      
                      {paymentMethod === 'netBanking' && (
                        <div className="space-y-4">
                          <div className="space-y-2">
                            <Label htmlFor="bank">Select Bank</Label>
                            <Select>
                              <SelectTrigger id="bank">
                                <SelectValue placeholder="Select your bank" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="hdfc">HDFC Bank</SelectItem>
                                <SelectItem value="sbi">State Bank of India</SelectItem>
                                <SelectItem value="icici">ICICI Bank</SelectItem>
                                <SelectItem value="axis">Axis Bank</SelectItem>
                                <SelectItem value="kotak">Kotak Mahindra Bank</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Payment Summary */}
                    <div className="space-y-3 border rounded-lg p-4">
                      <h4 className="font-medium">Payment Summary</h4>
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Initial booking fee (20%)</span>
                        <span>₹{calculateInitialBookingFee()}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Security deposit (refundable)</span>
                        <span>₹{calculateSecurityDeposit()}</span>
                      </div>
                      <Separator />
                      <div className="flex justify-between font-medium">
                        <span>Amount to pay now</span>
                        <span className="text-orange">₹{calculateInitialBookingFee() + calculateSecurityDeposit()}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Remaining balance (at pickup)</span>
                        <span>₹{calculatePrice() - calculateInitialBookingFee()}</span>
                      </div>
                    </div>

                    {/* Booking Policy */}
                    <div className="space-y-3 mt-2">
                      <div className="flex items-start space-x-3">
                        <Info className="h-4 w-4 mt-1 text-muted-foreground" />
                        <div className="text-xs text-muted-foreground space-y-1">
                          <p>• Free cancellation up to 24 hours before pickup (full refund including deposit)</p>
                          <p>• 50% refund for cancellations within 24 hours (security deposit fully refunded)</p>
                          <p>• Security deposit refunded within 3 business days after return</p>
                          <p>• Please bring original documents for verification at pickup</p>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-start space-x-3 pt-2">
                      <Checkbox 
                        id="terms" 
                        checked={agreeTerms}
                        onCheckedChange={(checked) => setAgreeTerms(checked === true)}
                      />
                      <div className="space-y-1">
                        <Label htmlFor="terms" className="text-sm font-normal">
                          I agree to the <a href="#" className="text-orange underline">Terms and Conditions</a> and <a href="#" className="text-orange underline">Privacy Policy</a>
                        </Label>
                      </div>
                    </div>
                  </div>
                </>
              )}
              
              <DialogFooter className="pt-4 flex justify-between">
                {currentStep > 1 && (
                  <Button type="button" variant="outline" onClick={prevStep}>
                    Back
                  </Button>
                )}
                
                {currentStep < totalSteps ? (
                  <Button type="button" onClick={nextStep} className="ml-auto bg-orange hover:bg-orange/90 text-white">
                    Next Step
                  </Button>
                ) : (
                  <Button 
                    type="submit" 
                    disabled={!agreeTerms}
                    className="ml-auto bg-orange hover:bg-orange/90 text-white"
                  >
                    <ShieldCheck className="mr-2 h-4 w-4" />
                    Complete Booking
                  </Button>
                )}
              </DialogFooter>
            </form>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

// Import for the Building icon
function Building(props) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <rect width="16" height="20" x="4" y="2" rx="2" ry="2" />
      <path d="M9 22v-4h6v4" />
      <path d="M8 6h.01" />
      <path d="M16 6h.01" />
      <path d="M8 10h.01" />
      <path d="M16 10h.01" />
      <path d="M8 14h.01" />
      <path d="M16 14h.01" />
    </svg>
  );
}

export default BookingModal;
