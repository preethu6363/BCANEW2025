import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useTheme } from '@/hooks/use-theme';

interface SplashScreenProps {
  onFinish: () => void;
}

const SplashScreen: React.FC<SplashScreenProps> = ({ onFinish }) => {
  const [progress, setProgress] = useState(0);
  const [showSplash, setShowSplash] = useState(true);
  const { theme } = useTheme();

  useEffect(() => {
    const timer = setTimeout(() => {
      setShowSplash(false);
      setTimeout(onFinish, 500);
    }, 5000); // Increased time to allow for engine sound

    const interval = setInterval(() => {
      setProgress(prev => {
        const newProgress = prev + (100 - prev) * 0.08;
        return Math.min(newProgress, 100);
      });
    }, 100);

    return () => {
      clearTimeout(timer);
      clearInterval(interval);
    };
  }, [onFinish]);

  return (
    <AnimatePresence>
      {showSplash && (
        <motion.div
          initial={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.5 }}
          className="fixed inset-0 z-50 flex items-center justify-center"
          style={{
            backgroundImage: `url(https://plus.unsplash.com/premium_photo-1686730540270-93f2c33351b6?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8Y2FyfGVufDB8fDB8fHww)`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            backgroundColor: theme === 'dark' ? 'rgba(0,0,0,0.7)' : 'rgba(255,255,255,0.7)',
            backgroundBlendMode: theme === 'dark' ? 'overlay' : 'lighten'
          }}
        >
          <div className="relative w-full max-w-md mx-auto flex flex-col items-center">
            {/* 3D Text */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5, duration: 0.8 }}
              className="text-center mb-8"
            >
              <h1 className="text-6xl font-bold mb-4 font-display text-white"
                  style={{
                    textShadow: `
                      3px 3px 0 rgba(0,0,0,0.2),
                      6px 6px 0 rgba(0,0,0,0.1),
                      0 0 20px rgba(255,255,255,0.5)
                    `,
                    letterSpacing: '2px'
                  }}>
                LUXAUTO
              </h1>
              <p className="text-white/80 text-lg">Premium Car Rental</p>
            </motion.div>
            
            {/* Loading Spinner */}
            <motion.div
              initial={{ rotate: 0 }}
              animate={{ rotate: 360 }}
              transition={{
                duration: 1.5,
                repeat: Infinity,
                ease: "linear"
              }}
              className="w-12 h-12 rounded-full border-4 border-transparent border-t-white mb-4"
            />

            {/* Progress Bar */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.8, duration: 0.5 }}
              className="w-full max-w-xs bg-white/20 rounded-full h-2 mb-4 overflow-hidden"
            >
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${progress}%` }}
                className="bg-white h-2 rounded-full"
              />
            </motion.div>

            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 1.2 }}
              className="text-white/70 text-sm"
            >
              Loading your luxury experience...
            </motion.p>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default SplashScreen;
