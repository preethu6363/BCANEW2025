
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Star, Car, ThumbsUp, MessageSquare } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

// Mock review data
const appReviews = [
  {
    id: 'app-1',
    name: 'Rahul Sharma',
    avatar: '/avatar-1.png',
    date: '2 weeks ago',
    rating: 4.5,
    text: 'The app is incredibly user-friendly and makes booking a luxury car a breeze. The selection is impressive!',
    likes: 12,
    replies: 2,
  },
  {
    id: 'app-2',
    name: 'Priya Patel',
    avatar: '/avatar-2.png',
    date: '1 month ago',
    rating: 5,
    text: 'Outstanding app experience. The integration with maps for pickup locations is extremely helpful.',
    likes: 8,
    replies: 1,
  },
  {
    id: 'app-3',
    name: 'Vikram Singh',
    avatar: '/avatar-3.png',
    date: '3 months ago',
    rating: 4,
    text: 'Very smooth booking process. Would love to see more payment options in the future.',
    likes: 5,
    replies: 0,
  }
];

const carReviews = [
  {
    id: 'car-1',
    name: 'Ananya Desai',
    avatar: '/avatar-4.png',
    date: '1 week ago',
    carName: 'BMW 7 Series',
    rating: 5,
    text: 'The BMW 7 Series exceeded all my expectations. Luxurious interior, smooth drive, and the perfect car for my business meetings.',
    likes: 15,
    replies: 3,
  },
  {
    id: 'car-2',
    name: 'Raj Malhotra',
    avatar: '/avatar-5.png',
    date: '2 months ago',
    carName: 'Porsche 911',
    rating: 4.5,
    text: 'The Porsche 911 was an exhilarating experience! The handling and power are unmatched.',
    likes: 24,
    replies: 5,
  },
  {
    id: 'car-3',
    name: 'Meera Iyer',
    avatar: '/avatar-6.png',
    date: '3 weeks ago',
    carName: 'Mercedes-Benz S-Class',
    rating: 5,
    text: 'The epitome of luxury. The S-Class made my anniversary celebration truly special.',
    likes: 18,
    replies: 2,
  }
];

const ReviewTabs = () => {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState<string>('app');
  
  const handleLike = (reviewId: string) => {
    toast({
      title: "Review liked",
      description: "Thank you for your feedback!",
    });
  };
  
  const handleReply = (reviewId: string) => {
    toast({
      title: "Reply started",
      description: "You can now write your response.",
    });
  };
  
  const handleSubmitReview = () => {
    toast({
      title: "Review submission",
      description: "Your review will be submitted after you login.",
    });
  };
  
  const renderRatingStars = (rating: number) => {
    return (
      <div className="flex items-center">
        {[...Array(5)].map((_, i) => (
          <Star 
            key={i} 
            size={16} 
            className={`${i < Math.floor(rating) ? 'text-yellow-500 fill-yellow-500' : i < rating ? 'text-yellow-500 fill-yellow-500' : 'text-gray-300'}`}
          />
        ))}
        <span className="ml-1 text-sm font-medium">{rating.toFixed(1)}</span>
      </div>
    );
  };

  return (
    <div className="py-12 bg-muted/10">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
          className="text-center mb-10"
        >
          <h2 className="text-3xl font-bold mb-4 font-display">Customer Reviews</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            See what our customers are saying about our luxury cars and service experience
          </p>
        </motion.div>
        
        <Tabs defaultValue="app" value={activeTab} onValueChange={setActiveTab} className="w-full">
          <div className="flex justify-center mb-8">
            <TabsList className="grid w-full max-w-md grid-cols-2">
              <TabsTrigger value="app" className="text-base py-3">
                App Reviews
              </TabsTrigger>
              <TabsTrigger value="cars" className="text-base py-3">
                Car Reviews
              </TabsTrigger>
            </TabsList>
          </div>
          
          <TabsContent value="app" className="mt-0">
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {appReviews.map((review, index) => (
                <motion.div
                  key={review.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  viewport={{ once: true }}
                >
                  <Card className="h-full">
                    <CardContent className="p-6">
                      <div className="flex justify-between items-start mb-4">
                        <div className="flex items-start gap-3">
                          <Avatar>
                            <AvatarImage src={review.avatar} />
                            <AvatarFallback>{review.name.substring(0, 2)}</AvatarFallback>
                          </Avatar>
                          <div>
                            <h4 className="font-semibold">{review.name}</h4>
                            <p className="text-sm text-muted-foreground">{review.date}</p>
                          </div>
                        </div>
                        {renderRatingStars(review.rating)}
                      </div>
                      
                      <p className="mb-6 text-muted-foreground">{review.text}</p>
                      
                      <div className="flex justify-between items-center">
                        <div className="flex gap-3">
                          <Button
                            variant="ghost"
                            size="sm"
                            className="flex items-center gap-1 text-muted-foreground"
                            onClick={() => handleLike(review.id)}
                          >
                            <ThumbsUp className="h-4 w-4" />
                            <span>{review.likes}</span>
                          </Button>
                          
                          <Button
                            variant="ghost"
                            size="sm"
                            className="flex items-center gap-1 text-muted-foreground"
                            onClick={() => handleReply(review.id)}
                          >
                            <MessageSquare className="h-4 w-4" />
                            <span>{review.replies}</span>
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </TabsContent>
          
          <TabsContent value="cars" className="mt-0">
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {carReviews.map((review, index) => (
                <motion.div
                  key={review.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  viewport={{ once: true }}
                >
                  <Card className="h-full">
                    <CardContent className="p-6">
                      <div className="flex justify-between items-start mb-4">
                        <div className="flex items-start gap-3">
                          <Avatar>
                            <AvatarImage src={review.avatar} />
                            <AvatarFallback>{review.name.substring(0, 2)}</AvatarFallback>
                          </Avatar>
                          <div>
                            <h4 className="font-semibold">{review.name}</h4>
                            <p className="text-sm text-muted-foreground">{review.date}</p>
                          </div>
                        </div>
                        {renderRatingStars(review.rating)}
                      </div>
                      
                      <div className="bg-muted/30 rounded-lg px-3 py-2 flex items-center gap-2 mb-4">
                        <Car className="h-4 w-4 text-green-500" />
                        <span className="text-sm font-medium">{review.carName}</span>
                      </div>
                      
                      <p className="mb-6 text-muted-foreground">{review.text}</p>
                      
                      <div className="flex justify-between items-center">
                        <div className="flex gap-3">
                          <Button
                            variant="ghost"
                            size="sm"
                            className="flex items-center gap-1 text-muted-foreground"
                            onClick={() => handleLike(review.id)}
                          >
                            <ThumbsUp className="h-4 w-4" />
                            <span>{review.likes}</span>
                          </Button>
                          
                          <Button
                            variant="ghost"
                            size="sm"
                            className="flex items-center gap-1 text-muted-foreground"
                            onClick={() => handleReply(review.id)}
                          >
                            <MessageSquare className="h-4 w-4" />
                            <span>{review.replies}</span>
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </TabsContent>
        </Tabs>
        
        <div className="mt-12 text-center">
          <Button 
            onClick={handleSubmitReview}
            className="bg-green-500 hover:bg-green-600 text-white"
          >
            Write a Review
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ReviewTabs;
