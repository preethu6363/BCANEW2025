
import React from 'react';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';
import { Zap, Award, Truck, Flame, Car } from 'lucide-react';

interface Category {
  id: string;
  name: string;
  icon: React.ReactNode;
}

interface CarCategoryFilterProps {
  selectedCategory: string;
  onSelectCategory: (categoryId: string) => void;
}

const categories: Category[] = [
  { id: 'all', name: 'All Cars', icon: <Car /> },
  { id: 'electric', name: 'Electric & Hybrid', icon: <Zap /> },
  { id: 'luxury', name: 'Luxury', icon: <Award /> },
  { id: 'suv', name: 'SUVs', icon: <Truck /> },
  { id: 'sports', name: 'Sports', icon: <Flame /> },
  { id: 'commuter', name: 'Commuters', icon: <Car /> },
];

const CarCategoryFilter: React.FC<CarCategoryFilterProps> = ({
  selectedCategory,
  onSelectCategory,
}) => {
  return (
    <div className="flex overflow-x-auto scrollbar-hide pb-2 gap-2">
      {categories.map((category) => (
        <button
          key={category.id}
          onClick={() => onSelectCategory(category.id)}
          className={cn(
            "relative flex-shrink-0 flex flex-col items-center justify-center p-4 rounded-xl transition-all",
            selectedCategory === category.id
              ? "bg-luxury text-luxury-foreground"
              : "bg-secondary hover:bg-secondary/80 text-foreground"
          )}
        >
          {selectedCategory === category.id && (
            <motion.div
              layoutId="active-category"
              className="absolute inset-0 bg-luxury rounded-xl"
              transition={{ type: "spring", duration: 0.5 }}
            />
          )}
          <span className={cn(
            "relative flex items-center justify-center w-8 h-8 mb-2 rounded-full",
            selectedCategory === category.id
              ? "text-luxury-muted"
              : "text-foreground"
          )}>
            {category.icon}
          </span>
          <span className="relative text-sm font-medium">{category.name}</span>
        </button>
      ))}
    </div>
  );
};

export default CarCategoryFilter;
