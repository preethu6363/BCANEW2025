
import React, { useRef, useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { CarType } from '@/types/car';
import CarCard from './CarCard';

interface CarGalleryProps {
  title: string;
  cars: CarType[];
  bookmarkedCars?: string[];
  onBookmark?: (carId: string) => void;
}

const CarGallery: React.FC<CarGalleryProps> = ({
  title,
  cars,
  bookmarkedCars = [],
  onBookmark,
}) => {
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const [isPaused, setIsPaused] = useState(false);
  const scrollSpeed = 0.5; // pixels per frame
  const animationId = useRef<number>();
  const scrollPos = useRef(0);

  const scroll = (direction: 'left' | 'right') => {
    const container = scrollContainerRef.current;
    if (!container) return;

    const scrollAmount = direction === 'left'
      ? -container.clientWidth * 0.75
      : container.clientWidth * 0.75;
    
    container.scrollBy({ left: scrollAmount, behavior: 'smooth' });
  };

  useEffect(() => {
    const autoScroll = () => {
      const container = scrollContainerRef.current;
      if (!container || isPaused) return;

      scrollPos.current += scrollSpeed;
      container.scrollLeft = scrollPos.current;

      // Reset position when reaching end
      if (scrollPos.current >= container.scrollWidth - container.clientWidth) {
        scrollPos.current = 0;
        container.scrollLeft = 0;
      }

      animationId.current = requestAnimationFrame(autoScroll);
    };

    animationId.current = requestAnimationFrame(autoScroll);
    return () => {
      if (animationId.current) {
        cancelAnimationFrame(animationId.current);
      }
    };
  }, [isPaused]);
  return (
    <div className="relative">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold">{title}</h2>
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="icon"
            className="rounded-full"
            onClick={() => scroll('left')}
          >
            <ChevronLeft className="h-5 w-5" />
          </Button>
          <Button
            variant="outline"
            size="icon"
            className="rounded-full"
            onClick={() => scroll('right')}
          >
            <ChevronRight className="h-5 w-5" />
          </Button>
        </div>
      </div>

      <div
        ref={scrollContainerRef}
        className="flex gap-4 overflow-x-auto scrollbar-hide pb-4 -mx-4 px-4"
        onMouseEnter={() => setIsPaused(true)}
        onMouseLeave={() => setIsPaused(false)}
      >
        {cars.map((car, index) => (
          <motion.div
            key={car.id}
            className="flex-shrink-0 w-64 md:w-72 lg:w-80"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
          >
            <CarCard
              car={car}
              isBookmarked={bookmarkedCars.includes(car.id)}
              onBookmark={onBookmark}
            />
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default CarGallery;
