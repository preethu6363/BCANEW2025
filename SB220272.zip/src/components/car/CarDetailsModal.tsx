import React from 'react';
import { X, Star, Calendar, Fuel, Users, Gauge, Settings, Car, Shield, BookOpen } from 'lucide-react';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { CarType } from '@/types/car';
import { motion } from 'framer-motion';

interface CarDetailsModalProps {
  isOpen: boolean;
  onClose: () => void;
  car: CarType;
  onBookNow: () => void;
}

const testimonials = [
  {
    name: "Rahul M.",
    location: "Mumbai",
    rating: 5,
    comment: "Incredible car, perfect for my business meetings. The comfort and luxury exceeded my expectations.",
    date: "2 weeks ago"
  },
  {
    name: "Priya S.",
    location: "Bangalore",
    rating: 4,
    comment: "Great performance and smooth drive. The only thing I would improve is the pickup process which took longer than expected.",
    date: "1 month ago"
  },
  {
    name: "Aditya K.",
    location: "Delhi",
    rating: 5,
    comment: "Absolutely loved driving this car. It turned heads everywhere I went. Will definitely rent again!",
    date: "2 months ago"
  }
];

const features = [
  "GPS Navigation System",
  "Premium Audio System",
  "Leather Seats",
  "Panoramic Sunroof",
  "Climate Control",
  "Bluetooth Connectivity",
  "Backup Camera",
  "Keyless Entry"
];

const CarDetailsModal: React.FC<CarDetailsModalProps> = ({ isOpen, onClose, car, onBookNow }) => {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl p-0 max-h-[90vh] overflow-hidden">
        <div className="flex flex-col max-h-[90vh]">
          {/* Header with image */}
          <div className="relative h-64 md:h-80 overflow-hidden">
            <img 
              src={car.image} 
              alt={car.name}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent"></div>
            
            <button 
              onClick={onClose}
              className="absolute top-4 right-4 p-2 rounded-full bg-black/20 text-white hover:bg-black/40 transition-colors"
            >
              <X size={20} />
            </button>
            
            <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
              <Badge className="mb-2">
                {car.categoryName}
              </Badge>
              <h2 className="text-3xl font-bold flex items-center gap-2">
                {car.name}
                {car.trending && (
                  <Badge variant="outline" className="ml-2 border-primary/50 text-primary-foreground">
                    Trending
                  </Badge>
                )}
              </h2>
              <div className="flex items-center mt-1">
                <div className="flex items-center">
                  <Star className="h-4 w-4 text-yellow-400 fill-yellow-400" />
                  <span className="ml-1 font-medium">{car.rating}</span>
                  <span className="text-white/70 ml-1">({testimonials.length} reviews)</span>
                </div>
                <span className="mx-2">•</span>
                <div className="text-white/90">
                  {car.year} Model
                </div>
              </div>
            </div>
          </div>
          
          {/* Content */}
          <div className="flex-1 overflow-y-auto">
            <Tabs defaultValue="overview" className="p-6">
              <TabsList className="w-full mb-6">
                <TabsTrigger value="overview" className="flex-1">Overview</TabsTrigger>
                <TabsTrigger value="specifications" className="flex-1">Specifications</TabsTrigger>
                <TabsTrigger value="reviews" className="flex-1">Reviews</TabsTrigger>
              </TabsList>
              
              <TabsContent value="overview" className="space-y-6">
                <div>
                  <h3 className="text-lg font-semibold mb-2">Description</h3>
                  <p className="text-muted-foreground">{car.description}</p>
                </div>
                
                <div>
                  <h3 className="text-lg font-semibold mb-4">Key Features</h3>
                  <div className="grid grid-cols-2 gap-3">
                    {features.map((feature, index) => (
                      <div key={index} className="flex items-center gap-2">
                        <Shield className="h-4 w-4 text-primary" />
                        <span className="text-sm">{feature}</span>
                      </div>
                    ))}
                  </div>
                </div>
                
                <div>
                  <h3 className="text-lg font-semibold mb-4">Pricing</h3>
                  <div className="bg-muted/50 rounded-lg p-4">
                    <div className="grid grid-cols-3 gap-4 text-center">
                      <div className="p-3">
                        <p className="text-muted-foreground text-sm">Hourly</p>
                        <p className="text-xl font-bold">₹{Math.round(car.price / 24)}</p>
                      </div>
                      <div className="p-3 border-x">
                        <p className="text-muted-foreground text-sm">Daily</p>
                        <p className="text-xl font-bold">₹{car.price}</p>
                      </div>
                      <div className="p-3">
                        <p className="text-muted-foreground text-sm">Weekly</p>
                        <p className="text-xl font-bold">₹{Math.round(car.price * 7 * 0.85)}</p>
                        <Badge variant="outline" className="text-xs mt-1">15% off</Badge>
                      </div>
                    </div>
                    <div className="mt-4 text-sm text-muted-foreground">
                      <p>* Security deposit of ₹{car.price * 2} required</p>
                      <p>* Free cancellation up to 24 hours before pickup</p>
                    </div>
                    </div>
                </div>
              </TabsContent>
              
              <TabsContent value="specifications">
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <h3 className="text-lg font-semibold mb-4">Technical Specifications</h3>
                    <div className="space-y-4">
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="text-sm flex items-center gap-2">
                            <Car className="h-4 w-4" /> Engine
                          </span>
                          <span className="text-sm font-medium">{car.specifications?.engine}</span>
                        </div>
                      </div>
                      
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="text-sm flex items-center gap-2">
                            <Gauge className="h-4 w-4" /> Power
                          </span>
                          <span className="text-sm font-medium">{car.specifications?.power}</span>
                        </div>
                      </div>
                      
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="text-sm flex items-center gap-2">
                            <Fuel className="h-4 w-4" /> Mileage
                          </span>
                          <span className="text-sm font-medium">{car.specifications?.mileage}</span>
                        </div>
                      </div>
                      
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="text-sm flex items-center gap-2">
                            <Users className="h-4 w-4" /> Seating Capacity
                          </span>
                          <span className="text-sm font-medium">{car.specifications?.seatingCapacity} Persons</span>
                        </div>
                      </div>
                      
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="text-sm flex items-center gap-2">
                            <Settings className="h-4 w-4" /> Transmission
                          </span>
                          <span className="text-sm font-medium">{car.transmission}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="text-center flex flex-col items-center justify-center">
                    <motion.div
                      initial={{ scale: 0.8, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      transition={{ duration: 0.5 }}
                      className="relative w-64 h-64"
                    >
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="text-7xl font-bold opacity-20">RPM</div>
                      </div>
                      
                      <svg viewBox="0 0 100 100" className="w-full h-full">
                        <circle 
                          cx="50" 
                          cy="50" 
                          r="45" 
                          fill="none" 
                          stroke="currentColor" 
                          strokeWidth="2" 
                          strokeOpacity="0.1" 
                        />
                        
                        <motion.circle 
                          cx="50" 
                          cy="50" 
                          r="45" 
                          fill="none" 
                          stroke="currentColor" 
                          strokeWidth="4" 
                          strokeLinecap="round"
                          strokeDasharray="283"
                          initial={{ strokeDashoffset: 283 }}
                          animate={{ strokeDashoffset: 283 * (1 - 0.7) }}
                          transition={{ duration: 2, ease: "easeInOut" }}
                          className="text-primary"
                        />
                      </svg>
                      
                      <div className="absolute inset-0 flex flex-col items-center justify-center">
                        <div className="text-sm text-muted-foreground">Performance</div>
                        <div className="text-3xl font-bold text-primary">7.5</div>
                        <div className="text-sm">/ 10</div>
                      </div>
                    </motion.div>
                    
                    <p className="text-sm text-muted-foreground mt-4 max-w-xs">
                      This car offers exceptional performance with a perfect balance of power and fuel efficiency, making it ideal for both city driving and long journeys.
                    </p>
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="reviews">
                <div>
                  <div className="flex items-center justify-between mb-6">
                    <h3 className="text-lg font-semibold">Customer Reviews</h3>
                    <div className="flex items-center gap-1">
                      <Star className="h-5 w-5 text-yellow-400 fill-yellow-400" />
                      <span className="font-bold text-lg">{car.rating}</span>
                      <span className="text-muted-foreground">({testimonials.length} reviews)</span>
                    </div>
                  </div>
                  
                  <div className="space-y-6">
                    {testimonials.map((review, index) => (
                      <div key={index} className="border-b pb-6 last:border-0">
                        <div className="flex justify-between">
                          <div>
                            <div className="font-medium">{review.name}</div>
                            <div className="text-sm text-muted-foreground">{review.location}</div>
                          </div>
                          <div className="flex items-center">
                            {Array.from({ length: 5 }).map((_, i) => (
                              <Star 
                                key={i} 
                                size={14} 
                                className={i < review.rating ? "text-yellow-400 fill-yellow-400" : "text-gray-300"} 
                              />
                            ))}
                          </div>
                        </div>
                        <p className="mt-2 text-sm">{review.comment}</p>
                        <div className="mt-2 text-xs text-muted-foreground">{review.date}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </div>
          
          {/* Footer with book button */}
          <div className="p-4 border-t bg-background sticky bottom-0 flex justify-between items-center">
            <div>
              <p className="text-muted-foreground text-sm">Daily Rate</p>
              <p className="text-xl font-bold text-gradient">₹{car.price}<span className="text-sm font-normal text-muted-foreground">/day</span></p>
            </div>
            
            <Button
              onClick={() => {
                onBookNow();
                onClose();
              }}
              className="px-8"
              size="lg"
            >
              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <BookOpen className="mr-2 h-5 w-5" />
                Book Now
              </motion.div>
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default CarDetailsModal;
