import React, { useState, useEffect } from 'react';
import { useTheme } from '@/hooks/use-theme';
import { Heart, Star, Clock, Calendar, Zap, Info, BookOpen, ShieldCheck, Users, Fuel, ChevronLeft, ChevronRight, Award } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { motion, AnimatePresence } from 'framer-motion';
import BookingModal from '@/components/booking/BookingModal';
import CarDetailsModal from '@/components/car/CarDetailsModal';
import { CarType } from '@/types/car';

interface CarCardProps {
  car: CarType;
  isBookmarked?: boolean;
  onBookmark?: (carId: string) => void;
}

const CarCard: React.FC<CarCardProps> = ({
  car,
  isBookmarked = false,
  onBookmark = () => {},
}) => {
  const { theme } = useTheme();
  const [bookmarked, setBookmarked] = useState(isBookmarked);
  const [showBookingModal, setShowBookingModal] = useState(false);
  const [showDetailsModal, setShowDetailsModal] = useState(false);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [isHovered, setIsHovered] = useState(false);
  const [autoRotate, setAutoRotate] = useState(true);

  // Safely handle car images
  const carImages = [car?.image, ...(car?.images || [])].filter(Boolean);
  const isPanoramic = carImages.length > 1;

  // Auto-rotate images
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (autoRotate && isPanoramic) {
      interval = setInterval(() => {
        setCurrentImageIndex((prev) => (prev + 1) % carImages.length);
      }, 3000);
    }
    return () => clearInterval(interval);
  }, [autoRotate, carImages.length, isPanoramic]);

  // Handle hover state
  useEffect(() => {
    if (isHovered) {
      setAutoRotate(false);
    } else {
      const timeout = setTimeout(() => {
        setAutoRotate(true);
      }, 2000);
      return () => clearTimeout(timeout);
    }
  }, [isHovered]);

  const toggleBookmark = (e: React.MouseEvent) => {
    e.stopPropagation();
    setBookmarked(!bookmarked);
    onBookmark(car.id);
  };

  const prevImage = (e: React.MouseEvent) => {
    e.stopPropagation();
    setCurrentImageIndex(prev => (prev - 1 + carImages.length) % carImages.length);
  };

  const nextImage = (e: React.MouseEvent) => {
    e.stopPropagation();
    setCurrentImageIndex(prev => (prev + 1) % carImages.length);
  };

  const getTagColor = () => {
    switch (car?.category) {
      case 'electric': return 'bg-green-100 text-green-800';
      case 'luxury': return 'bg-purple-100 text-purple-800';
      case 'suv': return 'bg-blue-100 text-blue-800';
      case 'sports': return 'bg-red-100 text-red-800';
      case 'commuter': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getCategoryIcon = () => {
    switch (car?.category) {
      case 'electric': return <Zap className="h-3.5 w-3.5" />;
      case 'sports': return <span className="text-xs">🏎️</span>;
      case 'luxury': return <ShieldCheck className="h-3.5 w-3.5" />;
      case 'suv': return <Users className="h-3.5 w-3.5" />;
      case 'commuter': return <Fuel className="h-3.5 w-3.5" />;
      default: return null;
    }
  };

  return (
    <>
      <motion.div 
        className="relative overflow-hidden rounded-xl bg-card h-full flex flex-col"
        whileHover={{ y: -5 }}
        transition={{ duration: 0.2 }}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        {car?.trending && (
          <Badge className="absolute top-3 left-3 z-10 bg-primary/90 text-primary-foreground">
            Trending
          </Badge>
        )}
        
        <div className="relative aspect-[16/9] overflow-hidden">
          {carImages.length > 0 ? (
            <AnimatePresence mode="wait">
              <motion.img
                key={currentImageIndex}
                src={carImages[currentImageIndex]}
                alt={car?.name || 'Car image'}
                className="object-cover w-full h-full"
                initial={{ opacity: 0.6 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0.6 }}
                transition={{ duration: 0.5 }}
              />
            </AnimatePresence>
          ) : (
            <div className="w-full h-full bg-gray-100 flex items-center justify-center">
              <span className="text-gray-400">No Image Available</span>
            </div>
          )}

          <button
            onClick={toggleBookmark}
            className="absolute top-3 right-3 p-2 rounded-full bg-white/80 backdrop-blur-sm z-10"
          >
            <Heart
              size={18}
              className={cn(
                bookmarked ? "fill-red-500 text-red-500" : "text-gray-500"
              )}
            />
          </button>
          
          {isPanoramic && (
            <>
              <button 
                onClick={prevImage}
                className="absolute left-2 top-1/2 transform -translate-y-1/2 p-1 rounded-full bg-black/30 text-white backdrop-blur-sm z-10"
              >
                <ChevronLeft size={20} />
              </button>
              <button 
                onClick={nextImage}
                className="absolute right-2 top-1/2 transform -translate-y-1/2 p-1 rounded-full bg-black/30 text-white backdrop-blur-sm z-10"
              >
                <ChevronRight size={20} />
              </button>
            </>
          )}
        </div>
        
        <div className="p-4 flex-grow flex flex-col">
          <div className="flex items-center justify-between mb-2">
            <Badge
              variant="outline"
              className={cn("font-medium flex items-center gap-1 text-xs", getTagColor())}
            >
              {getCategoryIcon()}
              {car?.categoryName || 'Car'}
            </Badge>
            <div className="flex items-center gap-1 text-yellow-500">
              <Star size={14} className="fill-yellow-500" />
              <span className="text-sm font-medium">{car?.rating || '4.5'}</span>
            </div>
          </div>
          
          <h3 className="text-lg font-semibold mb-1">{car?.name || 'Car Name'}</h3>
          
          <div className="flex items-center text-sm text-muted-foreground space-x-3 mb-2">
            <div className="flex items-center">
              <Calendar size={14} className="mr-1" />
              <span>{car?.year || '2023'}</span>
            </div>
            <div className="flex items-center">
              <Clock size={14} className="mr-1" />
              <span>{car?.transmission || 'Automatic'}</span>
            </div>
          </div>
          
          <p className="text-sm text-muted-foreground mb-3 line-clamp-2">
            {car?.description || 'Car description not available'}
          </p>
          
          <div className="mt-auto">
            <div className="flex justify-between items-end mb-3">
              <div>
                <p className="text-sm text-muted-foreground">Starting from</p>
                <div className="flex items-baseline gap-2">
                  <p className="text-lg font-bold">
                    ₹{Math.round((car?.price || 2500)/8)}<span className="text-xs font-normal text-muted-foreground">/hr</span>
                  </p>
                  <p className="text-2xl font-bold">
                    ₹{car?.price || '2500'}<span className="text-sm font-normal text-muted-foreground">/day</span>
                  </p>
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  Weekly rate: ₹{Math.round((car?.price || 2500)*5.5)} (save 15%)
                </p>
                <p className="text-xs text-red-500 mt-1">
                  * Security deposit: ₹{car?.price ? car.price * 3 : 7500} required
                </p>
                <p className="text-xs text-red-500">
                  * Original documents must be presented at pickup
                </p>
              </div>
              
              {car?.trending && (
                <Badge className="bg-green-500/10 text-green-600">
                  <Award className="mr-1 h-3 w-3" />
                  10% Off
                </Badge>
              )}
            </div>

            <div className="grid grid-cols-2 gap-2">
              <Button
                onClick={() => setShowDetailsModal(true)}
                variant="outline"
                className="rounded-full"
                size="sm"
              >
                <Info className="mr-1 h-4 w-4" />
                Details
              </Button>
              <Button
                onClick={() => setShowBookingModal(true)}
                className={`rounded-full ${theme === 'dark' ? 'bg-blush hover:bg-blush/90' : 'bg-emerald-400 hover:bg-emerald-500'} text-white`}
                size="sm"
              >
                <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }} className="flex items-center">
                  <BookOpen className="h-4 w-4 mr-1" />
                  <span className="font-medium">Book Now</span>
                </motion.div>
              </Button>
            </div>
          </div>
        </div>
      </motion.div>

      <BookingModal 
        isOpen={showBookingModal} 
        onClose={() => setShowBookingModal(false)} 
        car={car} 
      />

      <CarDetailsModal
        isOpen={showDetailsModal}
        onClose={() => setShowDetailsModal(false)}
        car={car}
        onBookNow={() => {
          setShowDetailsModal(false);
          setShowBookingModal(true);
        }}
      />
    </>
  );
};

export default CarCard;