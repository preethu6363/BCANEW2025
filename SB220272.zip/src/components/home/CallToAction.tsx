
import React from 'react';
import { useTheme } from '@/hooks/use-theme';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { Phone, Mail } from 'lucide-react';

const CallToAction = () => {
  const { theme } = useTheme();
  return (
    <section className="py-20 relative bg-luxury overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-80 h-80 rounded-full bg-luxury-muted opacity-10 blur-3xl"></div>
        <div className="absolute -bottom-20 -left-20 w-60 h-60 rounded-full bg-luxury-muted opacity-10 blur-3xl"></div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
              Ready to Experience Luxury on Wheels?
            </h2>
            <p className="text-white/80 text-lg mb-8 max-w-2xl mx-auto">
              Book your dream car today and elevate your journey with LuxAuto's premium rental services.
            </p>

            <div className="flex flex-col sm:flex-row justify-center gap-4 mb-10">
              <Link to="/explore">
                <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  <Button className={`h-12 px-8 text-base text-white shadow-lg hover:shadow-xl transition-all ${
                    theme === 'dark'
                      ? 'bg-blush hover:bg-blush/90'
                      : 'bg-vibrant-orange hover:bg-vibrant-orange/90'
                  }`}>
                    Book Now
                  </Button>
                </motion.div>
              </Link>
              <Button variant="outline" className="h-12 px-8 text-base border-white/20 bg-white/10 backdrop-blur-sm text-white hover:bg-white/20">
                <Phone className="mr-2 h-4 w-4" /> Contact Us
              </Button>
            </div>

            <div className="flex flex-col sm:flex-row justify-center items-center gap-8 text-white/80">
              <div className="flex items-center gap-2">
                <Mail className="h-5 w-5 text-luxury-muted" />
                <span>contact@luxauto.in</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="h-5 w-5 text-luxury-muted" />
                <span>+91 98765 43210</span>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default CallToAction;
