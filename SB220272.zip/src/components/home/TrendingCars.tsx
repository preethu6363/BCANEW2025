import React from 'react';
import { motion } from 'framer-motion';
import { CarType } from '@/types/car';
import { Carousel, CarouselContent, CarouselItem } from '@/components/ui/carousel';
import CarCard from '@/components/car/CarCard';
import { ChevronLeft, ChevronRight } from 'lucide-react';

interface TrendingCarsProps {
  cars: CarType[];
  title?: string;
  bookmarkedCars?: string[];
  onBookmark?: (carId: string) => void;
}

const TrendingCars: React.FC<TrendingCarsProps> = ({ 
  cars, 
  title = 'Trending Now', 
  bookmarkedCars = [], 
  onBookmark 
}) => {
  return (
    <section className="py-12 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold mb-2">{title}</h2>
          <p className="text-muted-foreground">Discover our most popular vehicles</p>
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="relative"
        >
          <Carousel
            opts={{
              align: "start",
              loop: true,
              duration: 30,
              dragFree: true
            }}
            className="w-full"
          >
            <CarouselContent className="-ml-4">
              {cars.map((car) => (
                <CarouselItem key={car.id} className="basis-1/2 md:basis-1/3 lg:basis-1/4 pl-4">
                  <motion.div
                    whileHover={{ y: -5 }}
                    className="h-full"
                  >
                    <CarCard 
                      car={car}
                      isBookmarked={bookmarkedCars.includes(car.id)}
                      onBookmark={onBookmark}
                    />
                  </motion.div>
                </CarouselItem>
              ))}
            </CarouselContent>
          </Carousel>
        </motion.div>
      </div>
    </section>
  );
};

export default TrendingCars;