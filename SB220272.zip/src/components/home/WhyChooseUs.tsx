
import React from 'react';
import { motion } from 'framer-motion';
import {
  Shield, Clock, MapPin, Award, Zap, HeartHandshake,
  Car, Fuel, ShieldCheck, Globe, XCircle, Sparkles, Baby,
  LifeBuoy
} from 'lucide-react';

const features = [
  {
    icon: <Shield className="h-5 w-5" />,
    title: "Secured Payment",
    description: "End-to-end encrypted transactions",
    color: "bg-green-100 dark:bg-green-900/50 text-green-600 dark:text-green-300"
  },
  {
    icon: <Clock className="h-5 w-5" />,
    title: "24/7 Support",
    description: "Always available assistance",
    color: "bg-blue-100 dark:bg-blue-900/50 text-blue-600 dark:text-blue-300"
  },
  {
    icon: <MapPin className="h-5 w-5" />,
    title: "Free Pickup",
    description: "Complimentary service",
    color: "bg-purple-100 dark:bg-purple-900/50 text-purple-600 dark:text-purple-300"
  },
  {
    icon: <Award className="h-5 w-5" />,
    title: "Quality Cars",
    description: "Rigorous inspections",
    color: "bg-yellow-100 dark:bg-yellow-900/50 text-yellow-600 dark:text-yellow-300"
  },
  {
    icon: <Zap className="h-5 w-5" />,
    title: "Fast Booking",
    description: "Minutes to reserve",
    color: "bg-red-100 dark:bg-red-900/50 text-red-600 dark:text-red-300"
  },
  {
    icon: <HeartHandshake className="h-5 w-5" />,
    title: "Flexible Rentals",
    description: "Customizable options",
    color: "bg-pink-100 dark:bg-pink-900/50 text-pink-600 dark:text-pink-300"
  },
  {
    icon: <Car className="h-5 w-5" />,
    title: "Wide Selection",
    description: "100+ luxury vehicles",
    color: "bg-indigo-100 dark:bg-indigo-900/50 text-indigo-600 dark:text-indigo-300"
  },
  {
    icon: <Fuel className="h-5 w-5" />,
    title: "Fuel Included",
    description: "Full tank with every rental",
    color: "bg-orange-100 dark:bg-orange-900/50 text-orange-600 dark:text-orange-300"
  },
  {
    icon: <ShieldCheck className="h-5 w-5" />,
    title: "Insurance Options",
    description: "Comprehensive coverage",
    color: "bg-teal-100 dark:bg-teal-900/50 text-teal-600 dark:text-teal-300"
  },
  {
    icon: <Globe className="h-5 w-5" />,
    title: "Global Service",
    description: "Available in 50+ cities",
    color: "bg-cyan-100 dark:bg-cyan-900/50 text-cyan-600 dark:text-cyan-300"
  },
  {
    icon: <XCircle className="h-5 w-5" />,
    title: "Free Cancellation",
    description: "Cancel up to 24 hours before",
    color: "bg-lime-100 dark:bg-lime-900/50 text-lime-600 dark:text-lime-300"
  },
  {
    icon: <Sparkles className="h-5 w-5" />,
    title: "Premium Cleaning",
    description: "Sanitized after every rental",
    color: "bg-fuchsia-100 dark:bg-fuchsia-900/50 text-fuchsia-600 dark:text-fuchsia-300"
  },
  {
    icon: <Baby className="h-5 w-5" />,
    title: "Child Seat Options",
    description: "Safe travel for kids",
    color: "bg-rose-100 dark:bg-rose-900/50 text-rose-600 dark:text-rose-300"
  },
  {
    icon: <Award className="h-5 w-5" />,
    title: "Loyalty Rewards",
    description: "Earn points on every rental",
    color: "bg-amber-100 dark:bg-amber-900/50 text-amber-600 dark:text-amber-300"
  },
  {
    icon: <LifeBuoy className="h-5 w-5" />,
    title: "Roadside Assistance",
    description: "24/7 help available",
    color: "bg-blue-100 dark:bg-blue-900/50 text-blue-600 dark:text-blue-300"
  },
  {
    icon: <MapPin className="h-5 w-5" />,
    title: "Flexible Pickup",
    description: "Choose your location",
    color: "bg-green-100 dark:bg-green-900/50 text-green-600 dark:text-green-300"
  }
];

const WhyChooseUs = () => {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 }
    }
  };

  return (
    <section className="py-16 bg-secondary dark:bg-luxury/20 overflow-hidden">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Why Choose LuxAuto</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Premium benefits for an exceptional journey
          </p>
        </div>

        <div className="relative">
          <motion.div
            className="flex gap-4 pb-6 overflow-x-auto scrollbar-hide"
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            animate={{
              x: ["0%", "-20%"],
              transition: {
                repeat: Infinity,
                repeatType: "loop",
                duration: 20,
                ease: "linear"
              }
            }}
          >
            {features.map((feature, index) => (
              <motion.div
                key={index}
                className="flex-shrink-0 w-64 bg-gradient-to-br from-card/80 via-card/60 to-card/40 p-5 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1 hover:scale-[1.02] backdrop-blur-sm border border-white/10"
                whileHover={{
                  rotateY: 5,
                  rotateX: 2,
                  z: 10
                }}
                variants={itemVariants}
              >
                <motion.div
                  className={`h-10 w-10 rounded-lg flex items-center justify-center mb-3 ${feature.color}`}
                  whileHover={{ scale: 1.1 }}
                >
                  {feature.icon}
                </motion.div>
                <h3 className="text-lg font-semibold mb-1 bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
                  {feature.title}
                </h3>
                <p className="text-muted-foreground text-sm">{feature.description}</p>
              </motion.div>
            ))}
          </motion.div>
          <div className="absolute inset-y-0 right-0 w-20 bg-gradient-to-l from-secondary to-transparent dark:from-luxury/20 pointer-events-none" />
        </div>
      </div>
    </section>
  );
};

export default WhyChooseUs;
