
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Star, ChevronLeft, ChevronRight, Quote } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

const testimonials = [
  {
    id: 1,
    name: "Arjun Kapoor",
    position: "Business Executive",
    image: "https://randomuser.me/api/portraits/men/32.jpg",
    rating: 5,
    text: "The BMW 7 Series rental exceeded all my expectations. The car was immaculate and the service was top-notch. I'll definitely be using LuxAuto for all my future business trips."
  },
  {
    id: 2,
    name: "Priya Sharma",
    position: "Travel Blogger",
    image: "https://randomuser.me/api/portraits/women/44.jpg",
    rating: 5,
    text: "As a travel blogger, I've rented cars all over India, and LuxAuto offers the best electric vehicle selection by far. The Tata Nexon EV was perfect for my sustainable tourism series."
  },
  {
    id: 3,
    name: "Rahul Mehta",
    position: "Software Engineer",
    image: "https://randomuser.me/api/portraits/men/68.jpg",
    rating: 4,
    text: "The booking process was effortless, and the car was delivered on time. The only small issue was a slight delay in pickup, but the team was very apologetic and provided excellent service otherwise."
  },
  {
    id: 4,
    name: "Aisha Khan",
    position: "Wedding Planner",
    image: "https://randomuser.me/api/portraits/women/37.jpg",
    rating: 5,
    text: "I rented the Audi A8 for a client's wedding, and it was the perfect luxury touch. The chauffeur service was professional, and the car made for stunning photos. Highly recommend for special occasions!"
  }
];

const Testimonials = () => {
  const [activeIndex, setActiveIndex] = useState(0);

  const nextTestimonial = () => {
    setActiveIndex((current) => (current + 1) % testimonials.length);
  };

  const prevTestimonial = () => {
    setActiveIndex((current) => (current - 1 + testimonials.length) % testimonials.length);
  };

  const testimonial = testimonials[activeIndex];

  return (
    <section className="py-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">What Our Customers Say</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Read authentic experiences from our valued customers who've enjoyed the LuxAuto difference
          </p>
        </div>

        <div className="max-w-4xl mx-auto relative">
          <div className="absolute -top-10 -left-10 text-luxury-muted opacity-20">
            <Quote size={80} />
          </div>
          
          <AnimatePresence mode="wait">
            <motion.div
              key={testimonial.id}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3 }}
              className="bg-card rounded-2xl p-8 shadow-md relative z-10"
            >
              <div className="flex flex-col md:flex-row gap-6">
                <div className="flex-shrink-0">
                  <img
                    src={testimonial.image}
                    alt={testimonial.name}
                    className="w-20 h-20 rounded-full object-cover border-2 border-luxury-muted"
                  />
                </div>
                
                <div className="flex-grow">
                  <div className="flex mb-3">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        size={18}
                        className={cn(
                          i < testimonial.rating
                            ? "fill-luxury-muted text-luxury-muted"
                            : "text-gray-300"
                        )}
                      />
                    ))}
                  </div>
                  
                  <p className="text-lg mb-4 italic">{testimonial.text}</p>
                  
                  <div>
                    <h4 className="font-semibold text-lg">{testimonial.name}</h4>
                    <p className="text-muted-foreground">{testimonial.position}</p>
                  </div>
                </div>
              </div>
            </motion.div>
          </AnimatePresence>
          
          <div className="flex justify-center mt-8 gap-2">
            <Button
              variant="outline"
              size="icon"
              className="rounded-full"
              onClick={prevTestimonial}
            >
              <ChevronLeft className="h-5 w-5" />
            </Button>
            
            <div className="flex items-center gap-2">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setActiveIndex(index)}
                  className={`w-2 h-2 rounded-full transition-all ${
                    activeIndex === index 
                      ? 'bg-luxury-muted w-6' 
                      : 'bg-gray-300 hover:bg-gray-400'
                  }`}
                />
              ))}
            </div>
            
            <Button
              variant="outline"
              size="icon"
              className="rounded-full"
              onClick={nextTestimonial}
            >
              <ChevronRight className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
