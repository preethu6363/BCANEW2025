import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Search, ArrowRight, Calendar, Car, CheckCircle2, ChevronDown, MapPin, Users, Fuel } from 'lucide-react';
import { Link } from 'react-router-dom';

// Premium car images
const heroImages = [
  '',
  'https://images.unsplash.com/photo-1542362567-b07e54358753?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NDd8fGNhcnxlbnwwfHwwfHx8MA%3D%3D',
  'https://images.unsplash.com/photo-1542362567-b07e54358753?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NDd8fGNhcnxlbnwwfHwwfHx8MA%3D%3D',
  'https://images.unsplash.com/photo-1508974239320-0a029497e820?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTJ8fGNhcnxlbnwwfHwwfHx8MA%3D%3D',
  'https://images.unsplash.com/photo-1580273916550-e323be2ae537?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTF8fGNhcnxlbnwwfHwwfHx8MA%3D%3D',
  'https://plus.unsplash.com/premium_photo-1683134240084-ba074973f75e?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NXx8Y2FyfGVufDB8fDB8fHww'
];


const Hero = () => {
  const [activeIndex, setActiveIndex] = useState(0);
  const [scrollY, setScrollY] = useState(0);

  const startAutoSlideshow = () => {
    const interval = window.setInterval(() => {
      setActiveIndex((current) => (current + 1) % heroImages.length);
    }, 5000);
    return interval;
  };

  useEffect(() => {
    const handleScroll = () => {
      setScrollY(window.scrollY);
    };
    
    window.addEventListener("scroll", handleScroll);
    const slideshowInterval = startAutoSlideshow();
    
    return () => {
      window.removeEventListener("scroll", handleScroll);
      clearInterval(slideshowInterval);
    };
  }, []);
  // Calculate parallax effect
  const parallaxY = -scrollY * 0.5;

  return (
    <div className="relative h-screen min-h-[600px] w-full overflow-hidden">
      
      {/* Hero Background Images or Video */}
      <AnimatePresence initial={false}>
        <motion.div
          key={activeIndex}
          className="absolute inset-0 bg-black"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 1.5 }}
        >
          <motion.div 
            className="absolute inset-0 bg-gradient-to-t from-black via-black/60 to-transparent opacity-90"
            style={{ y: parallaxY * 0.2 }}
          />
          
          {/* Hero Image */}
          <motion.img
            src={heroImages[activeIndex]}
            alt="Luxury Car"
            className="object-cover w-full h-full opacity-80"
            style={{ y: parallaxY * 0.5, scale: 1 + (scrollY * 0.0005) }}
          />
        </motion.div>
      </AnimatePresence>
      
      {/* Hero Content */}
      <div className="container mx-auto relative z-10 flex flex-col items-center justify-center h-full pt-16 text-center px-4">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2, duration: 0.8 }}
          className="max-w-3xl"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.4, duration: 0.8 }}
            className="mb-4 inline-block px-4 py-1 rounded-full bg-primary/20 backdrop-blur-sm text-primary text-sm font-medium"
          >
            Premium Car Rental Experience in India
          </motion.div>
          
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6, duration: 0.8 }}
            className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 text-white font-display"
          >
            Experience Luxury <br />
            <span className="text-gradient">Like Never Before</span>
          </motion.h1>
          
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.8, duration: 0.8 }}
            className="text-lg md:text-xl text-white/80 mb-8 max-w-2xl mx-auto"
          >
            From electric vehicles to high-performance sports cars, experience the thrill of driving the finest automobiles in India
          </motion.p>
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1, duration: 0.8 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-4"
          >
            <Link to="/explore">
              <Button className="h-12 px-8 text-base rounded-full bg-green-500 hover:bg-green-600">
                Explore Cars <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
            <Link to="/bookings">
              <Button variant="outline" className="h-12 px-8 text-base border-white/20 bg-white/10 backdrop-blur-sm text-white hover:bg-white/20 rounded-full">
                My Bookings
              </Button>
            </Link>
          </motion.div>
        </motion.div>
        
        {/* Benefits Icons */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.2, duration: 0.8 }}
          className="mt-12 grid grid-cols-2 md:grid-cols-4 gap-8"
        >
          {[
            { icon: <Car className="h-5 w-5" />, text: "Premium Vehicles" },
            { icon: <Calendar className="h-5 w-5" />, text: "Flexible Booking" },
            { icon: <CheckCircle2 className="h-5 w-5" />, text: "Quality Assured" },
            { icon: <Search className="h-5 w-5" />, text: "24/7 Support" },
          ].map((item, index) => (
            <div key={index} className="flex flex-col items-center text-white/90">
              <div className="w-12 h-12 rounded-full bg-white/10 backdrop-blur-sm flex items-center justify-center mb-3">
                {item.icon}
              </div>
              <span className="text-sm">{item.text}</span>
            </div>
          ))}
        </motion.div>
        
        {/* Scroll Indicator */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.5, duration: 0.8 }}
          className="absolute bottom-8 left-0 right-0 flex flex-col items-center"
        >
          <span className="text-white/60 text-sm mb-2">Scroll to discover</span>
          <motion.div
            animate={{ y: [0, 10, 0] }}
            transition={{ repeat: Infinity, duration: 1.5 }}
          >
            <ChevronDown className="h-6 w-6 text-white/60" />
          </motion.div>
        </motion.div>
      </div>
      
      {/* Pagination Dots */}
      <div className="absolute bottom-8 left-8 flex flex-col gap-2 z-10">
        {heroImages.map((_, index) => (
          <button
            key={index}
            onClick={() => {
              setActiveIndex(index);
            }}
            className={`w-2 h-8 rounded-full transition-all ${
              activeIndex === index 
                ? 'bg-green-400' 
                : 'bg-white/40 h-2 hover:bg-white/60'
            }`}
          />
        ))}
      </div>
      
      {/* Quick Stats Floating Panel */}
      <motion.div 
        initial={{ opacity: 0, x: -50 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ delay: 1.5, duration: 0.8 }}
        className="absolute left-10 top-1/2 transform -translate-y-1/2 bg-black/30 backdrop-blur-md p-4 rounded-xl border border-white/10 hidden lg:block"
      >
        <div className="flex flex-col gap-4 text-white">
          <div className="flex items-center gap-3">
            <MapPin className="h-5 w-5 text-green-500" />
            <div>
              <p className="text-xs opacity-70">Locations</p>
              <p className="font-medium">15+ Cities in India</p>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            <Car className="h-5 w-5 text-green-500" />
            <div>
              <p className="text-xs opacity-70">Fleet</p>
              <p className="font-medium">200+ Luxury Cars</p>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            <Users className="h-5 w-5 text-green-500" />
            <div>
              <p className="text-xs opacity-70">Happy Customers</p>
              <p className="font-medium">10,000+</p>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            <Fuel className="h-5 w-5 text-green-500" />
            <div>
              <p className="text-xs opacity-70">Car Types</p>
              <p className="font-medium">Electric & Petrol</p>
            </div>
          </div>
        </div>
      </motion.div>
      
    </div>
  );
};

export default Hero;
