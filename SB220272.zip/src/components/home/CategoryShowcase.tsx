
import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Car, Zap, Users, ShieldCheck, Car as CarIcon } from 'lucide-react';
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from '@/components/ui/carousel';
import { Badge } from '@/components/ui/badge';

const categories = [
  {
    id: 'luxury',
    name: 'Luxury Cars',
    description: 'Experience the pinnacle of automotive excellence with our premium luxury fleet',
    image: '/lovable-uploads/e5eab1ec-6b74-4344-8073-675fdcc030ee.png',
    icon: <ShieldCheck className="h-5 w-5" />,
    color: 'bg-gradient-to-r from-purple-600 to-indigo-600',
    count: 12
  },
  {
    id: 'sports',
    name: 'Sports Cars',
    description: 'Feel the adrenaline with our high-performance sports cars collection',
    image: '/lovable-uploads/5f65edfb-d145-479b-b5fe-97ac5e3ff611.png',
    icon: <CarIcon className="h-5 w-5" />,
    color: 'bg-gradient-to-r from-red-600 to-pink-600',
    count: 8
  },
  {
    id: 'electric',
    name: 'Electric Cars',
    description: 'Go green with our innovative and powerful electric vehicles',
    image: '/lovable-uploads/0f39f5ee-d1a2-4688-a832-2f479e295e25.png',
    icon: <Zap className="h-5 w-5" />,
    color: 'bg-gradient-to-r from-green-500 to-emerald-500',
    count: 10
  },
  {
    id: 'suv',
    name: 'SUVs',
    description: 'Spacious, comfortable, and versatile SUVs for any adventure',
    image: '/lovable-uploads/fe30cab1-2fe8-4795-a116-aaa27c2460cb.png',
    icon: <Users className="h-5 w-5" />,
    color: 'bg-gradient-to-r from-blue-600 to-cyan-600',
    count: 15
  }
];

const CategoryShowcase = () => {
  return (
    <section className="py-20 bg-muted/20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
            className="text-3xl font-bold mb-4 font-display"
          >
            Browse by Category
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            viewport={{ once: true }}
            className="text-muted-foreground max-w-2xl mx-auto"
          >
            Discover the perfect vehicle for your needs from our diverse collection of premium cars
          </motion.p>
        </div>

        <Carousel className="w-full">
          <CarouselContent>
            {categories.map((category, index) => (
              <CarouselItem key={category.id} className="md:basis-1/2 lg:basis-1/3">
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  viewport={{ once: true }}
                  whileHover={{ y: -10, transition: { duration: 0.2 } }}
                  className="h-full"
                >
                  <Link to={`/explore?category=${category.id}`}>
                    <div className="relative h-96 rounded-xl overflow-hidden group">
                      {/* Background image */}
                      <div 
                        className="absolute inset-0 bg-cover bg-center transform group-hover:scale-110 transition-transform duration-700"
                        style={{ backgroundImage: `url(${category.image})` }}
                      >
                        <div className={`absolute inset-0 opacity-60 ${category.color}`}></div>
                      </div>
                      
                      {/* Content */}
                      <div className="absolute inset-0 p-6 flex flex-col justify-between">
                        <div className="flex justify-between items-start">
                          <div className="bg-white/90 dark:bg-black/80 rounded-full p-3">
                            {category.icon}
                          </div>
                          <Badge variant="outline" className="bg-white/20 backdrop-blur-sm border-none text-white">
                            {category.count} Cars
                          </Badge>
                        </div>
                        
                        <div>
                          <h3 className="text-2xl font-bold text-white mb-2 drop-shadow-md">{category.name}</h3>
                          <p className="text-white/90 mb-4 max-w-xs drop-shadow-md">{category.description}</p>
                          
                          <motion.div 
                            className="inline-block bg-white/20 backdrop-blur-sm text-white px-4 py-2 rounded-full font-medium"
                            whileHover={{ scale: 1.05 }}
                            whileTap={{ scale: 0.95 }}
                          >
                            Explore {category.name}
                          </motion.div>
                        </div>
                      </div>
                    </div>
                  </Link>
                </motion.div>
              </CarouselItem>
            ))}
          </CarouselContent>
          <div className="flex justify-center mt-8 gap-4">
            <CarouselPrevious className="static transform-none mx-0 bg-green-500 text-white hover:bg-green-600 hover:text-white" />
            <CarouselNext className="static transform-none mx-0 bg-green-500 text-white hover:bg-green-600 hover:text-white" />
          </div>
        </Carousel>
      </div>
    </section>
  );
};

export default CategoryShowcase;
